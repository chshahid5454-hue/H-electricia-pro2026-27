import React, { useState, useEffect } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { PinLockModal } from './components/PinLockModal';
import { Navbar } from './components/Navbar';
import { SideDrawer } from './components/SideDrawer';
import { BottomNav } from './components/BottomNav';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { VoiceSearchModal, VoiceCommandMatch } from './components/VoiceSearchModal';
import { DiagramZoomModal } from './components/DiagramZoomModal';
import { OwnerRatesModal } from './components/OwnerRatesModal';
import { BackupModal } from './components/BackupModal';
import { AdMobBanner } from './components/AdMobBanner';

// Views
import { HomeView } from './views/HomeView';
import { CalculatorsView } from './views/CalculatorsView';
import { FormulasView } from './views/FormulasView';
import { DiagramsView } from './views/DiagramsView';
import { PLCView } from './views/PLCView';
import { SensorsView } from './views/SensorsView';
import { VFDView } from './views/VFDView';
import { HVACView } from './views/HVACView';
import { BMSView } from './views/BMSView';
import { FireAlarmView } from './views/FireAlarmView';
import { LiftView } from './views/LiftView';
import { PanelsView } from './views/PanelsView';
import { ComponentsView } from './views/ComponentsView';
import { ToolsSafetyView } from './views/ToolsSafetyView';
import { FaultFindingView } from './views/FaultFindingView';
import { WorkDiaryView } from './views/WorkDiaryView';

import { StorageService } from './services/storage';
import { Language, ModuleId, DiagramItem } from './types';
import { MODULES_CATALOG } from './data/modules';
import { DIAGRAMS_DATA } from './data/diagramsData';

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [isLocked, setIsLocked] = useState<boolean>(true);

  // Core navigation states
  const [isHomeView, setIsHomeView] = useState<boolean>(true);
  const [activeModule, setActiveModule] = useState<ModuleId>('calculators');

  // Modals & Panels
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState<boolean>(false);
  const [voiceZoomedDiagram, setVoiceZoomedDiagram] = useState<DiagramItem | null>(null);
  const [isRatesOpen, setIsRatesOpen] = useState<boolean>(false);
  const [isBackupOpen, setIsBackupOpen] = useState<boolean>(false);
  const [isPinModalOpen, setIsPinModalOpen] = useState<boolean>(false);

  // Settings
  const [language, setLanguage] = useState<Language>(() => {
    return StorageService.getSettings().language || 'ur';
  });
  const [favoritesCount, setFavoritesCount] = useState<number>(() => {
    return StorageService.getFavorites().length;
  });

  useEffect(() => {
    // Check if PIN lock is enabled in settings
    const settings = StorageService.getSettings();
    if (!settings.isPinEnabled) {
      setIsLocked(false);
    }
  }, []);

  const handleSplashComplete = () => {
    setShowSplash(false);
  };

  const handleUnlock = () => {
    setIsLocked(false);
    setIsPinModalOpen(false);
  };

  const handleLockApp = () => {
    setIsLocked(true);
  };

  const handleToggleLanguage = () => {
    const nextLang: Language = language === 'ur' ? 'en' : 'ur';
    setLanguage(nextLang);
    const settings = StorageService.getSettings();
    StorageService.saveSettings({ ...settings, language: nextLang });
  };

  const handleSelectModule = (id: ModuleId) => {
    setActiveModule(id);
    setIsHomeView(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectHome = () => {
    setIsHomeView(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectSearchResult = (moduleId: ModuleId) => {
    setActiveModule(moduleId);
    setIsHomeView(false);
  };

  const handleOpenRates = () => {
    // My Rates is protected by PIN if locked
    if (isLocked) {
      setIsPinModalOpen(true);
    } else {
      setIsRatesOpen(true);
    }
  };

  const handleVoiceCommand = (match: VoiceCommandMatch) => {
    setIsVoiceModalOpen(false);

    if (match.action === 'open_rates') {
      handleOpenRates();
      return;
    }

    if (match.action === 'open_module' && match.moduleId) {
      setActiveModule(match.moduleId);
      setIsHomeView(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    if (match.action === 'open_diagram') {
      const diag = DIAGRAMS_DATA.find(
        (d) => d.id === match.diagramId || d.diagramType === match.diagramType
      );
      setActiveModule('diagrams');
      setIsHomeView(false);
      if (diag) {
        setVoiceZoomedDiagram(diag);
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  if (showSplash) {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  if (isLocked) {
    return (
      <PinLockModal
        isOpen={true}
        onUnlocked={handleUnlock}
        title="Owner PIN Lock | شاہد الیکٹریشن"
        subtitle="Enter 4-digit code to open H Electrician Pro (Default: 7860)"
      />
    );
  }

  const activeModInfo = MODULES_CATALOG.find((m) => m.id === activeModule);

  return (
    <div className={`min-h-screen bg-[#070F1E] text-slate-100 flex flex-col font-sans ${language === 'ur' ? 'rtl-ready' : ''}`}>
      {/* Top Navbar */}
      <Navbar
        onOpenDrawer={() => setIsDrawerOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenVoice={() => setIsVoiceModalOpen(true)}
        onLockApp={handleLockApp}
        onOpenRates={handleOpenRates}
        language={language}
        onToggleLanguage={handleToggleLanguage}
        onOpenFavorites={() => {
          setActiveModule('formulas');
          setIsHomeView(false);
        }}
        favoritesCount={favoritesCount}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5 pb-20">
        {isHomeView ? (
          <HomeView
            onSelectModule={handleSelectModule}
            onOpenRates={handleOpenRates}
            onOpenSearch={() => setIsSearchOpen(true)}
            onOpenVoice={() => setIsVoiceModalOpen(true)}
          />
        ) : (
          <>
            {/* Subheader Breadcrumb & Navigation Bar */}
            <div className="mb-4 flex items-center justify-between gap-3 p-2.5 sm:p-3 rounded-xl bg-[#0B172E] border border-[#1E3A70] shadow-sm">
              <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                <button
                  onClick={handleSelectHome}
                  className="px-3 py-1.5 rounded-lg bg-[#070F1E] hover:bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] hover:border-[#0EA5E9] text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shrink-0"
                >
                  <span>←</span>
                  <span>Dashboard (ہوم)</span>
                </button>
                <div className="h-4 w-[1px] bg-[#1E3A70] shrink-0" />
                <div className="flex items-center gap-2 truncate">
                  <span className="text-[10px] font-mono font-bold bg-[#162C58] text-[#38BDF8] px-2 py-0.5 rounded border border-[#1E3A70] shrink-0">
                    M{activeModInfo?.moduleNumber}
                  </span>
                  <h2 className="text-xs sm:text-sm font-bold text-white font-sans truncate">
                    {activeModInfo?.title}
                  </h2>
                  <span className="text-xs text-[#E8A85C] font-urdu hidden md:inline truncate">
                    · {activeModInfo?.titleUrdu}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => setIsSearchOpen(true)}
                  className="px-2.5 py-1.5 rounded-lg bg-[#070F1E] hover:bg-[#162C58] text-slate-300 text-xs font-medium border border-[#1E3A70] transition cursor-pointer"
                  title="Search Topics"
                >
                  Search
                </button>
                <button
                  onClick={handleOpenRates}
                  className="px-2.5 py-1.5 rounded-lg bg-amber-950/30 hover:bg-amber-900/50 text-[#E8A85C] text-xs font-medium border border-[#E8A85C]/30 transition cursor-pointer"
                  title="My Rates"
                >
                  Rates
                </button>
              </div>
            </div>

            {/* Active Module View */}
            {activeModule === 'calculators' && <CalculatorsView />}
            {activeModule === 'formulas' && <FormulasView />}
            {activeModule === 'diagrams' && <DiagramsView />}
            {activeModule === 'plc' && <PLCView />}
            {activeModule === 'sensors' && <SensorsView />}
            {activeModule === 'vfd' && <VFDView />}
            {activeModule === 'hvac' && <HVACView />}
            {activeModule === 'bms' && <BMSView />}
            {activeModule === 'fire_alarm' && <FireAlarmView />}
            {activeModule === 'lift' && <LiftView />}
            {activeModule === 'panels' && <PanelsView />}
            {activeModule === 'components' && <ComponentsView />}
            {activeModule === 'tools_safety' && <ToolsSafetyView />}
            {activeModule === 'fault_finding' && <FaultFindingView />}
            {activeModule === 'work_diary' && <WorkDiaryView />}
          </>
        )}
      </main>

      {/* AdMob Banner Placeholder at bottom above nav */}
      <div className="fixed bottom-14 left-0 right-0 z-30 pointer-events-auto">
        <AdMobBanner />
      </div>

      {/* Bottom Navigation Bar */}
      <BottomNav
        activeModule={activeModule}
        onSelectModule={handleSelectModule}
        isHomeView={isHomeView}
        onSelectHome={handleSelectHome}
      />

      {/* Side Drawer with all 15 Modules */}
      <SideDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        activeModule={activeModule}
        onSelectModule={handleSelectModule}
        onOpenRates={handleOpenRates}
        onOpenApkGuide={() => setIsSearchOpen(true)}
        onOpenBackup={() => setIsBackupOpen(true)}
      />

      {/* Global Search Modal */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectResult={handleSelectSearchResult}
      />

      {/* Owner Rates Secret Page */}
      <OwnerRatesModal
        isOpen={isRatesOpen}
        onClose={() => setIsRatesOpen(false)}
      />

      {/* Backup and Restore Modal */}
      <BackupModal
        isOpen={isBackupOpen}
        onClose={() => setIsBackupOpen(false)}
        onRefreshData={() => {
          setFavoritesCount(StorageService.getFavorites().length);
        }}
      />

      {/* PIN Lock Trigger Modal */}
      {isPinModalOpen && (
        <PinLockModal
          isOpen={true}
          canCancel={true}
          onCancel={() => setIsPinModalOpen(false)}
          onUnlocked={() => {
            setIsPinModalOpen(false);
            setIsRatesOpen(true);
          }}
          title="Owner Authentication | شاہد الیکٹریشن"
          subtitle="Enter 4-digit PIN to open My Rates (Default: 7860)"
        />
      )}

      {/* Voice Search Modal: Bol Ke Dikhao */}
      <VoiceSearchModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        onExecuteCommand={handleVoiceCommand}
      />

      {/* Voice Search Directly Opened Diagram */}
      {voiceZoomedDiagram && (
        <DiagramZoomModal
          isOpen={true}
          onClose={() => setVoiceZoomedDiagram(null)}
          title={voiceZoomedDiagram.title}
          titleUrdu={voiceZoomedDiagram.titleUrdu}
          diagramType={voiceZoomedDiagram.diagramType}
          item={voiceZoomedDiagram}
        />
      )}
    </div>
  );
}
