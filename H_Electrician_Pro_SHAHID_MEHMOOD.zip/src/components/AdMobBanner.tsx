import React, { useState } from 'react';
import { X, ExternalLink, ShieldCheck } from 'lucide-react';

interface AdMobBannerProps {
  adUnitId?: string;
}

export const AdMobBanner: React.FC<AdMobBannerProps> = ({
  adUnitId = 'ca-app-pub-3940256099942544/6300978111', // Standard Google Test AdMob Banner ID
}) => {
  const [isVisible, setIsVisible] = useState<boolean>(true);

  if (!isVisible) return null;

  return (
    <div className="w-full bg-[#071326] border-t border-[#1E4680] py-1.5 px-3 flex items-center justify-between text-xs text-slate-400 select-none">
      <div className="flex items-center gap-2 max-w-[85%] truncate">
        <span className="bg-[#E8A85C] text-[#050F1E] text-[9px] font-black px-1.5 py-0.5 rounded tracking-tighter">
          AD
        </span>
        <div className="truncate">
          <span className="font-bold text-white text-[11px] truncate">
            Shahid Electrician Works & Switchgear
          </span>
          <span className="hidden sm:inline text-[10px] text-slate-400 ml-1.5 truncate">
            Industrial Panels, Star-Delta Starters & Motor Rewinding in Pakistan
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2 flex-shrink-0">
        <span className="hidden md:inline font-mono text-[9px] text-slate-500 truncate">
          ID: {adUnitId.slice(0, 20)}...
        </span>
        <button
          onClick={() => setIsVisible(false)}
          title="Dismiss Ad"
          className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
