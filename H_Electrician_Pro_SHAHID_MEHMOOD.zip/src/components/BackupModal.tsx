import React, { useState } from 'react';
import { X, Download, Upload, Check, HardDrive, AlertTriangle } from 'lucide-react';
import { StorageService } from '../services/storage';

interface BackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRefreshData: () => void;
}

export const BackupModal: React.FC<BackupModalProps> = ({ isOpen, onClose, onRefreshData }) => {
  const [importStatus, setImportStatus] = useState<string>('');
  const [importError, setImportError] = useState<string>('');

  if (!isOpen) return null;

  const handleExport = () => {
    const jsonString = StorageService.exportFullBackup();
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `helectrician_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setImportStatus('بیک اپ فائل ڈاؤن لوڈ ہو گئی ہے! (Backup exported successfully)');
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const success = StorageService.importFullBackup(content);
        if (success) {
          setImportStatus('ڈیٹا کامیابی سے بحال ہو گیا ہے! (Database restored successfully)');
          setImportError('');
          onRefreshData();
        } else {
          setImportError('فائل درست نہیں ہے (Invalid backup file)');
        }
      } catch {
        setImportError('فائل پڑھنے میں غلطی (Error reading file)');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-fadeIn">
      <div className="w-full max-w-md rounded-2xl bg-[#0A1E3C] border-2 border-[#E8A85C] shadow-2xl p-5 text-white flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#1E4680]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#38BDF8]/20 text-[#38BDF8]">
              <HardDrive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white font-sans">Offline Data Backup & Restore</h3>
              <p className="text-xs text-slate-300 font-urdu">ڈائری اور ریٹ لسٹ کا مکمل بیک اپ</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#163768] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="py-4 space-y-4 text-xs">
          <p className="text-slate-300 leading-relaxed font-urdu">
            آپ کی ڈائری، کسٹمر ریکارڈ، ذاتی نوٹس اور ریٹ لسٹ سب آپ کے موبائل کی میموری میں محفوظ ہیں۔ نئے موبائل میں ڈیٹا شفٹ کرنے کیلئے بیک اپ فائل ڈاؤن لوڈ کریں۔
          </p>

          {/* Export Button */}
          <div className="p-3.5 rounded-xl bg-[#0F294E] border border-[#1E4680] flex items-center justify-between gap-3">
            <div>
              <h4 className="font-bold text-white text-sm">Download Backup (بیک اپ بنائیں)</h4>
              <p className="text-[11px] text-slate-400">Save complete database to phone (.json)</p>
            </div>
            <button
              onClick={handleExport}
              className="px-3.5 py-2 rounded-xl bg-[#E8A85C] hover:bg-[#F7C58B] text-[#050F1E] font-bold flex items-center gap-1.5 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Export</span>
            </button>
          </div>

          {/* Import File Input */}
          <div className="p-3.5 rounded-xl bg-[#0F294E] border border-[#1E4680] flex items-center justify-between gap-3">
            <div>
              <h4 className="font-bold text-white text-sm">Restore Data (پرانا ڈیٹا لوڈ کریں)</h4>
              <p className="text-[11px] text-slate-400">Select backup file from device</p>
            </div>
            <label className="px-3.5 py-2 rounded-xl bg-[#163768] hover:bg-[#1E4680] text-slate-200 font-bold flex items-center gap-1.5 border border-[#1E4680] transition cursor-pointer">
              <Upload className="w-4 h-4 text-[#38BDF8]" />
              <span>Select File</span>
              <input type="file" accept=".json" onChange={handleFileChange} className="hidden" />
            </label>
          </div>

          {/* Feedback Messages */}
          {importStatus && (
            <div className="p-2.5 rounded-lg bg-emerald-950 border border-emerald-500 text-emerald-200 font-semibold flex items-center gap-1.5 font-urdu">
              <Check className="w-4 h-4 text-emerald-400" />
              {importStatus}
            </div>
          )}

          {importError && (
            <div className="p-2.5 rounded-lg bg-red-950 border border-red-500 text-red-200 font-semibold flex items-center gap-1.5 font-urdu">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              {importError}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-[#1E4680] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-[#163768] hover:bg-[#1E4680] font-bold text-xs text-white"
          >
            Close (بند کریں)
          </button>
        </div>
      </div>
    </div>
  );
};
