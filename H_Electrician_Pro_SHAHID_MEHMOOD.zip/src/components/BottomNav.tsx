import React from 'react';
import { Home, Calculator, BookOpen, GitFork, Cpu, Layers, Box, FileText } from 'lucide-react';
import { ModuleId } from '../types';

interface BottomNavProps {
  activeModule: ModuleId;
  onSelectModule: (id: ModuleId) => void;
  isHomeView: boolean;
  onSelectHome: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeModule,
  onSelectModule,
  isHomeView,
  onSelectHome,
}) => {
  const tabs = [
    { id: 'home', label: 'Home', labelUrdu: 'ہوم', icon: <Home className="w-4 h-4 sm:w-5 sm:h-5" />, isHome: true },
    { id: 'calculators', label: 'Calcs', labelUrdu: 'حساب', icon: <Calculator className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'formulas', label: 'Formulas', labelUrdu: 'فارمولے', icon: <BookOpen className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'diagrams', label: 'Wiring', labelUrdu: 'ڈایاگرام', icon: <GitFork className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'plc', label: 'PLC/VFD', labelUrdu: 'آٹومیشن', icon: <Cpu className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'panels', label: 'Panels', labelUrdu: 'پینلز', icon: <Layers className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'components', label: 'Parts', labelUrdu: 'پرزہ جات', icon: <Box className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'work_diary', label: 'Diary', labelUrdu: 'ڈائری', icon: <FileText className="w-4 h-4 sm:w-5 sm:h-5" /> },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#070F1E]/95 backdrop-blur-md border-t border-[#1E3A70] shadow-2xl px-1 sm:px-3 py-1">
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        {tabs.map((tab) => {
          const isSelected = tab.isHome
            ? isHomeView
            : !isHomeView &&
              (activeModule === tab.id ||
                (tab.id === 'plc' && (activeModule === 'plc' || activeModule === 'vfd' || activeModule === 'sensors')) ||
                (tab.id === 'panels' &&
                  (activeModule === 'panels' ||
                    activeModule === 'hvac' ||
                    activeModule === 'bms' ||
                    activeModule === 'fire_alarm' ||
                    activeModule === 'lift')));

          return (
            <button
              key={tab.id}
              onClick={() => {
                if (tab.isHome) {
                  onSelectHome();
                } else {
                  onSelectModule(tab.id as ModuleId);
                }
              }}
              className={`flex-1 py-1 px-0.5 flex flex-col items-center justify-center transition-all cursor-pointer rounded-xl relative ${
                isSelected
                  ? 'text-[#38BDF8]'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`p-1 rounded-lg transition-all ${
                  isSelected
                    ? 'bg-[#0284C7]/20 border border-[#0EA5E9]/50 shadow-[0_0_12px_rgba(14,165,233,0.3)]'
                    : ''
                }`}
              >
                {tab.icon}
              </div>
              <span className={`text-[10px] font-bold font-sans tracking-tight mt-0.5 truncate max-w-[42px] sm:max-w-none ${isSelected ? 'text-white' : ''}`}>
                {tab.label}
              </span>
              <span className={`text-[9px] font-urdu leading-none truncate max-w-[42px] sm:max-w-none ${isSelected ? 'text-[#E8A85C]' : 'text-slate-500'}`}>
                {tab.labelUrdu}
              </span>

              {/* Active top dot indicator */}
              {isSelected && (
                <span className="absolute -top-1 w-1.5 h-1.5 rounded-full bg-[#38BDF8] shadow-[0_0_6px_#38BDF8]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
