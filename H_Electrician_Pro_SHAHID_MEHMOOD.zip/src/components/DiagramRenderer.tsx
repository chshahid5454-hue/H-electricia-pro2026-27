import React from 'react';

interface DiagramRendererProps {
  type: string;
  className?: string;
  isSimulating?: boolean;
}

export const DiagramRenderer: React.FC<DiagramRendererProps> = ({
  type,
  className = '',
  isSimulating = false,
}) => {
  // Glow / simulation styles
  const activeWireColor = isSimulating ? '#38BDF8' : undefined;
  const activePhase = isSimulating ? '#EF4444' : '#EF4444';
  const activeNeutral = isSimulating ? '#38BDF8' : '#38BDF8';
  const pulseClass = isSimulating ? 'animate-pulse' : '';

  switch (type) {
    // ----------------------------------------------------
    // 1. ONE WAY SWITCH & LAMP
    // ----------------------------------------------------
    case 'house':
    case 'one_way':
      return (
        <svg viewBox="0 0 760 430" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <defs>
            <radialGradient id="lampGlow1" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#FFFBEB" />
              <stop offset="50%" stopColor="#FBBF24" />
              <stop offset="100%" stopColor="#071326" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="100%" height="100%" fill="#071326" />
          {/* Header Banner */}
          <rect x="20" y="15" width="720" height="42" rx="8" fill="#0A1E3C" stroke="#E8A85C" strokeWidth="1.5" />
          <text x="40" y="42" fill="#E8A85C" fontSize="15" fontWeight="bold">
            1-WAY SWITCH & LAMP WIRING SCHEMATIC (سنگل وے سوئچ اور بلب وائرنگ)
          </text>
          <text x="720" y="42" textAnchor="end" fill="#94A3B8" fontSize="12">
            230V AC Single Phase • Phase Wire Broken Through Switch
          </text>

          {/* DB Breaker Box */}
          <rect x="40" y="90" width="130" height="200" rx="10" fill="#0F294E" stroke="#38BDF8" strokeWidth="2" />
          <text x="105" y="125" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="13">MAIN DB</text>
          <text x="105" y="145" textAnchor="middle" fill="#94A3B8" fontSize="11">MCB 10A SP</text>
          <circle cx="105" cy="185" r="7" fill="#EF4444" stroke="#FFF" strokeWidth="1.5" />
          <text x="105" y="210" textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="11">PHASE (L)</text>
          <circle cx="105" cy="240" r="7" fill="#38BDF8" stroke="#FFF" strokeWidth="1.5" />
          <text x="105" y="265" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="11">NEUTRAL (N)</text>

          {/* 1-Way Switch */}
          <rect x="300" y="150" width="150" height="150" rx="10" fill="#0F294E" stroke="#E8A85C" strokeWidth="2" />
          <text x="375" y="180" textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="13">1-WAY SWITCH</text>
          <text x="375" y="198" textAnchor="middle" fill="#94A3B8" fontSize="10">10A Piano Type (سوئچ)</text>
          <circle cx="375" cy="225" r="6" fill="#EF4444" />
          <text x="355" y="230" textAnchor="end" fill="#CBD5E1" fontSize="10">COM (L)</text>
          <circle cx="375" cy="265" r="6" fill="#F97316" />
          <text x="355" y="270" textAnchor="end" fill="#CBD5E1" fontSize="10">L1 (Load)</text>
          <line x1="375" y1="225" x2={isSimulating ? "375" : "390"} y2={isSimulating ? "265" : "250"} stroke="#E8A85C" strokeWidth="3.5" strokeLinecap="round" />

          {/* Lamp Load */}
          <circle cx="620" cy="220" r={isSimulating ? "65" : "50"} fill="url(#lampGlow1)" className={pulseClass} />
          <circle cx="620" cy="220" r="35" fill="#0F294E" stroke="#FBBF24" strokeWidth="3" />
          <path d="M 605 220 C 610 200 630 200 635 220" fill="none" stroke="#FFF" strokeWidth="2.5" />
          <text x="620" y="280" textAnchor="middle" fill="#FBBF24" fontWeight="bold" fontSize="13">LAMP LOAD (بلب)</text>
          <text x="620" y="298" textAnchor="middle" fill="#94A3B8" fontSize="11">230V AC Load</text>

          {/* Wiring Lines */}
          <path d="M 112 185 L 240 185 L 240 225 L 369 225" fill="none" stroke="#EF4444" strokeWidth="3.5" strokeLinecap="round" />
          <text x="210" y="175" fill="#EF4444" fontSize="11" fontWeight="bold">Phase Wire (Red 1.5mm²)</text>
          <path d="M 381 265 L 500 265 L 500 220 L 585 220" fill="none" stroke="#F97316" strokeWidth="3.5" strokeLinecap="round" />
          <text x="450" y="255" fill="#F97316" fontSize="11" fontWeight="bold">Half-Wire (Switch Live)</text>
          <path d="M 112 240 L 200 240 L 200 340 L 620 340 L 620 255" fill="none" stroke="#38BDF8" strokeWidth="3.5" strokeLinecap="round" strokeDasharray="8 4" />
          <text x="350" y="360" fill="#38BDF8" textAnchor="middle" fontSize="12" fontWeight="bold">Neutral Directly to Lamp (Direct Return 1.5mm²)</text>

          {/* Safety Rule Note on Canvas */}
          <rect x="40" y="380" width="680" height="32" rx="6" fill="#1C1917" stroke="#DC2626" />
          <text x="50" y="401" fill="#EF4444" fontSize="11" fontWeight="bold">
            ⚠️ لازمی سیفٹی اصول: سوئچ ہمیشہ فیز (Phase) تار پر لگائیں۔ سوئچ کو نیوٹرل پر لگانے سے بلب بند ہونے پر بھی ہولڈر میں 230V کرنٹ رہتا ہے۔
          </text>
        </svg>
      );

    // ----------------------------------------------------
    // 2. TWO-WAY STAIRCASE WIRING
    // ----------------------------------------------------
    case 'two_way':
      return (
        <svg viewBox="0 0 760 440" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <defs>
            <radialGradient id="lampGlow2" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#FFFBEB" />
              <stop offset="40%" stopColor="#FBBF24" />
              <stop offset="100%" stopColor="#071326" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="720" height="42" rx="8" fill="#0A1E3C" stroke="#E8A85C" strokeWidth="1.5" />
          <text x="40" y="42" fill="#E8A85C" fontSize="15" fontWeight="bold">
            2-WAY STAIRCASE WIRING SCHEMATIC (ٹو وے سیڑھی وائرنگ - دو سوئچ، ایک بلب)
          </text>
          <text x="720" y="42" textAnchor="end" fill="#94A3B8" fontSize="12">
            Safe 3-Wire Traveler Method • Standard IEC Method
          </text>

          {/* Switch 1 Box (Ground Floor) */}
          <rect x="50" y="120" width="160" height="200" rx="12" fill="#0F294E" stroke="#E8A85C" strokeWidth="2" />
          <text x="130" y="150" textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="13">SWITCH 1</text>
          <text x="130" y="170" textAnchor="middle" fill="#94A3B8" fontSize="11">Bottom of Stairs (نیچے)</text>
          <circle cx="160" cy="200" r="7" fill="#E8A85C" />
          <text x="140" y="205" textAnchor="end" fill="#CBD5E1" fontSize="11" fontWeight="bold">L1</text>
          <circle cx="160" cy="240" r="7" fill="#EF4444" />
          <text x="140" y="245" textAnchor="end" fill="#EF4444" fontSize="11" fontWeight="bold">COM</text>
          <circle cx="160" cy="280" r="7" fill="#E8A85C" />
          <text x="140" y="285" textAnchor="end" fill="#CBD5E1" fontSize="11" fontWeight="bold">L2</text>

          {/* Switch 2 Box (Top Floor) */}
          <rect x="360" y="120" width="160" height="200" rx="12" fill="#0F294E" stroke="#E8A85C" strokeWidth="2" />
          <text x="440" y="150" textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="13">SWITCH 2</text>
          <text x="440" y="170" textAnchor="middle" fill="#94A3B8" fontSize="11">Top of Stairs (اوپر)</text>
          <circle cx="390" cy="200" r="7" fill="#E8A85C" />
          <text x="410" y="205" fill="#CBD5E1" fontSize="11" fontWeight="bold">L1</text>
          <circle cx="390" cy="240" r="7" fill="#F97316" />
          <text x="410" y="245" fill="#F97316" fontSize="11" fontWeight="bold">COM</text>
          <circle cx="390" cy="280" r="7" fill="#E8A85C" />
          <text x="410" y="285" fill="#CBD5E1" fontSize="11" fontWeight="bold">L2</text>

          {/* Staircase Lamp in Center */}
          <circle cx="640" cy="220" r="55" fill="url(#lampGlow2)" className={pulseClass} />
          <circle cx="640" cy="220" r="35" fill="#0F294E" stroke="#FBBF24" strokeWidth="3" />
          <path d="M 625 220 C 630 200 650 200 655 220" fill="none" stroke="#FFF" strokeWidth="2.5" />
          <text x="640" y="280" textAnchor="middle" fill="#FBBF24" fontWeight="bold" fontSize="13">STAIR LAMP (بلب)</text>

          {/* Wiring Connections */}
          <path d="M 20 240 L 153 240" fill="none" stroke="#EF4444" strokeWidth="4" strokeLinecap="round" />
          <text x="30" y="230" fill="#EF4444" fontSize="11" fontWeight="bold">Phase In (فیز)</text>
          <path d="M 167 200 L 383 200" fill="none" stroke="#EAB308" strokeWidth="3.5" strokeLinecap="round" />
          <text x="270" y="190" fill="#EAB308" textAnchor="middle" fontSize="11" fontWeight="bold">Traveler Wire 1 (L1 to L1)</text>
          <path d="M 167 280 L 383 280" fill="none" stroke="#EAB308" strokeWidth="3.5" strokeLinecap="round" />
          <text x="270" y="300" fill="#EAB308" textAnchor="middle" fontSize="11" fontWeight="bold">Traveler Wire 2 (L2 to L2)</text>
          <path d="M 397 240 L 560 240 L 560 220 L 605 220" fill="none" stroke="#F97316" strokeWidth="3.5" strokeLinecap="round" />
          <text x="500" y="230" fill="#F97316" fontSize="11" fontWeight="bold">Lamp Switch Wire</text>
          <path d="M 20 370 L 640 370 L 640 255" fill="none" stroke="#38BDF8" strokeWidth="3.5" strokeLinecap="round" strokeDasharray="8 4" />
          <text x="350" y="390" fill="#38BDF8" textAnchor="middle" fontSize="12" fontWeight="bold">
            Neutral Directly from DB (نیوٹرل براہ راست)
          </text>
        </svg>
      );

    // ----------------------------------------------------
    // 3. GODOWN / CORRIDOR SEQUENCE WIRING
    // ----------------------------------------------------
    case 'godown':
      return (
        <svg viewBox="0 0 780 440" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="740" height="42" rx="8" fill="#0A1E3C" stroke="#E8A85C" strokeWidth="1.5" />
          <text x="40" y="42" fill="#E8A85C" fontSize="15" fontWeight="bold">
            GODOWN / TUNNEL SEQUENCE LIGHTING (گودام اور سرنگ وائرنگ - سلسلہ وار کنٹرول)
          </text>

          {/* Master 1-way switch at entrance */}
          <rect x="40" y="130" width="100" height="150" rx="8" fill="#0F294E" stroke="#EF4444" strokeWidth="2" />
          <text x="90" y="160" textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="11">MASTER SW</text>
          <text x="90" y="178" textAnchor="middle" fill="#94A3B8" fontSize="10">1-Way Entrance</text>
          <circle cx="90" cy="205" r="5" fill="#EF4444" />
          <circle cx="90" cy="245" r="5" fill="#EF4444" />

          {/* 3 Two-way switches along corridor */}
          {[
            { id: 1, name: '2-WAY SW 1', x: 200 },
            { id: 2, name: '2-WAY SW 2', x: 380 },
            { id: 3, name: '2-WAY SW 3', x: 560 },
          ].map((sw) => (
            <g key={sw.id}>
              <rect x={sw.x} y={130} width="110" height="150" rx="8" fill="#0F294E" stroke="#E8A85C" strokeWidth="2" />
              <text x={sw.x + 55} y={160} textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="11">{sw.name}</text>
              <circle cx={sw.x + 35} cy="200" r="5" fill="#EF4444" />
              <circle cx={sw.x + 75} cy="200" r="5" fill="#EAB308" />
              <circle cx={sw.x + 55} cy="245" r="5" fill="#F97316" />
              <text x={sw.x + 55} y={265} textAnchor="middle" fill="#CBD5E1" fontSize="9">COM</text>
            </g>
          ))}

          {/* Lamps Row */}
          {[
            { id: 1, label: 'LAMP 1', x: 190, y: 350 },
            { id: 2, label: 'LAMP 2', x: 370, y: 350 },
            { id: 3, label: 'LAMP 3', x: 550, y: 350 },
            { id: 4, label: 'LAMP 4', x: 700, y: 350 },
          ].map((l) => (
            <g key={l.id}>
              <circle cx={l.x} cy={l.y} r="24" fill="#0F294E" stroke="#FBBF24" strokeWidth="2.5" />
              <text x={l.x} y={l.y + 5} textAnchor="middle" fill="#FBBF24" fontWeight="bold" fontSize="10">{l.label}</text>
            </g>
          ))}

          {/* Lines */}
          <path d="M 20 205 L 85 205" stroke="#EF4444" strokeWidth="3" />
          <path d="M 95 245 L 255 245" stroke="#EF4444" strokeWidth="3" />
          <path d="M 235 200 L 190 326" stroke="#F97316" strokeWidth="3" />
          <path d="M 275 200 L 435 245" stroke="#EAB308" strokeWidth="3" />
          <path d="M 415 200 L 370 326" stroke="#F97316" strokeWidth="3" />
          <path d="M 455 200 L 615 245" stroke="#EAB308" strokeWidth="3" />
          <path d="M 595 200 L 550 326" stroke="#F97316" strokeWidth="3" />
          <path d="M 635 200 L 700 326" stroke="#EAB308" strokeWidth="3" />

          {/* Common Neutral Line */}
          <path d="M 20 400 L 750 400" stroke="#38BDF8" strokeWidth="3" strokeDasharray="6 4" />
          <text x="390" y="420" fill="#38BDF8" textAnchor="middle" fontSize="11" fontWeight="bold">Common Neutral (ساری لائٹوں پر نیوٹرل کامن)</text>
        </svg>
      );

    // ----------------------------------------------------
    // 4. DISTRIBUTION BOARD (DB) DRESSING
    // ----------------------------------------------------
    case 'db':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="20" width="760" height="440" rx="16" fill="#0A1E3C" stroke="#E8A85C" strokeWidth="3" />
          <rect x="35" y="35" width="730" height="40" rx="8" fill="#0F294E" stroke="#1E4680" strokeWidth="1.5" />
          <text x="50" y="60" fill="#E8A85C" fontSize="15" fontWeight="bold">
            PROFESSIONAL DISTRIBUTION BOARD (DB) DRESSING & WIRING SCHEMATIC
          </text>
          <text x="750" y="60" textAnchor="end" fill="#38BDF8" fontSize="12">
            63A Isolator ➔ 30mA RCCB ➔ 10A/20A/32A MCBs
          </text>

          {/* Main Isolator 63A DP */}
          <rect x="60" y="110" width="110" height="170" rx="8" fill="#163768" stroke="#EF4444" strokeWidth="2" />
          <text x="115" y="140" textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="12">MAIN ISOLATOR</text>
          <text x="115" y="160" textAnchor="middle" fill="#FFF" fontSize="14" fontWeight="bold">63A DP</text>
          <circle cx="85" cy="195" r="5" fill="#EF4444" />
          <circle cx="145" cy="195" r="5" fill="#38BDF8" />
          <circle cx="85" cy="250" r="5" fill="#EF4444" />
          <circle cx="145" cy="250" r="5" fill="#38BDF8" />
          <text x="85" y="185" textAnchor="middle" fill="#EF4444" fontSize="10">P-In</text>
          <text x="145" y="185" textAnchor="middle" fill="#38BDF8" fontSize="10">N-In</text>

          {/* RCCB (ELCB) 63A 30mA */}
          <rect x="200" y="110" width="120" height="170" rx="8" fill="#163768" stroke="#10B981" strokeWidth="2" />
          <text x="260" y="140" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="12">RCCB (ELCB)</text>
          <text x="260" y="160" textAnchor="middle" fill="#FFF" fontSize="14" fontWeight="bold">63A 30mA</text>
          <rect x="240" y="170" width="40" height="20" rx="4" fill="#EAB308" />
          <text x="260" y="184" textAnchor="middle" fill="#000" fontWeight="bold" fontSize="10">TEST</text>
          <circle cx="230" cy="250" r="5" fill="#EF4444" />
          <circle cx="290" cy="250" r="5" fill="#38BDF8" />
          <text x="230" y="270" textAnchor="middle" fill="#EF4444" fontSize="10">P-Out</text>
          <text x="290" y="270" textAnchor="middle" fill="#38BDF8" fontSize="10">N-Out</text>

          {/* SP MCBs Row */}
          {[
            { id: 1, label: 'LIGHT', rating: '10A', x: 350 },
            { id: 2, label: 'FANS', rating: '10A', x: 420 },
            { id: 3, label: 'SOCKETS', rating: '16A', x: 490 },
            { id: 4, label: 'POWER', rating: '20A', x: 560 },
            { id: 5, label: 'AC 1.5T', rating: '32A', x: 630 },
          ].map((mcb) => (
            <g key={mcb.id}>
              <rect x={mcb.x} y={110} width="60" height="170" rx="6" fill="#163768" stroke="#E8A85C" strokeWidth="1.5" />
              <text x={mcb.x + 30} y={135} textAnchor="middle" fill="#E8A85C" fontSize="10" fontWeight="bold">{mcb.label}</text>
              <text x={mcb.x + 30} y={155} textAnchor="middle" fill="#FFF" fontSize="13" fontWeight="bold">{mcb.rating}</text>
              <circle cx={mcb.x + 30} cy={120} r="4" fill="#EF4444" />
              <circle cx={mcb.x + 30} cy={265} r="4" fill="#EF4444" />
            </g>
          ))}

          {/* Copper Comb Busbar */}
          <rect x="345" y="290" width="350" height="14" rx="4" fill="#B87333" stroke="#E8A85C" strokeWidth="1.5" />
          <text x="520" y="301" textAnchor="middle" fill="#FFF" fontSize="10" fontWeight="bold">
            COPPER COMB BUSBAR (فیز بس بار)
          </text>
          <path d="M 230 255 L 230 297 L 345 297" fill="none" stroke="#EF4444" strokeWidth="4" strokeLinecap="round" />

          {/* Neutral Brass Terminal Bar */}
          <rect x="350" y="340" width="340" height="24" rx="5" fill="#0284C7" stroke="#38BDF8" strokeWidth="1.5" />
          <text x="520" y="356" textAnchor="middle" fill="#FFF" fontSize="11" fontWeight="bold">
            NEUTRAL BRASS BUSBAR (نیوٹرل لنک)
          </text>
          <path d="M 290 255 L 290 352 L 350 352" fill="none" stroke="#38BDF8" strokeWidth="4" strokeLinecap="round" />

          {/* Earth Brass Terminal Bar */}
          <rect x="350" y="400" width="340" height="24" rx="5" fill="#15803D" stroke="#4ADE80" strokeWidth="1.5" />
          <text x="520" y="416" textAnchor="middle" fill="#FFF" fontSize="11" fontWeight="bold">
            EARTH BRASS BUSBAR (گرؤنڈنگ / ارتھ لنک)
          </text>
          <path d="M 60 412 L 350 412" fill="none" stroke="#4ADE80" strokeWidth="4" strokeLinecap="round" />
          <text x="200" y="405" fill="#4ADE80" fontSize="11" fontWeight="bold">Main Earth Rod (16mm²)</text>
        </svg>
      );

    // ----------------------------------------------------
    // 5. SOLAR HYBRID INVERTER & NET METERING
    // ----------------------------------------------------
    case 'solar':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#FBBF24" strokeWidth="1.5" />
          <text x="40" y="42" fill="#FBBF24" fontSize="15" fontWeight="bold">
            SOLAR HYBRID / ON-GRID INVERTER & NET METERING WIRING SCHEMATIC
          </text>

          {/* Solar PV Panels */}
          <rect x="40" y="90" width="160" height="110" rx="8" fill="#1E3A8A" stroke="#38BDF8" strokeWidth="2" />
          <text x="120" y="125" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="12">SOLAR PV ARRAY</text>
          <text x="120" y="145" textAnchor="middle" fill="#FBBF24" fontSize="11">Strings in Series (350V DC)</text>
          <circle cx="70" cy="180" r="5" fill="#EF4444" />
          <text x="85" y="184" fill="#EF4444" fontSize="10" fontWeight="bold">PV (+)</text>
          <circle cx="140" cy="180" r="5" fill="#1E293B" stroke="#FFF" />
          <text x="155" y="184" fill="#CBD5E1" fontSize="10" fontWeight="bold">PV (-)</text>

          {/* DC Protection Box */}
          <rect x="250" y="90" width="130" height="110" rx="8" fill="#0F294E" stroke="#EF4444" strokeWidth="2" />
          <text x="315" y="120" textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="11">DC DB BOX</text>
          <text x="315" y="140" textAnchor="middle" fill="#FFF" fontSize="10">DC Breaker 600V</text>
          <text x="315" y="155" textAnchor="middle" fill="#38BDF8" fontSize="10">+ DC SPD Surge</text>

          {/* Central Hybrid Inverter */}
          <rect x="430" y="90" width="180" height="230" rx="12" fill="#0A1E3C" stroke="#FBBF24" strokeWidth="3" />
          <rect x="450" y="110" width="140" height="40" rx="6" fill="#071326" stroke="#38BDF8" />
          <text x="520" y="135" textAnchor="middle" fill="#38BDF8" fontFamily="monospace" fontWeight="bold" fontSize="12">HYBRID MPPT</text>
          <text x="520" y="175" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="12">INVERTER 6kW/10kW</text>
          <text x="520" y="195" textAnchor="middle" fill="#94A3B8" fontSize="10">PV In | Grid | Battery | Load</text>
          <circle cx="460" cy="290" r="5" fill="#EF4444" />
          <text x="460" y="310" textAnchor="middle" fill="#EF4444" fontSize="9">PV+</text>
          <circle cx="490" cy="290" r="5" fill="#38BDF8" />
          <text x="490" y="310" textAnchor="middle" fill="#38BDF8" fontSize="9">PV-</text>
          <circle cx="530" cy="290" r="5" fill="#10B981" />
          <text x="530" y="310" textAnchor="middle" fill="#10B981" fontSize="9">BAT+</text>
          <circle cx="570" cy="290" r="5" fill="#1E293B" stroke="#FFF" />
          <text x="570" y="310" textAnchor="middle" fill="#CBD5E1" fontSize="9">BAT-</text>

          {/* Battery Bank */}
          <rect x="40" y="270" width="180" height="120" rx="8" fill="#163768" stroke="#10B981" strokeWidth="2" />
          <text x="130" y="305" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="12">BATTERY BANK</text>
          <text x="130" y="325" textAnchor="middle" fill="#FFF" fontSize="11">Lithium LiFePO4 / 48V</text>
          <circle cx="80" cy="360" r="6" fill="#10B981" />
          <text x="100" y="365" fill="#10B981" fontSize="10" fontWeight="bold">Pos 48V</text>
          <circle cx="150" cy="360" r="6" fill="#1E293B" stroke="#FFF" />
          <text x="170" y="365" fill="#CBD5E1" fontSize="10" fontWeight="bold">Neg 0V</text>

          {/* WAPDA Bi-Directional Net Meter */}
          <rect x="650" y="90" width="120" height="130" rx="8" fill="#0F294E" stroke="#10B981" strokeWidth="2" />
          <text x="710" y="120" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="11">NET METER</text>
          <text x="710" y="140" textAnchor="middle" fill="#FBBF24" fontSize="10">Green Meter</text>
          <text x="710" y="160" textAnchor="middle" fill="#94A3B8" fontSize="9">Import / Export</text>

          {/* Wiring lines */}
          <path d="M 70 185 L 70 230 L 250 145" stroke="#EF4444" strokeWidth="3" />
          <path d="M 140 185 L 140 220 L 250 160" stroke="#CBD5E1" strokeWidth="3" />
          <path d="M 380 145 L 430 145 L 460 285" stroke="#EF4444" strokeWidth="3" />
          <path d="M 380 160 L 410 160 L 490 285" stroke="#CBD5E1" strokeWidth="3" />
          {/* Battery cables */}
          <path d="M 80 360 L 320 360 L 320 290 L 525 290" stroke="#10B981" strokeWidth="4" />
          <path d="M 150 360 L 280 360 L 280 300 L 565 300" stroke="#CBD5E1" strokeWidth="4" />

          {/* Home Load DB */}
          <rect x="650" y="270" width="120" height="120" rx="8" fill="#0F294E" stroke="#E8A85C" strokeWidth="2" />
          <text x="710" y="305" textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="11">ESSENTIAL LOAD</text>
          <text x="710" y="325" textAnchor="middle" fill="#FFF" fontSize="10">Backup DB</text>

          <path d="M 610 200 L 650 160" stroke="#EF4444" strokeWidth="3" />
          <path d="M 610 260 L 650 310" stroke="#EF4444" strokeWidth="3" />
        </svg>
      );

    // ----------------------------------------------------
    // 6. DOL (DIRECT-ON-LINE) STARTER
    // ----------------------------------------------------
    case 'dol_starter':
      return (
        <svg viewBox="0 0 780 460" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="740" height="42" rx="8" fill="#0A1E3C" stroke="#E8A85C" strokeWidth="1.5" />
          <text x="40" y="42" fill="#E8A85C" fontSize="15" fontWeight="bold">
            DOL (DIRECT-ON-LINE) MOTOR STARTER POWER & CONTROL SCHEMATIC
          </text>
          <text x="740" y="42" textAnchor="end" fill="#94A3B8" fontSize="12">
            Main KM1 • TOR 95-96 • Start/Stop PB
          </text>

          {/* Left: 3-Phase Power Circuit */}
          <rect x="35" y="80" width="310" height="350" rx="10" fill="#0B172E" stroke="#38BDF8" strokeWidth="1.5" />
          <text x="190" y="105" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="12">
            3-PHASE POWER CIRCUIT (400V AC)
          </text>

          {/* Power Lines L1, L2, L3 */}
          <line x1="70" y1="120" x2="70" y2="350" stroke="#EF4444" strokeWidth="3" />
          <text x="70" y="135" textAnchor="middle" fill="#EF4444" fontSize="9" fontWeight="bold">L1</text>
          <line x1="120" y1="120" x2="120" y2="350" stroke="#EAB308" strokeWidth="3" />
          <text x="120" y="135" textAnchor="middle" fill="#EAB308" fontSize="9" fontWeight="bold">L2</text>
          <line x1="170" y1="120" x2="170" y2="350" stroke="#0284C7" strokeWidth="3" />
          <text x="170" y="135" textAnchor="middle" fill="#0284C7" fontSize="9" fontWeight="bold">L3</text>

          {/* Contactor KM1 Contacts */}
          <rect x="50" y="160" width="140" height="45" rx="6" fill="#163768" stroke="#E8A85C" strokeWidth="1.5" />
          <text x="120" y="188" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="11">CONTACTOR KM1</text>

          {/* Thermal Overload Relay */}
          <rect x="50" y="240" width="140" height="50" rx="6" fill="#163768" stroke="#EF4444" strokeWidth="1.5" />
          <text x="120" y="265" textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="11">OVERLOAD (TOR)</text>
          <text x="120" y="280" textAnchor="middle" fill="#94A3B8" fontSize="9">Set to 100% FLA</text>

          {/* 3-Phase Induction Motor */}
          <circle cx="120" cy="380" r="32" fill="#0F294E" stroke="#10B981" strokeWidth="2.5" />
          <text x="120" y="380" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="13">M 3~</text>
          <text x="120" y="396" textAnchor="middle" fill="#FFF" fontSize="9">MOTOR</text>

          {/* Right: 230V Control Circuit */}
          <rect x="370" y="80" width="375" height="350" rx="10" fill="#0B172E" stroke="#E8A85C" strokeWidth="1.5" />
          <text x="557" y="105" textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="12">
            230V CONTROL CIRCUIT (کنٹرول سرکٹ)
          </text>

          {/* Control Rails */}
          <line x1="400" y1="125" x2="710" y2="125" stroke="#EF4444" strokeWidth="3" />
          <text x="400" y="120" fill="#EF4444" fontSize="10" fontWeight="bold">Control Phase (from MCB 6A)</text>
          <line x1="400" y1="390" x2="710" y2="390" stroke="#38BDF8" strokeWidth="3" strokeDasharray="6 3" />
          <text x="400" y="405" fill="#38BDF8" fontSize="10" fontWeight="bold">Control Neutral</text>

          {/* Overload NC Contact 95-96 */}
          <rect x="420" y="150" width="80" height="30" rx="4" fill="#071326" stroke="#EF4444" />
          <text x="460" y="165" textAnchor="middle" fill="#EF4444" fontSize="9" fontWeight="bold">TOR 95-96 (NC)</text>
          <line x1="460" y1="125" x2="460" y2="150" stroke="#EF4444" strokeWidth="2" />
          <line x1="460" y1="180" x2="460" y2="200" stroke="#EF4444" strokeWidth="2" />

          {/* Stop Push Button (NC Red) */}
          <rect x="420" y="200" width="80" height="30" rx="4" fill="#7F1D1D" stroke="#EF4444" />
          <text x="460" y="215" textAnchor="middle" fill="#FFF" fontSize="9" fontWeight="bold">STOP PB (NC)</text>
          <line x1="460" y1="230" x2="460" y2="260" stroke="#EF4444" strokeWidth="2" />

          {/* Start Push Button (NO Green) */}
          <rect x="420" y="260" width="80" height="30" rx="4" fill="#064E3B" stroke="#10B981" />
          <text x="460" y="278" textAnchor="middle" fill="#FFF" fontSize="9" fontWeight="bold">START PB (NO)</text>

          {/* Latch Contact 13-14 parallel with Start PB */}
          <rect x="540" y="260" width="80" height="30" rx="4" fill="#071326" stroke="#E8A85C" />
          <text x="580" y="278" textAnchor="middle" fill="#E8A85C" fontSize="9" fontWeight="bold">KM1 (13-14)</text>
          <path d="M 460 250 L 580 250 L 580 260" stroke="#E8A85C" strokeWidth="2" fill="none" />
          <path d="M 580 290 L 580 305 L 460 305" stroke="#E8A85C" strokeWidth="2" fill="none" />

          {/* Contactor Coil KM1 */}
          <circle cx="460" cy="345" r="18" fill="#163768" stroke="#E8A85C" strokeWidth="2" />
          <text x="460" y="349" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="11">KM1</text>
          <text x="430" y="340" fill="#CBD5E1" fontSize="8">A1</text>
          <text x="430" y="360" fill="#CBD5E1" fontSize="8">A2</text>
          <line x1="460" y1="290" x2="460" y2="327" stroke="#EF4444" strokeWidth="2" />
          <line x1="460" y1="363" x2="460" y2="390" stroke="#38BDF8" strokeWidth="2" />
        </svg>
      );

    // ----------------------------------------------------
    // 7. STAR-DELTA AUTOMATIC MOTOR STARTER
    // ----------------------------------------------------
    case 'star_delta':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#E8A85C" strokeWidth="1.5" />
          <text x="40" y="42" fill="#E8A85C" fontSize="15" fontWeight="bold">
            AUTOMATIC STAR-DELTA STARTER (3 CONTACTORS KM1, KM2, KM3 & TIMER)
          </text>
          <text x="760" y="42" textAnchor="end" fill="#38BDF8" fontSize="12">
            Reduces Starting Inrush Current by 66%
          </text>

          {/* Main Contactor KM1 */}
          <rect x="60" y="90" width="140" height="75" rx="8" fill="#163768" stroke="#E8A85C" strokeWidth="2" />
          <text x="130" y="120" textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="12">MAIN KM1</text>
          <text x="130" y="140" textAnchor="middle" fill="#FFF" fontSize="10">Line Contactor</text>

          {/* Delta Contactor KM3 */}
          <rect x="260" y="90" width="140" height="75" rx="8" fill="#163768" stroke="#10B981" strokeWidth="2" />
          <text x="330" y="120" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="12">DELTA KM3</text>
          <text x="330" y="140" textAnchor="middle" fill="#FFF" fontSize="10">Run Contactor</text>

          {/* Star Contactor KM2 */}
          <rect x="460" y="90" width="140" height="75" rx="8" fill="#163768" stroke="#38BDF8" strokeWidth="2" />
          <text x="530" y="120" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="12">STAR KM2</text>
          <text x="530" y="140" textAnchor="middle" fill="#FFF" fontSize="10">Star Bridge (Short)</text>

          {/* Star Bridge Busbar */}
          <line x1="480" y1="80" x2="580" y2="80" stroke="#FBBF24" strokeWidth="4" />
          <text x="530" y="73" textAnchor="middle" fill="#FBBF24" fontSize="10" fontWeight="bold">Star Point Bridge</text>

          {/* 6-Terminal Induction Motor */}
          <rect x="200" y="240" width="220" height="150" rx="14" fill="#0A1E3C" stroke="#E8A85C" strokeWidth="2.5" />
          <circle cx="310" cy="315" r="45" fill="#0F294E" stroke="#10B981" strokeWidth="2" />
          <text x="310" y="315" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="14">M 3~</text>
          <text x="310" y="333" textAnchor="middle" fill="#FFF" fontSize="9">6 TERMINALS</text>

          {/* Terminal Block */}
          <text x="230" y="265" fill="#EF4444" fontSize="10" fontWeight="bold">U1</text>
          <text x="270" y="265" fill="#EAB308" fontSize="10" fontWeight="bold">V1</text>
          <text x="310" y="265" fill="#0284C7" fontSize="10" fontWeight="bold">W1</text>
          <text x="230" y="375" fill="#EF4444" fontSize="10" fontWeight="bold">W2</text>
          <text x="270" y="375" fill="#EAB308" fontSize="10" fontWeight="bold">U2</text>
          <text x="310" y="375" fill="#0284C7" fontSize="10" fontWeight="bold">V2</text>

          {/* Star-Delta Timer Module */}
          <rect x="630" y="90" width="130" height="130" rx="8" fill="#163768" stroke="#F472B6" strokeWidth="2" />
          <text x="695" y="120" textAnchor="middle" fill="#F472B6" fontWeight="bold" fontSize="11">S-D TIMER</text>
          <text x="695" y="140" textAnchor="middle" fill="#FFF" fontSize="10">Delay: 5-8 Sec</text>
          <text x="695" y="160" textAnchor="middle" fill="#94A3B8" fontSize="9">Dwell: 50ms</text>

          {/* Operation Flow Box */}
          <rect x="470" y="260" width="290" height="130" rx="8" fill="#0F294E" stroke="#1E4680" />
          <text x="485" y="285" fill="#E8A85C" fontSize="11" fontWeight="bold">Operation Sequence:</text>
          <text x="485" y="310" fill="#CBD5E1" fontSize="10">1. Start PB ➔ KM1 (Main) + KM2 (Star) ON</text>
          <text x="485" y="330" fill="#CBD5E1" fontSize="10">2. Timer counts 6 sec (Motor reaches 80% speed)</text>
          <text x="485" y="350" fill="#CBD5E1" fontSize="10">3. Star drops out ➔ 50ms break ➔ KM3 (Delta) ON</text>
          <text x="485" y="370" fill="#10B981" fontSize="10" fontWeight="bold">4. Electrical Interlock prevents Star & Delta overlap</text>
        </svg>
      );

    // ----------------------------------------------------
    // 8. APFC PANEL SCHEMATIC
    // ----------------------------------------------------
    case 'apfc_panel':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#E8A85C" strokeWidth="1.5" />
          <text x="40" y="42" fill="#E8A85C" fontSize="15" fontWeight="bold">
            APFC PANEL (AUTOMATIC POWER FACTOR CORRECTION & DETUNED REACTORS)
          </text>

          {/* Main 400V Busbar */}
          <rect x="40" y="80" width="720" height="20" rx="4" fill="#B87333" stroke="#E8A85C" />
          <text x="400" y="94" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="10">
            MAIN 3-PHASE COPPER BUSBAR (L1 - L2 - L3) 400V 50Hz
          </text>

          {/* Current Transformer (CT) */}
          <circle cx="100" cy="90" r="18" fill="none" stroke="#EF4444" strokeWidth="4" />
          <text x="100" y="130" textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="10">CT 1000/5A</text>

          {/* Microprocessor PF Controller */}
          <rect x="40" y="160" width="160" height="190" rx="10" fill="#0A1E3C" stroke="#38BDF8" strokeWidth="2" />
          <rect x="55" y="175" width="130" height="35" rx="4" fill="#071326" stroke="#38BDF8" />
          <text x="120" y="198" textAnchor="middle" fill="#38BDF8" fontFamily="monospace" fontWeight="bold" fontSize="13">
            cosφ 0.98
          </text>
          <text x="120" y="235" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="11">APFC CONTROLLER</text>
          <text x="120" y="255" textAnchor="middle" fill="#94A3B8" fontSize="10">6 / 12 Step Relay Outputs</text>

          {/* 3 Capacitor Bank Branches */}
          {[
            { id: 1, step: 'STEP 1 (10 kvar)', x: 250 },
            { id: 2, step: 'STEP 2 (25 kvar)', x: 420 },
            { id: 3, step: 'STEP 3 (50 kvar)', x: 590 },
          ].map((branch) => (
            <g key={branch.id}>
              {/* Branch HRC Fuse */}
              <rect x={branch.x + 25} y={120} width="80" height="25" rx="4" fill="#163768" stroke="#CBD5E1" />
              <text x={branch.x + 65} y={137} textAnchor="middle" fill="#FFF" fontSize="9">HRC FUSE</text>

              {/* Detuned Reactor */}
              <rect x={branch.x + 15} y={165} width="100" height="40" rx="6" fill="#1E3A8A" stroke="#FBBF24" strokeWidth="1.5" />
              <text x={branch.x + 65} y={185} textAnchor="middle" fill="#FBBF24" fontSize="9" fontWeight="bold">7% REACTOR</text>
              <text x={branch.x + 65} y={198} textAnchor="middle" fill="#94A3B8" fontSize="8">Harmonic Filter</text>

              {/* Capacitor Contactor */}
              <rect x={branch.x + 15} y={225} width="100" height="45" rx="6" fill="#163768" stroke="#E8A85C" strokeWidth="1.5" />
              <text x={branch.x + 65} y={245} textAnchor="middle" fill="#E8A85C" fontSize="9" fontWeight="bold">CAP CONTACTOR</text>
              <text x={branch.x + 65} y={260} textAnchor="middle" fill="#94A3B8" fontSize="8">Damping Resistors</text>

              {/* MPP Capacitors */}
              <rect x={branch.x + 10} y={290} width="110" height="80" rx="8" fill="#0F294E" stroke="#10B981" strokeWidth="2" />
              <text x={branch.x + 65} y={320} textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="11">{branch.step}</text>
              <text x={branch.x + 65} y={340} textAnchor="middle" fill="#FFF" fontSize="9">Heavy Duty MPP</text>
              <text x={branch.x + 65} y={355} textAnchor="middle" fill="#94A3B8" fontSize="8">Internal Resistors</text>
            </g>
          ))}

          {/* Safe Earth Bar at bottom */}
          <rect x="40" y="420" width="720" height="15" rx="3" fill="#15803D" stroke="#4ADE80" />
          <text x="400" y="432" textAnchor="middle" fill="#FFF" fontSize="9" fontWeight="bold">
            EARTH GROUNDING BUSBAR (تمام کپیسیٹرز کی باڈی گراؤنڈ ہے)
          </text>
        </svg>
      );

    // ----------------------------------------------------
    // 9. AUTOMATIC TRANSFER SWITCH (ATS) GENERATOR & WAPDA
    // ----------------------------------------------------
    case 'ats':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#E8A85C" strokeWidth="1.5" />
          <text x="40" y="42" fill="#E8A85C" fontSize="15" fontWeight="bold">
            ATS GENERATOR & WAPDA AUTOMATIC CHANGEOVER SCHEMATIC
          </text>
          <text x="760" y="42" textAnchor="end" fill="#38BDF8" fontSize="12">
            Mechanical & Electrical Interlocking
          </text>

          {/* WAPDA Contactor KM1 */}
          <rect x="60" y="100" width="220" height="190" rx="12" fill="#0F294E" stroke="#EF4444" strokeWidth="2.5" />
          <text x="170" y="130" textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="14">WAPDA CONTACTOR (KM1)</text>
          <text x="170" y="150" textAnchor="middle" fill="#FFF" fontSize="11">4-Pole Heavy Duty (400V)</text>
          <circle cx="110" cy="180" r="6" fill="#EF4444" />
          <circle cx="150" cy="180" r="6" fill="#EAB308" />
          <circle cx="190" cy="180" r="6" fill="#0284C7" />
          <circle cx="230" cy="180" r="6" fill="#38BDF8" />
          <text x="170" y="210" textAnchor="middle" fill="#CBD5E1" fontSize="10">Inputs: R - Y - B - N</text>

          {/* Generator Contactor KM2 */}
          <rect x="520" y="100" width="220" height="190" rx="12" fill="#0F294E" stroke="#10B981" strokeWidth="2.5" />
          <text x="630" y="130" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="14">GENERATOR (KM2)</text>
          <text x="630" y="150" textAnchor="middle" fill="#FFF" fontSize="11">4-Pole Heavy Duty (400V)</text>
          <circle cx="570" cy="180" r="6" fill="#EF4444" />
          <circle cx="610" cy="180" r="6" fill="#EAB308" />
          <circle cx="650" cy="180" r="6" fill="#0284C7" />
          <circle cx="690" cy="180" r="6" fill="#38BDF8" />
          <text x="630" y="210" textAnchor="middle" fill="#CBD5E1" fontSize="10">Inputs: Gen R - Y - B - N</text>

          {/* Center: Mechanical Interlock */}
          <rect x="330" y="160" width="140" height="70" rx="8" fill="#1C1917" stroke="#DC2626" strokeWidth="2" />
          <text x="400" y="190" textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="11">MECHANICAL</text>
          <text x="400" y="210" textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="11">INTERLOCK</text>
          <line x1="280" y1="195" x2="330" y2="195" stroke="#DC2626" strokeWidth="4" />
          <line x1="470" y1="195" x2="520" y2="195" stroke="#DC2626" strokeWidth="4" />

          {/* Output Common Busbar */}
          <rect x="180" y="340" width="440" height="30" rx="6" fill="#B87333" stroke="#E8A85C" strokeWidth="2" />
          <text x="400" y="360" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="12">
            FACTORY LOAD BUSBAR (کامن لوڈ بس بار)
          </text>
          <path d="M 170 290 L 170 340" stroke="#EF4444" strokeWidth="4" />
          <path d="M 630 290 L 630 340" stroke="#10B981" strokeWidth="4" />

          {/* Safety Warning */}
          <rect x="40" y="410" width="720" height="40" rx="6" fill="#1C1917" stroke="#DC2626" />
          <text x="50" y="435" fill="#EF4444" fontSize="11" fontWeight="bold">
            ⚠️ خطرہ: الیکٹریکل اور مکینکل انٹرلاک کبھی بائی پاس نہ کریں۔ دونوں کنٹیکٹرز کے ایک ساتھ ملنے پر خوفناک بلاسٹ اور واپڈا ریورس فیڈ ہو سکتی ہے۔
          </text>
        </svg>
      );

    // ----------------------------------------------------
    // 10. SIEMENS S7-1200 DIGITAL INPUT WIRING (SINK/SOURCE)
    // ----------------------------------------------------
    case 'plc_s7_inputs':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#F472B6" strokeWidth="1.5" />
          <text x="40" y="42" fill="#F472B6" fontSize="15" fontWeight="bold">
            SIEMENS S7-1200 CPU 1214C DC/DC/DC DIGITAL INPUT WIRING (SINK / SOURCE)
          </text>

          {/* 24V DC Power Supply SMPS */}
          <rect x="40" y="90" width="140" height="150" rx="8" fill="#0F294E" stroke="#38BDF8" strokeWidth="2" />
          <text x="110" y="120" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="12">24V DC SMPS</text>
          <circle cx="75" cy="180" r="6" fill="#8B4513" />
          <text x="75" y="205" textAnchor="middle" fill="#E8A85C" fontSize="10">L+ (+24V)</text>
          <circle cx="145" cy="180" r="6" fill="#1E3A8A" />
          <text x="145" y="205" textAnchor="middle" fill="#38BDF8" fontSize="10">M (0V)</text>

          {/* Siemens CPU 1214C */}
          <rect x="240" y="90" width="520" height="340" rx="14" fill="#0A1E3C" stroke="#F472B6" strokeWidth="3" />
          <rect x="260" y="110" width="480" height="40" rx="6" fill="#163768" />
          <text x="500" y="135" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="13">
            SIEMENS SIMATIC S7-1200 • CPU 1214C DC/DC/DC
          </text>

          {/* Input Terminals Row */}
          <rect x="260" y="170" width="480" height="60" rx="6" fill="#071326" stroke="#38BDF8" />
          <text x="270" y="190" fill="#38BDF8" fontSize="11" fontWeight="bold">1M (Common)</text>
          <text x="360" y="190" fill="#CBD5E1" fontSize="10">DI .0 (Start)</text>
          <text x="440" y="190" fill="#CBD5E1" fontSize="10">DI .1 (Stop)</text>
          <text x="520" y="190" fill="#CBD5E1" fontSize="10">DI .2 (PNP Sensor)</text>
          <text x="640" y="190" fill="#CBD5E1" fontSize="10">DI .3 to .7</text>

          {/* LED Indicators */}
          <circle cx="380" cy="210" r="4" fill="#10B981" />
          <circle cx="460" cy="210" r="4" fill="#10B981" />
          <circle cx="560" cy="210" r="4" fill="#10B981" />

          {/* Field Devices connected to inputs */}
          {/* Start PB */}
          <rect x="290" y="270" width="90" height="60" rx="6" fill="#064E3B" stroke="#10B981" />
          <text x="335" y="295" textAnchor="middle" fill="#FFF" fontSize="10" fontWeight="bold">START PB (NO)</text>
          <text x="335" y="315" textAnchor="middle" fill="#A7F3D0" fontSize="9">Input 0.0</text>

          {/* Stop PB */}
          <rect x="410" y="270" width="90" height="60" rx="6" fill="#7F1D1D" stroke="#EF4444" />
          <text x="455" y="295" textAnchor="middle" fill="#FFF" fontSize="10" fontWeight="bold">STOP PB (NC)</text>
          <text x="455" y="315" textAnchor="middle" fill="#FECACA" fontSize="9">Input 0.1</text>

          {/* Inductive PNP Sensor */}
          <rect x="530" y="270" width="190" height="80" rx="8" fill="#163768" stroke="#FBBF24" />
          <text x="625" y="295" textAnchor="middle" fill="#FBBF24" fontSize="10" fontWeight="bold">PNP INDUCTIVE SENSOR</text>
          <text x="625" y="315" textAnchor="middle" fill="#FFF" fontSize="9">Brown: +24V | Blue: 0V | Black: Signal</text>

          {/* 1M to 0V jumper for Sourcing input */}
          <path d="M 145 186 L 200 186 L 200 185 L 290 185" stroke="#1E3A8A" strokeWidth="3" />
          <text x="210" y="170" fill="#38BDF8" fontSize="9" fontWeight="bold">1M Tied to 0V (M)</text>
        </svg>
      );

    // ----------------------------------------------------
    // 11. SIEMENS S7-1200 DIGITAL OUTPUT WIRING
    // ----------------------------------------------------
    case 'plc_s7_outputs':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#F472B6" strokeWidth="1.5" />
          <text x="40" y="42" fill="#F472B6" fontSize="15" fontWeight="bold">
            SIEMENS S7-1200 DIGITAL OUTPUT & INTERPOSING RELAYS WIRING
          </text>

          {/* CPU Output Section */}
          <rect x="40" y="90" width="220" height="340" rx="12" fill="#0A1E3C" stroke="#F472B6" strokeWidth="2.5" />
          <text x="150" y="120" textAnchor="middle" fill="#F472B6" fontWeight="bold" fontSize="13">S7-1200 OUTPUTS</text>
          <text x="150" y="140" textAnchor="middle" fill="#94A3B8" fontSize="10">Relay / Transistor (Q0.0-Q0.5)</text>
          <circle cx="80" cy="180" r="5" fill="#EF4444" />
          <text x="100" y="184" fill="#CBD5E1" fontSize="10">1L (+24V)</text>
          <circle cx="80" cy="230" r="5" fill="#10B981" />
          <text x="100" y="234" fill="#CBD5E1" fontSize="10">Q 0.0 (Motor 1)</text>
          <circle cx="80" cy="280" r="5" fill="#10B981" />
          <text x="100" y="284" fill="#CBD5E1" fontSize="10">Q 0.1 (Valve)</text>
          <circle cx="80" cy="330" r="5" fill="#10B981" />
          <text x="100" y="334" fill="#CBD5E1" fontSize="10">Q 0.2 (Alarm)</text>

          {/* Slim Interface Relays */}
          <rect x="320" y="150" width="160" height="240" rx="10" fill="#0F294E" stroke="#10B981" strokeWidth="2" />
          <text x="400" y="180" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="12">SLIM RELAY BANK</text>
          <text x="400" y="200" textAnchor="middle" fill="#94A3B8" fontSize="10">24V DC Coils (Optoisolated)</text>

          <rect x="340" y="220" width="120" height="40" rx="4" fill="#163768" stroke="#38BDF8" />
          <text x="400" y="245" textAnchor="middle" fill="#FFF" fontSize="10">Relay 1 (K1 Coil)</text>

          <rect x="340" y="280" width="120" height="40" rx="4" fill="#163768" stroke="#38BDF8" />
          <text x="400" y="305" textAnchor="middle" fill="#FFF" fontSize="10">Relay 2 (K2 Coil)</text>

          {/* Heavy 230V Motor Contactor KM1 */}
          <rect x="540" y="180" width="200" height="180" rx="10" fill="#0A1E3C" stroke="#E8A85C" strokeWidth="2.5" />
          <text x="640" y="215" textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="13">HEAVY CONTACTOR KM1</text>
          <text x="640" y="235" textAnchor="middle" fill="#FFF" fontSize="10">230V AC Coil</text>
          <circle cx="580" cy="270" r="6" fill="#EF4444" />
          <text x="600" y="275" fill="#EF4444" fontSize="10">A1 (Phase)</text>
          <circle cx="580" cy="310" r="6" fill="#38BDF8" />
          <text x="600" y="315" fill="#38BDF8" fontSize="10">A2 (Neutral)</text>

          {/* Lines */}
          <path d="M 85 230 L 340 240" stroke="#10B981" strokeWidth="3" />
          <path d="M 460 240 L 580 270" stroke="#EF4444" strokeWidth="3" />
        </svg>
      );

    // ----------------------------------------------------
    // 12. PLC LADDER LOGIC: STAR-DELTA WITH TIMER
    // ----------------------------------------------------
    case 'plc_ladder_star_delta':
      return (
        <svg viewBox="0 0 760 460" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="720" height="42" rx="8" fill="#0A1E3C" stroke="#F472B6" strokeWidth="1.5" />
          <text x="40" y="42" fill="#F472B6" fontSize="15" fontWeight="bold">
            SIEMENS TIA PORTAL LADDER: STAR-DELTA MOTOR STARTER LOGIC
          </text>

          {/* Rails */}
          <line x1="40" y1="80" x2="40" y2="430" stroke="#38BDF8" strokeWidth="5" />
          <line x1="720" y1="80" x2="720" y2="430" stroke="#38BDF8" strokeWidth="5" />

          {/* Network 1: Main Contactor Latch */}
          <text x="50" y="100" fill="#E8A85C" fontSize="11" fontWeight="bold">Network 1: Main Contactor Q0.0 Latch</text>
          <line x1="40" y1="130" x2="110" y2="130" stroke="#10B981" strokeWidth="3" />
          {/* Start NO */}
          <text x="130" y="115" fill="#FFF" fontSize="9">"Start_PB"</text>
          <line x1="110" y1="130" x2="125" y2="130" stroke="#10B981" strokeWidth="3" />
          <line x1="125" y1="120" x2="125" y2="140" stroke="#FFF" strokeWidth="2.5" />
          <line x1="135" y1="120" x2="135" y2="140" stroke="#FFF" strokeWidth="2.5" />
          <line x1="135" y1="130" x2="220" y2="130" stroke="#10B981" strokeWidth="3" />
          {/* Parallel Latch Q0.0 */}
          <path d="M 100 130 L 100 160 L 125 160" stroke="#10B981" strokeWidth="2" fill="none" />
          <line x1="125" y1="150" x2="125" y2="170" stroke="#FFF" strokeWidth="2.5" />
          <line x1="135" y1="150" x2="135" y2="170" stroke="#FFF" strokeWidth="2.5" />
          <path d="M 135 160 L 180 160 L 180 130" stroke="#10B981" strokeWidth="2" fill="none" />
          <text x="130" y="180" fill="#F472B6" fontSize="9">"Q0.0"</text>

          {/* Stop NC */}
          <line x1="220" y1="130" x2="235" y2="130" stroke="#10B981" strokeWidth="3" />
          <line x1="235" y1="120" x2="235" y2="140" stroke="#FFF" strokeWidth="2.5" />
          <line x1="245" y1="120" x2="245" y2="140" stroke="#FFF" strokeWidth="2.5" />
          <line x1="230" y1="140" x2="250" y2="120" stroke="#EF4444" strokeWidth="2" />
          <text x="240" y="115" fill="#EF4444" fontSize="9">"Stop_PB"</text>
          <line x1="245" y1="130" x2="580" y2="130" stroke="#10B981" strokeWidth="3" />
          {/* Coil Q0.0 */}
          <circle cx="610" cy="130" r="14" fill="#0F294E" stroke="#10B981" strokeWidth="2.5" />
          <text x="610" y="134" textAnchor="middle" fill="#FFF" fontSize="9" fontWeight="bold">Q 0.0</text>
          <line x1="624" y1="130" x2="720" y2="130" stroke="#10B981" strokeWidth="3" />

          {/* Network 2: TON Timer */}
          <text x="50" y="210" fill="#E8A85C" fontSize="11" fontWeight="bold">Network 2: TON Timer (T#6S)</text>
          <line x1="40" y1="240" x2="200" y2="240" stroke="#10B981" strokeWidth="3" />
          <rect x="200" y="215" width="120" height="50" rx="6" fill="#163768" stroke="#F472B6" />
          <text x="260" y="235" textAnchor="middle" fill="#FFF" fontSize="10" fontWeight="bold">TON (Timer)</text>
          <text x="260" y="255" textAnchor="middle" fill="#FBBF24" fontSize="9">PT: T#6s</text>
          <line x1="320" y1="240" x2="720" y2="240" stroke="#10B981" strokeWidth="3" />

          {/* Network 3: Star Contactor Q0.1 */}
          <text x="50" y="300" fill="#E8A85C" fontSize="11" fontWeight="bold">Network 3: Star Contactor (Q0.1) until Timer.Q</text>
          <line x1="40" y1="330" x2="580" y2="330" stroke="#10B981" strokeWidth="3" />
          <circle cx="610" cy="330" r="14" fill="#0F294E" stroke="#38BDF8" strokeWidth="2.5" />
          <text x="610" y="334" textAnchor="middle" fill="#FFF" fontSize="9" fontWeight="bold">Q 0.1</text>
          <text x="610" y="355" textAnchor="middle" fill="#38BDF8" fontSize="9">STAR</text>
          <line x1="624" y1="330" x2="720" y2="330" stroke="#10B981" strokeWidth="3" />

          {/* Network 4: Delta Contactor Q0.2 */}
          <text x="50" y="380" fill="#E8A85C" fontSize="11" fontWeight="bold">Network 4: Delta Contactor (Q0.2) after Timer.Q</text>
          <line x1="40" y1="410" x2="580" y2="410" stroke="#10B981" strokeWidth="3" />
          <circle cx="610" cy="410" r="14" fill="#0F294E" stroke="#10B981" strokeWidth="2.5" />
          <text x="610" y="414" textAnchor="middle" fill="#FFF" fontSize="9" fontWeight="bold">Q 0.2</text>
          <text x="610" y="435" textAnchor="middle" fill="#10B981" fontSize="9">DELTA</text>
          <line x1="624" y1="410" x2="720" y2="410" stroke="#10B981" strokeWidth="3" />
        </svg>
      );

    // ----------------------------------------------------
    // 13. PLC TANK LEVEL AUTOMATION
    // ----------------------------------------------------
    case 'plc_tank_level':
      return (
        <svg viewBox="0 0 760 450" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="720" height="42" rx="8" fill="#0A1E3C" stroke="#38BDF8" strokeWidth="1.5" />
          <text x="40" y="42" fill="#38BDF8" fontSize="15" fontWeight="bold">
            DUAL-FLOAT WATER TANK AUTOMATIC PUMP CONTROL
          </text>

          {/* Water Tank Graphic */}
          <rect x="60" y="90" width="220" height="260" rx="8" fill="#0F294E" stroke="#38BDF8" strokeWidth="3" />
          <rect x="62" y="200" width="216" height="148" fill="#0284C7" fillOpacity="0.4" />
          <text x="170" y="125" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="13">WATER STORAGE TANK</text>

          {/* High Float */}
          <circle cx="170" cy="160" r="14" fill="#FBBF24" />
          <text x="200" y="165" fill="#FBBF24" fontSize="10" fontWeight="bold">High Float (I 0.4 NC)</text>

          {/* Low Float */}
          <circle cx="170" cy="280" r="14" fill="#EF4444" />
          <text x="200" y="285" fill="#EF4444" fontSize="10" fontWeight="bold">Low Float (I 0.3 NO)</text>

          {/* Pump Motor */}
          <rect x="420" y="240" width="180" height="110" rx="10" fill="#0A1E3C" stroke="#10B981" strokeWidth="2.5" />
          <text x="510" y="275" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="13">PUMP MOTOR (Q0.3)</text>
          <text x="510" y="295" textAnchor="middle" fill="#FFF" fontSize="10">Submersible Pump</text>
          <text x="510" y="325" textAnchor="middle" fill="#94A3B8" fontSize="9">Automatic Latch ON/OFF</text>

          {/* Control logic explanation box */}
          <rect x="340" y="90" width="380" height="120" rx="8" fill="#0F294E" stroke="#1E4680" />
          <text x="360" y="115" fill="#38BDF8" fontSize="11" fontWeight="bold">Ladder Logic Operation:</text>
          <text x="360" y="140" fill="#CBD5E1" fontSize="10">• Water falls below Low Float ➔ I0.3 Closes ➔ Pump Q0.3 Latches ON</text>
          <text x="360" y="160" fill="#CBD5E1" fontSize="10">• Pump runs continuously until High Float I0.4 opens</text>
          <text x="360" y="180" fill="#10B981" fontSize="10" fontWeight="bold">• Dry-Run sensor I0.5 protects pump if underground sump is empty</text>
        </svg>
      );

    // ----------------------------------------------------
    // 14. VFD 3-PHASE POWER & MOTOR WIRING
    // ----------------------------------------------------
    case 'vfd_power_control':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#818CF8" strokeWidth="1.5" />
          <text x="40" y="42" fill="#818CF8" fontSize="15" fontWeight="bold">
            VFD 3-PHASE POWER & MOTOR TERMINAL WIRING WITH LINE REACTOR
          </text>

          {/* Input Line Choke */}
          <rect x="50" y="100" width="130" height="160" rx="8" fill="#0F294E" stroke="#38BDF8" strokeWidth="2" />
          <text x="115" y="130" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="12">AC LINE CHOKE</text>
          <text x="115" y="150" textAnchor="middle" fill="#94A3B8" fontSize="10">3% Impedance</text>
          <text x="115" y="170" textAnchor="middle" fill="#FFF" fontSize="9">Harmonic Suppressor</text>

          {/* VFD Drive Chassis */}
          <rect x="240" y="90" width="280" height="340" rx="14" fill="#0A1E3C" stroke="#818CF8" strokeWidth="3" />
          <rect x="270" y="115" width="220" height="50" rx="6" fill="#071326" stroke="#818CF8" />
          <text x="380" y="145" textAnchor="middle" fill="#818CF8" fontFamily="monospace" fontWeight="bold" fontSize="14">
            50.00 Hz
          </text>
          <text x="380" y="190" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="13">
            VFD INVERTER DRIVE
          </text>
          <text x="380" y="210" textAnchor="middle" fill="#94A3B8" fontSize="11">400V 3-Phase Variable Freq</text>

          {/* VFD Terminals */}
          <rect x="260" y="240" width="240" height="40" rx="6" fill="#071326" />
          <text x="285" y="265" fill="#EF4444" fontSize="11" fontWeight="bold">R</text>
          <text x="325" y="265" fill="#EAB308" fontSize="11" fontWeight="bold">S</text>
          <text x="365" y="265" fill="#0284C7" fontSize="11" fontWeight="bold">T</text>
          <text x="415" y="265" fill="#EF4444" fontSize="11" fontWeight="bold">DC+</text>
          <text x="465" y="265" fill="#F97316" fontSize="11" fontWeight="bold">BR</text>

          <rect x="260" y="320" width="240" height="40" rx="6" fill="#071326" />
          <text x="300" y="345" fill="#EF4444" fontSize="11" fontWeight="bold">U/T1</text>
          <text x="370" y="345" fill="#EAB308" fontSize="11" fontWeight="bold">V/T2</text>
          <text x="440" y="345" fill="#0284C7" fontSize="11" fontWeight="bold">W/T3</text>

          {/* External Braking Resistor */}
          <rect x="340" y="40" width="160" height="35" rx="6" fill="#7C2D12" stroke="#F97316" strokeWidth="1.5" />
          <text x="420" y="62" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="10">BRAKING RESISTOR</text>

          {/* Motor Graphic */}
          <circle cx="680" cy="340" r="45" fill="#0F294E" stroke="#10B981" strokeWidth="3" />
          <text x="680" y="340" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="14">M 3~</text>
          <text x="680" y="358" textAnchor="middle" fill="#FFF" fontSize="10">SHIELDED CABLE</text>

          {/* Lines */}
          <path d="M 180 180 L 260 250" stroke="#EF4444" strokeWidth="3" />
          <path d="M 460 340 L 635 340" stroke="#38BDF8" strokeWidth="4" />
        </svg>
      );

    // ----------------------------------------------------
    // 15. VFD FORWARD/REVERSE & 0-10V POTENTIOMETER
    // ----------------------------------------------------
    case 'vfd_forward_reverse':
      return (
        <svg viewBox="0 0 780 460" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="740" height="42" rx="8" fill="#0A1E3C" stroke="#818CF8" strokeWidth="1.5" />
          <text x="40" y="42" fill="#818CF8" fontSize="15" fontWeight="bold">
            VFD FORWARD/REVERSE & 0-10V POT SPEED WIRING
          </text>

          {/* Potentiometer */}
          <rect x="50" y="100" width="160" height="140" rx="10" fill="#0F294E" stroke="#E8A85C" strokeWidth="2" />
          <circle cx="130" cy="150" r="28" fill="#071326" stroke="#E8A85C" strokeWidth="2" />
          <line x1="130" y1="150" x2="148" y2="135" stroke="#E8A85C" strokeWidth="3" />
          <text x="130" y="195" textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="11">10kΩ POTENTIOMETER</text>
          <text x="130" y="215" textAnchor="middle" fill="#94A3B8" fontSize="9">Speed Knob (0-50 Hz)</text>

          {/* FWD / REV Selector Switch */}
          <rect x="50" y="270" width="160" height="140" rx="10" fill="#0F294E" stroke="#10B981" strokeWidth="2" />
          <circle cx="130" cy="320" r="24" fill="#071326" stroke="#10B981" strokeWidth="2" />
          <text x="130" y="365" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="11">FWD / REV SWITCH</text>
          <text x="130" y="385" textAnchor="middle" fill="#94A3B8" fontSize="9">3-Position Selector</text>

          {/* VFD Control Terminal Strip */}
          <rect x="300" y="90" width="440" height="330" rx="12" fill="#0A1E3C" stroke="#818CF8" strokeWidth="2.5" />
          <text x="520" y="125" textAnchor="middle" fill="#818CF8" fontWeight="bold" fontSize="13">
            VFD LOW VOLTAGE CONTROL STRIP
          </text>

          {/* Analog Inputs section */}
          <rect x="320" y="150" width="400" height="85" rx="6" fill="#071326" stroke="#E8A85C" />
          <text x="340" y="175" fill="#E8A85C" fontWeight="bold" fontSize="11">Analog Speed Reference:</text>
          <text x="340" y="200" fill="#FFF" fontSize="10">+10V DC Output ➔ Pot Pin 1</text>
          <text x="340" y="215" fill="#FFF" fontSize="10">AI1 (0-10V Input) ➔ Pot Center Wiper (Pin 2)</text>
          <text x="340" y="230" fill="#FFF" fontSize="10">GND (Analog Ground) ➔ Pot Pin 3</text>

          {/* Digital Inputs section */}
          <rect x="320" y="255" width="400" height="85" rx="6" fill="#071326" stroke="#10B981" />
          <text x="340" y="280" fill="#10B981" fontWeight="bold" fontSize="11">Digital Run Commands:</text>
          <text x="340" y="300" fill="#FFF" fontSize="10">+24V Output ➔ Selector Switch Common</text>
          <text x="340" y="315" fill="#FFF" fontSize="10">DI1 (Digital Input 1) ➔ Forward Run</text>
          <text x="340" y="330" fill="#FFF" fontSize="10">DI2 (Digital Input 2) ➔ Reverse Run</text>

          {/* Drive Fault Relay */}
          <rect x="320" y="355" width="400" height="50" rx="6" fill="#071326" stroke="#EF4444" />
          <text x="340" y="385" fill="#EF4444" fontWeight="bold" fontSize="10">Fault Relay: Rel1A (COM) - Rel1C (NO) ➔ Panel Alarm Lamp</text>
        </svg>
      );

    // ----------------------------------------------------
    // 16. SCADA & HMI NETWORK ARCHITECTURE
    // ----------------------------------------------------
    case 'scada_hmi_network':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#38BDF8" strokeWidth="1.5" />
          <text x="40" y="42" fill="#38BDF8" fontSize="15" fontWeight="bold">
            SCADA & HMI INDUSTRIAL AUTOMATION NETWORK TOPOLOGY
          </text>

          {/* Central Industrial Ethernet Switch */}
          <rect x="300" y="190" width="200" height="100" rx="10" fill="#0A1E3C" stroke="#38BDF8" strokeWidth="3" />
          <text x="400" y="225" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="12">
            INDUSTRIAL ETHERNET SWITCH
          </text>
          <text x="400" y="245" textAnchor="middle" fill="#94A3B8" fontSize="10">PROFINET / TCP-IP 100 Mbps</text>
          <circle cx="340" cy="270" r="4" fill="#10B981" />
          <circle cx="380" cy="270" r="4" fill="#10B981" />
          <circle cx="420" cy="270" r="4" fill="#10B981" />
          <circle cx="460" cy="270" r="4" fill="#10B981" />

          {/* Master SCADA PC Workstation */}
          <rect x="320" y="70" width="160" height="80" rx="8" fill="#163768" stroke="#FBBF24" strokeWidth="2" />
          <text x="400" y="98" textAnchor="middle" fill="#FBBF24" fontWeight="bold" fontSize="11">SCADA WORKSTATION</text>
          <text x="400" y="115" textAnchor="middle" fill="#FFF" fontSize="9">WinCC / Ignition</text>
          <text x="400" y="130" textAnchor="middle" fill="#94A3B8" fontSize="8">IP: 192.168.0.10</text>
          <line x1="400" y1="150" x2="400" y2="190" stroke="#38BDF8" strokeWidth="3" />

          {/* HMI Touch Panel KTP700 */}
          <rect x="60" y="190" width="160" height="100" rx="10" fill="#163768" stroke="#10B981" strokeWidth="2" />
          <rect x="75" y="205" width="130" height="50" rx="4" fill="#071326" stroke="#10B981" />
          <text x="140" y="235" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="11">HMI TOUCH SCREEN</text>
          <text x="140" y="275" textAnchor="middle" fill="#FFF" fontSize="9">IP: 192.168.0.2</text>
          <line x1="220" y1="240" x2="300" y2="240" stroke="#38BDF8" strokeWidth="3" />

          {/* Siemens S7-1200 PLC */}
          <rect x="580" y="190" width="170" height="100" rx="10" fill="#163768" stroke="#F472B6" strokeWidth="2" />
          <text x="665" y="225" textAnchor="middle" fill="#F472B6" fontWeight="bold" fontSize="12">SIEMENS S7-1200</text>
          <text x="665" y="245" textAnchor="middle" fill="#FFF" fontSize="9">PROFINET Port</text>
          <text x="665" y="260" textAnchor="middle" fill="#94A3B8" fontSize="8">IP: 192.168.0.1</text>
          <line x1="500" y1="240" x2="580" y2="240" stroke="#38BDF8" strokeWidth="3" />

          {/* RS-485 Modbus RTU Bus to VFDs */}
          <path d="M 665 290 L 665 370 L 600 370" stroke="#E8A85C" strokeWidth="3" fill="none" />
          <text x="665" y="340" fill="#E8A85C" fontSize="9" fontWeight="bold">Modbus RS-485</text>

          {/* 3 VFD Slaves */}
          {[
            { id: 1, node: 'VFD 1 (Addr 1)', x: 120 },
            { id: 2, node: 'VFD 2 (Addr 2)', x: 300 },
            { id: 3, node: 'VFD 3 (Addr 3)', x: 480 },
          ].map((vfd) => (
            <g key={vfd.id}>
              <rect x={vfd.x} y={340} width="140" height="70" rx="8" fill="#0F294E" stroke="#E8A85C" strokeWidth="1.5" />
              <text x={vfd.x + 70} y={370} textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="10">{vfd.node}</text>
              <text x={vfd.x + 70} y={390} textAnchor="middle" fill="#94A3B8" fontSize="8">RS-485 Terminal 68/69</text>
            </g>
          ))}
          <line x1="260" y1="375" x2="300" y2="375" stroke="#E8A85C" strokeWidth="3" />
          <line x1="440" y1="375" x2="480" y2="375" stroke="#E8A85C" strokeWidth="3" />
          <line x1="620" y1="375" x2="665" y2="370" stroke="#E8A85C" strokeWidth="3" />
          <text x="120" y="430" fill="#FBBF24" fontSize="9" fontWeight="bold">120Ω EOL Resistor on last drive</text>
        </svg>
      );

    // ----------------------------------------------------
    // 17. 1.5 TON SPLIT AC INDOOR & OUTDOOR WIRING
    // ----------------------------------------------------
    case 'split_ac_wiring':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#2DD4BF" strokeWidth="1.5" />
          <text x="40" y="42" fill="#2DD4BF" fontSize="15" fontWeight="bold">
            1.5 TON SPLIT AC INDOOR & OUTDOOR INTERCONNECTION TERMINAL WIRING
          </text>

          {/* Indoor Unit */}
          <rect x="50" y="90" width="220" height="340" rx="14" fill="#0F294E" stroke="#38BDF8" strokeWidth="2.5" />
          <text x="160" y="125" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="13">INDOOR UNIT (کمرے کے اندر)</text>
          <text x="160" y="145" textAnchor="middle" fill="#94A3B8" fontSize="10">Electronic PCB Card</text>
          <circle cx="100" cy="180" r="5" fill="#EF4444" />
          <text x="120" y="184" fill="#FFF" fontSize="10">L (Mains In)</text>
          <circle cx="100" cy="210" r="5" fill="#38BDF8" />
          <text x="120" y="214" fill="#FFF" fontSize="10">N (Mains In)</text>

          {/* Terminal Block in Indoor */}
          <rect x="70" y="240" width="180" height="170" rx="8" fill="#071326" stroke="#E8A85C" />
          <text x="160" y="260" textAnchor="middle" fill="#E8A85C" fontSize="10" fontWeight="bold">OUTDOOR FEED TERMINALS</text>
          <text x="90" y="290" fill="#EF4444" fontSize="11" fontWeight="bold">1</text>
          <text x="110" y="290" fill="#CBD5E1" fontSize="9">Comp Live</text>
          <text x="90" y="320" fill="#38BDF8" fontSize="11" fontWeight="bold">2</text>
          <text x="110" y="320" fill="#CBD5E1" fontSize="9">Neutral (N)</text>
          <text x="90" y="350" fill="#EAB308" fontSize="11" fontWeight="bold">3</text>
          <text x="110" y="350" fill="#CBD5E1" fontSize="9">Fan Motor</text>
          <text x="90" y="380" fill="#F97316" fontSize="11" fontWeight="bold">4</text>
          <text x="110" y="380" fill="#CBD5E1" fontSize="9">4-Way Valve</text>

          {/* Outdoor Unit */}
          <rect x="520" y="90" width="240" height="340" rx="14" fill="#0A1E3C" stroke="#2DD4BF" strokeWidth="2.5" />
          <text x="640" y="125" textAnchor="middle" fill="#2DD4BF" fontWeight="bold" fontSize="13">OUTDOOR UNIT (چھت پر)</text>

          {/* Compressor and Dual Cap */}
          <circle cx="640" cy="200" r="35" fill="#163768" stroke="#EF4444" strokeWidth="2" />
          <text x="640" y="200" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="11">COMPRESSOR</text>
          <text x="640" y="215" textAnchor="middle" fill="#CBD5E1" fontSize="9">C - S - R</text>

          {/* Dual Capacitor */}
          <rect x="550" y="270" width="80" height="50" rx="6" fill="#0F294E" stroke="#FBBF24" />
          <text x="590" y="295" textAnchor="middle" fill="#FBBF24" fontSize="9" fontWeight="bold">50+5 μF</text>
          <text x="590" y="310" textAnchor="middle" fill="#FFF" fontSize="8">HERM / FAN</text>

          {/* Outdoor Fan & 4-Way Valve */}
          <rect x="650" y="270" width="90" height="50" rx="6" fill="#0F294E" stroke="#38BDF8" />
          <text x="695" y="295" textAnchor="middle" fill="#38BDF8" fontSize="9" fontWeight="bold">FAN & 4-WAY</text>

          {/* Connecting 5-Core Cable */}
          <path d="M 250 290 L 520 290" stroke="#EF4444" strokeWidth="3" />
          <text x="385" y="280" fill="#EF4444" textAnchor="middle" fontSize="10" fontWeight="bold">Wire 1: Compressor Live</text>
          <path d="M 250 320 L 520 320" stroke="#38BDF8" strokeWidth="3" strokeDasharray="6 3" />
          <text x="385" y="315" fill="#38BDF8" textAnchor="middle" fontSize="10" fontWeight="bold">Wire 2: Neutral Common</text>
          <path d="M 250 350 L 520 350" stroke="#EAB308" strokeWidth="3" />
          <text x="385" y="345" fill="#EAB308" textAnchor="middle" fontSize="10" fontWeight="bold">Wire 3: Fan Motor</text>
          <path d="M 250 380 L 520 380" stroke="#F97316" strokeWidth="3" />
          <text x="385" y="375" fill="#F97316" textAnchor="middle" fontSize="10" fontWeight="bold">Wire 4: 4-Way Heating Valve</text>
        </svg>
      );

    // ----------------------------------------------------
    // 18. SINGLE-PHASE CSR COMPRESSOR WIRING
    // ----------------------------------------------------
    case 'csr_compressor':
      return (
        <svg viewBox="0 0 780 460" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="740" height="42" rx="8" fill="#0A1E3C" stroke="#2DD4BF" strokeWidth="1.5" />
          <text x="40" y="42" fill="#2DD4BF" fontSize="15" fontWeight="bold">
            SINGLE-PHASE CSR COMPRESSOR WIRING (START/RUN CAP & POTENTIAL RELAY)
          </text>

          {/* Potential Starting Relay */}
          <rect x="60" y="100" width="200" height="180" rx="10" fill="#0F294E" stroke="#E8A85C" strokeWidth="2" />
          <text x="160" y="130" textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="12">POTENTIAL RELAY</text>
          <text x="160" y="150" textAnchor="middle" fill="#94A3B8" fontSize="10">High Starting Torque</text>
          <circle cx="100" cy="190" r="6" fill="#EF4444" />
          <text x="120" y="195" fill="#CBD5E1" fontSize="10">Pin 1 (Start Cap)</text>
          <circle cx="100" cy="230" r="6" fill="#F97316" />
          <text x="120" y="235" fill="#CBD5E1" fontSize="10">Pin 2 (Start Coil S)</text>
          <circle cx="100" cy="265" r="6" fill="#38BDF8" />
          <text x="120" y="270" fill="#CBD5E1" fontSize="10">Pin 5 (Neutral)</text>

          {/* Start and Run Capacitors */}
          <rect x="300" y="90" width="120" height="70" rx="6" fill="#163768" stroke="#EF4444" strokeWidth="1.5" />
          <text x="360" y="120" textAnchor="middle" fill="#EF4444" fontSize="10" fontWeight="bold">START CAPACITOR</text>
          <text x="360" y="140" textAnchor="middle" fill="#FFF" fontSize="9">150-200 μF (15kΩ Bleed)</text>

          <rect x="300" y="180" width="120" height="70" rx="6" fill="#163768" stroke="#38BDF8" strokeWidth="1.5" />
          <text x="360" y="210" textAnchor="middle" fill="#38BDF8" fontSize="10" fontWeight="bold">RUN CAPACITOR</text>
          <text x="360" y="230" textAnchor="middle" fill="#FFF" fontSize="9">45 μF Continuous</text>

          {/* Compressor Body & Pins C, S, R */}
          <circle cx="620" cy="200" r="75" fill="#0A1E3C" stroke="#2DD4BF" strokeWidth="3" />
          <text x="620" y="155" textAnchor="middle" fill="#2DD4BF" fontWeight="bold" fontSize="12">COMPRESSOR</text>

          <circle cx="620" cy="180" r="8" fill="#EF4444" />
          <text x="620" y="205" textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="11">C (Common)</text>

          <circle cx="580" cy="235" r="8" fill="#F97316" />
          <text x="580" y="260" textAnchor="middle" fill="#F97316" fontWeight="bold" fontSize="11">S (Start)</text>

          <circle cx="660" cy="235" r="8" fill="#38BDF8" />
          <text x="660" y="260" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="11">R (Run)</text>

          {/* Instructions Box */}
          <rect x="60" y="320" width="660" height="100" rx="8" fill="#0F294E" stroke="#1E4680" />
          <text x="80" y="345" fill="#E8A85C" fontSize="11" fontWeight="bold">CSR وائرنگ کا خلاصہ:</text>
          <text x="80" y="370" fill="#CBD5E1" fontSize="10">• اوور لوڈ پروٹیکٹر کے ذریعے فیز سیدھا کامن (C) پر جاتا ہے۔</text>
          <text x="80" y="390" fill="#CBD5E1" fontSize="10">• ریلے کے پوائنٹ 1 اور 2 سٹارٹ کپیسیٹر کو موٹر سٹارٹ ہوتے ہی 0.5 سیکنڈ میں سرکٹ سے کاٹ دیتے ہیں۔</text>
          <text x="80" y="410" fill="#38BDF8" fontSize="10">• رن کپیسیٹر مسلسل R اور S کے درمیان کام کرتا رہتا ہے۔</text>
        </svg>
      );

    // ----------------------------------------------------
    // 19. 3-PHASE CHILLER SAFETY LOOP
    // ----------------------------------------------------
    case 'chiller_safety':
      return (
        <svg viewBox="0 0 800 460" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#2DD4BF" strokeWidth="1.5" />
          <text x="40" y="42" fill="#2DD4BF" fontSize="15" fontWeight="bold">
            3-PHASE INDUSTRIAL CHILLER SAFETY INTERLOCK LOOP (SERIES SAFETY CHAIN)
          </text>

          {/* Series safety switches chain */}
          <rect x="40" y="120" width="110" height="120" rx="8" fill="#0F294E" stroke="#EF4444" strokeWidth="2" />
          <text x="95" y="150" textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="11">LP SWITCH</text>
          <text x="95" y="170" textAnchor="middle" fill="#FFF" fontSize="9">Low Pressure</text>
          <text x="95" y="190" textAnchor="middle" fill="#94A3B8" fontSize="8">Gas Leakage</text>

          <rect x="180" y="120" width="110" height="120" rx="8" fill="#0F294E" stroke="#EF4444" strokeWidth="2" />
          <text x="235" y="150" textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="11">HP SWITCH</text>
          <text x="235" y="170" textAnchor="middle" fill="#FFF" fontSize="9">High Pressure</text>
          <text x="235" y="190" textAnchor="middle" fill="#94A3B8" fontSize="8">Fan Failure</text>

          <rect x="320" y="120" width="120" height="120" rx="8" fill="#0F294E" stroke="#FBBF24" strokeWidth="2" />
          <text x="380" y="150" textAnchor="middle" fill="#FBBF24" fontWeight="bold" fontSize="11">OIL DIFF SW</text>
          <text x="380" y="170" textAnchor="middle" fill="#FFF" fontSize="9">Differential</text>
          <text x="380" y="190" textAnchor="middle" fill="#94A3B8" fontSize="8">Lubrication Guard</text>

          <rect x="470" y="120" width="120" height="120" rx="8" fill="#0F294E" stroke="#38BDF8" strokeWidth="2" />
          <text x="530" y="150" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="11">FLOW SWITCH</text>
          <text x="530" y="170" textAnchor="middle" fill="#FFF" fontSize="9">Water Paddle</text>
          <text x="530" y="190" textAnchor="middle" fill="#94A3B8" fontSize="8">Chilled Water Circ</text>

          <rect x="620" y="120" width="120" height="120" rx="8" fill="#0F294E" stroke="#10B981" strokeWidth="2" />
          <text x="680" y="150" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="11">ANTI-FREEZE</text>
          <text x="680" y="170" textAnchor="middle" fill="#FFF" fontSize="9">Thermostat +3°C</text>
          <text x="680" y="190" textAnchor="middle" fill="#94A3B8" fontSize="8">Burst Protection</text>

          {/* Series Red Wire running through all switches */}
          <line x1="20" y1="210" x2="40" y2="210" stroke="#EF4444" strokeWidth="4" />
          <line x1="150" y1="210" x2="180" y2="210" stroke="#EF4444" strokeWidth="4" />
          <line x1="290" y1="210" x2="320" y2="210" stroke="#EF4444" strokeWidth="4" />
          <line x1="440" y1="210" x2="470" y2="210" stroke="#EF4444" strokeWidth="4" />
          <line x1="590" y1="210" x2="620" y2="210" stroke="#EF4444" strokeWidth="4" />

          {/* Compressor Contactor Coil KM1 */}
          <circle cx="680" cy="330" r="30" fill="#163768" stroke="#10B981" strokeWidth="3" />
          <text x="680" y="335" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="11">KM1 COIL</text>
          <path d="M 680 240 L 680 300" stroke="#EF4444" strokeWidth="4" />
          <line x1="680" y1="360" x2="680" y2="400" stroke="#38BDF8" strokeWidth="4" />
          <text x="690" y="415" fill="#38BDF8" fontSize="10">Neutral Return</text>

          {/* Critical Warning */}
          <rect x="40" y="290" width="560" height="90" rx="8" fill="#1C1917" stroke="#DC2626" />
          <text x="60" y="320" fill="#EF4444" fontSize="11" fontWeight="bold">
            ⚠️ لازمی سیفٹی انتباہ: یہ تمام 5 سوئچز ایک ہی سیریز میں جڑے ہیں۔
          </text>
          <text x="60" y="345" fill="#CBD5E1" fontSize="10">
            اگر کسی ایک سوئچ میں بھی فالٹ آئے (مثلاً پانی کا پمپ بند ہو یا گیس کا پریشر بڑھے)
          </text>
          <text x="60" y="365" fill="#CBD5E1" fontSize="10">
            تو کمپریسر کنٹیکٹر فوراً گر جائے گا تاکہ لاکھوں روپے کے پائپ اور موٹر تباہ ہونے سے بچ سکیں۔
          </text>
        </svg>
      );

    // ----------------------------------------------------
    // 20. 7-WIRE DIGITAL THERMOSTAT WIRING
    // ----------------------------------------------------
    case 'thermostat_7wire':
      return (
        <svg viewBox="0 0 780 460" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="740" height="42" rx="8" fill="#0A1E3C" stroke="#2DD4BF" strokeWidth="1.5" />
          <text x="40" y="42" fill="#2DD4BF" fontSize="15" fontWeight="bold">
            7-WIRE DIGITAL PROGRAMMABLE THERMOSTAT STANDARD COLOR CODE & CONNECTIONS
          </text>

          {/* Thermostat Subbase */}
          <rect x="50" y="90" width="300" height="340" rx="14" fill="#0F294E" stroke="#38BDF8" strokeWidth="2.5" />
          <text x="200" y="125" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="13">THERMOSTAT BASEPLATE</text>

          {/* Terminals list */}
          {[
            { tag: 'R / Rc', name: '24V Power In', color: '#EF4444', y: 160 },
            { tag: 'C', name: '24V Common Return', color: '#38BDF8', y: 200 },
            { tag: 'Y / Y1', name: 'Cooling Stage 1', color: '#EAB308', y: 240 },
            { tag: 'W / W1', name: 'Heating Stage 1', color: '#FFFFFF', y: 280 },
            { tag: 'G', name: 'Indoor Fan Blower', color: '#10B981', y: 320 },
            { tag: 'O / B', name: 'Reversing Valve (Heat Pump)', color: '#F97316', y: 360 },
            { tag: 'Aux / E', name: 'Emergency Strip Heat', color: '#8B4513', y: 400 },
          ].map((t) => (
            <g key={t.tag}>
              <circle cx="85" cy={t.y} r="8" fill={t.color} />
              <text x="110" y={t.y + 4} fill={t.color} fontWeight="bold" fontSize="12">{t.tag}</text>
              <text x="170" y={t.y + 4} fill="#CBD5E1" fontSize="10">{t.name}</text>
            </g>
          ))}

          {/* Air Handler Terminal Board */}
          <rect x="440" y="90" width="300" height="340" rx="14" fill="#0A1E3C" stroke="#E8A85C" strokeWidth="2.5" />
          <text x="590" y="125" textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="13">AIR HANDLER / INDOOR PCB</text>
          <text x="590" y="150" textAnchor="middle" fill="#94A3B8" fontSize="10">24V Transformer Terminals</text>

          <path d="M 85 160 L 440 160" stroke="#EF4444" strokeWidth="3" />
          <path d="M 85 200 L 440 200" stroke="#38BDF8" strokeWidth="3" strokeDasharray="6 3" />
          <path d="M 85 240 L 440 240" stroke="#EAB308" strokeWidth="3" />
          <path d="M 85 280 L 440 280" stroke="#FFFFFF" strokeWidth="3" />
          <path d="M 85 320 L 440 320" stroke="#10B981" strokeWidth="3" />
          <path d="M 85 360 L 440 360" stroke="#F97316" strokeWidth="3" />
          <path d="M 85 400 L 440 400" stroke="#8B4513" strokeWidth="3" />
        </svg>
      );

    // ----------------------------------------------------
    // 21. BMS DDC PANEL LOOP WIRING
    // ----------------------------------------------------
    case 'bms_ddc_loop':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#A78BFA" strokeWidth="1.5" />
          <text x="40" y="42" fill="#A78BFA" fontSize="15" fontWeight="bold">
            BMS DDC CONTROLLER PANEL LOOP WIRING (SENSORS, ACTUATORS & BACNET)
          </text>

          {/* Central DDC Controller Box */}
          <rect x="250" y="80" width="280" height="360" rx="14" fill="#0A1E3C" stroke="#A78BFA" strokeWidth="3" />
          <rect x="270" y="100" width="240" height="40" rx="6" fill="#163768" />
          <text x="390" y="125" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="13">
            DDC CONTROLLER (BACnet)
          </text>

          {/* Left: Universal Inputs (UI) */}
          <rect x="40" y="100" width="160" height="140" rx="8" fill="#0F294E" stroke="#38BDF8" strokeWidth="2" />
          <text x="120" y="125" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="11">PT1000 TEMP SENSOR</text>
          <text x="120" y="145" textAnchor="middle" fill="#FFF" fontSize="9">Chilled Water Pipe</text>
          <line x1="200" y1="170" x2="250" y2="170" stroke="#38BDF8" strokeWidth="3" />
          <text x="225" y="160" fill="#38BDF8" fontSize="9">UI-1</text>

          <rect x="40" y="270" width="160" height="140" rx="8" fill="#0F294E" stroke="#38BDF8" strokeWidth="2" />
          <text x="120" y="295" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="11">HUMIDITY SENSOR</text>
          <text x="120" y="315" textAnchor="middle" fill="#FFF" fontSize="9">0-10V DC Duct Sensor</text>
          <line x1="200" y1="340" x2="250" y2="340" stroke="#38BDF8" strokeWidth="3" />
          <text x="225" y="330" fill="#38BDF8" fontSize="9">UI-2</text>

          {/* Right: Analog Output (AO) Modulating Actuator */}
          <rect x="580" y="100" width="180" height="140" rx="8" fill="#0F294E" stroke="#E8A85C" strokeWidth="2" />
          <text x="670" y="125" textAnchor="middle" fill="#E8A85C" fontWeight="bold" fontSize="11">WATER VALVE ACTUATOR</text>
          <text x="670" y="145" textAnchor="middle" fill="#FFF" fontSize="9">0-10V Modulating (Belimo)</text>
          <line x1="530" y1="170" x2="580" y2="170" stroke="#E8A85C" strokeWidth="3" />
          <text x="545" y="160" fill="#E8A85C" fontSize="9">AO-1</text>

          {/* Right: Digital Output (DO) Pump Relay */}
          <rect x="580" y="270" width="180" height="140" rx="8" fill="#0F294E" stroke="#10B981" strokeWidth="2" />
          <text x="670" y="295" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="11">PUMP START RELAY</text>
          <text x="670" y="315" textAnchor="middle" fill="#FFF" fontSize="9">24V DC Relay Coil (DO-1)</text>
          <line x1="530" y1="340" x2="580" y2="340" stroke="#10B981" strokeWidth="3" />
          <text x="545" y="330" fill="#10B981" fontSize="9">DO-1</text>
        </svg>
      );

    // ----------------------------------------------------
    // 22. BMS ACCESS CONTROL & FIRE ALARM INTERLOCK
    // ----------------------------------------------------
    case 'bms_access_fire':
      return (
        <svg viewBox="0 0 780 460" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="740" height="42" rx="8" fill="#0A1E3C" stroke="#F87171" strokeWidth="1.5" />
          <text x="40" y="42" fill="#F87171" fontSize="15" fontWeight="bold">
            ACCESS CONTROL EM-LOCK & FIRE ALARM FAIL-SAFE INTERLOCK
          </text>

          {/* 12V DC Power Supply */}
          <rect x="50" y="120" width="140" height="160" rx="8" fill="#0F294E" stroke="#38BDF8" strokeWidth="2" />
          <text x="120" y="150" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="12">12V DC SMPS</text>
          <text x="120" y="170" textAnchor="middle" fill="#94A3B8" fontSize="10">Battery Backup</text>
          <circle cx="90" cy="220" r="6" fill="#EF4444" />
          <text x="90" y="245" textAnchor="middle" fill="#EF4444" fontSize="9">+12V</text>
          <circle cx="150" cy="220" r="6" fill="#1E3A8A" />
          <text x="150" y="245" textAnchor="middle" fill="#38BDF8" fontSize="9">0V</text>

          {/* Fire Alarm Panel NC Contact */}
          <rect x="250" y="120" width="140" height="160" rx="8" fill="#7F1D1D" stroke="#EF4444" strokeWidth="2" />
          <text x="320" y="150" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="11">FIRE PANEL (FACP)</text>
          <text x="320" y="170" textAnchor="middle" fill="#FECACA" fontSize="9">NC Dry Contact</text>
          <text x="320" y="210" textAnchor="middle" fill="#FFF" fontSize="9">Opens on Fire Alarm</text>

          {/* Green Break Glass */}
          <rect x="440" y="120" width="120" height="160" rx="8" fill="#064E3B" stroke="#10B981" strokeWidth="2" />
          <text x="500" y="150" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="10">BREAK GLASS</text>
          <text x="500" y="170" textAnchor="middle" fill="#A7F3D0" fontSize="9">Manual Override</text>

          {/* Electromagnetic Lock (EM-Lock) */}
          <rect x="610" y="120" width="130" height="160" rx="8" fill="#0A1E3C" stroke="#FBBF24" strokeWidth="2.5" />
          <text x="675" y="150" textAnchor="middle" fill="#FBBF24" fontWeight="bold" fontSize="11">EM-LOCK 600lbs</text>
          <text x="675" y="170" textAnchor="middle" fill="#FFF" fontSize="9">Fail-Safe</text>
          <text x="675" y="210" textAnchor="middle" fill="#94A3B8" fontSize="8">Power Drops = Open</text>

          {/* Series +12V Wire */}
          <path d="M 90 220 L 250 220" stroke="#EF4444" strokeWidth="3.5" />
          <path d="M 390 220 L 440 220" stroke="#EF4444" strokeWidth="3.5" />
          <path d="M 560 220 L 610 220" stroke="#EF4444" strokeWidth="3.5" />

          {/* Direct 0V return line */}
          <path d="M 150 226 L 150 340 L 675 340 L 675 280" stroke="#38BDF8" strokeWidth="3" strokeDasharray="6 3" fill="none" />
          <text x="400" y="360" textAnchor="middle" fill="#38BDF8" fontSize="11">Direct 0V GND Return</text>

          {/* Safety Rule Box */}
          <rect x="40" y="390" width="700" height="40" rx="6" fill="#1C1917" stroke="#DC2626" />
          <text x="50" y="415" fill="#EF4444" fontSize="11" fontWeight="bold">
            ⚠️ قانونِ زندگی (NFPA 101): فائر الارم بجنے پر تمام میگنیٹک دروازوں کی پاور فوری کٹ کر خود بخود ان لاک ہونا قانونی طور پر لازمی ہے۔
          </text>
        </svg>
      );

    // ----------------------------------------------------
    // 23. CONVENTIONAL FIRE ALARM ZONE WIRING
    // ----------------------------------------------------
    case 'fire_conventional_zone':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#F87171" strokeWidth="1.5" />
          <text x="40" y="42" fill="#F87171" fontSize="15" fontWeight="bold">
            CONVENTIONAL 2-WIRE FIRE ALARM ZONE WIRING WITH 4.7kΩ EOL RESISTOR
          </text>

          {/* FACP Panel */}
          <rect x="40" y="90" width="160" height="240" rx="10" fill="#7F1D1D" stroke="#EF4444" strokeWidth="2.5" />
          <text x="120" y="125" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="13">FIRE PANEL (FACP)</text>
          <text x="120" y="145" textAnchor="middle" fill="#FECACA" fontSize="10">Conventional Zone 1</text>
          <circle cx="80" cy="180" r="5" fill="#EF4444" />
          <text x="100" y="184" fill="#FFF" fontSize="10">Z1 (+)</text>
          <circle cx="80" cy="220" r="5" fill="#1E3A8A" />
          <text x="100" y="224" fill="#38BDF8" fontSize="10">Z1 (-)</text>

          {/* Detectors Row */}
          {[
            { id: 1, name: 'SMOKE 1', x: 260 },
            { id: 2, name: 'SMOKE 2', x: 420 },
            { id: 3, name: 'MANUAL CALL POINT', x: 580 },
          ].map((d) => (
            <g key={d.id}>
              <circle cx={d.x + 50} cy={180} r="35" fill="#0F294E" stroke="#EF4444" strokeWidth="2.5" />
              <text x={d.x + 50} y={185} textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="9">{d.name}</text>
              <text x={d.x + 50} y={240} textAnchor="middle" fill="#94A3B8" fontSize="9">Diode Base</text>
            </g>
          ))}

          {/* End-Of-Line (EOL) Resistor at last point */}
          <rect x="710" y="160" width="40" height="40" rx="4" fill="#FBBF24" stroke="#D97706" />
          <text x="730" y="185" textAnchor="middle" fill="#000" fontWeight="bold" fontSize="10">4.7kΩ</text>
          <text x="730" y="220" textAnchor="middle" fill="#FBBF24" fontSize="9" fontWeight="bold">EOL RESISTOR</text>

          {/* Wire Lines */}
          <line x1="85" y1="180" x2="710" y2="180" stroke="#EF4444" strokeWidth="3" />
          <line x1="85" y1="220" x2="710" y2="200" stroke="#38BDF8" strokeWidth="3" />

          {/* Separate Sounder Loop at bottom */}
          <rect x="40" y="360" width="720" height="80" rx="8" fill="#0F294E" stroke="#E8A85C" />
          <text x="60" y="390" fill="#E8A85C" fontWeight="bold" fontSize="11">
            24V DC Polarized Sounder / Hooter Circuit (الگ ساؤنڈر سرکٹ):
          </text>
          <text x="60" y="415" fill="#CBD5E1" fontSize="10">
            ساؤنڈر اور ہاٹرز کیلئے پینل سے الگ 24V ڈی سی ریورس پولیریٹی سرکٹ نکلتا ہے جو فائر سگنل پر ایکٹیو ہوتا ہے۔
          </text>
        </svg>
      );

    // ----------------------------------------------------
    // 24. ADDRESSABLE FIRE ALARM CLASS A SLC LOOP
    // ----------------------------------------------------
    case 'fire_addressable_loop':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#F87171" strokeWidth="1.5" />
          <text x="40" y="42" fill="#F87171" fontSize="15" fontWeight="bold">
            ADDRESSABLE FIRE ALARM CLASS A SLC RING LOOP (BIDIRECTIONAL)
          </text>

          {/* Addressable Panel */}
          <rect x="50" y="120" width="180" height="260" rx="12" fill="#7F1D1D" stroke="#EF4444" strokeWidth="3" />
          <text x="140" y="155" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="13">ADDRESSABLE FACP</text>
          <text x="140" y="175" textAnchor="middle" fill="#FECACA" fontSize="10">SLC Loop 1 (Class A)</text>
          <circle cx="80" cy="220" r="5" fill="#10B981" />
          <text x="95" y="224" fill="#FFF" fontSize="9">Loop Out (+)</text>
          <circle cx="80" cy="250" r="5" fill="#38BDF8" />
          <text x="95" y="254" fill="#FFF" fontSize="9">Loop Out (-)</text>
          <circle cx="80" cy="300" r="5" fill="#FBBF24" />
          <text x="95" y="304" fill="#FFF" fontSize="9">Loop In (+)</text>
          <circle cx="80" cy="330" r="5" fill="#38BDF8" />
          <text x="95" y="334" fill="#FFF" fontSize="9">Loop In (-)</text>

          {/* Ring Devices */}
          <circle cx="350" cy="120" r="32" fill="#0F294E" stroke="#10B981" strokeWidth="2.5" />
          <text x="350" y="120" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="9">SMOKE 01</text>
          <text x="350" y="135" textAnchor="middle" fill="#10B981" fontSize="8">Addr 01</text>

          <circle cx="550" cy="120" r="32" fill="#0F294E" stroke="#10B981" strokeWidth="2.5" />
          <text x="550" y="120" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="9">SMOKE 02</text>
          <text x="550" y="135" textAnchor="middle" fill="#10B981" fontSize="8">Addr 02</text>

          <rect x="650" y="210" width="90" height="60" rx="8" fill="#064E3B" stroke="#10B981" strokeWidth="2" />
          <text x="695" y="235" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="9">MCP 03</text>
          <text x="695" y="255" textAnchor="middle" fill="#A7F3D0" fontSize="8">Call Point</text>

          <rect x="520" y="330" width="120" height="60" rx="8" fill="#163768" stroke="#FBBF24" strokeWidth="2" />
          <text x="580" y="355" textAnchor="middle" fill="#FBBF24" fontWeight="bold" fontSize="9">CONTROL MODULE</text>
          <text x="580" y="375" textAnchor="middle" fill="#FFF" fontSize="8">Lift Recall Relay</text>

          <circle cx="350" cy="360" r="32" fill="#0F294E" stroke="#10B981" strokeWidth="2.5" />
          <text x="350" y="360" textAnchor="middle" fill="#FFF" fontWeight="bold" fontSize="9">SMOKE 05</text>
          <text x="350" y="375" textAnchor="middle" fill="#10B981" fontSize="8">Addr 05</text>

          {/* Complete Ring Loop lines */}
          <path d="M 85 220 L 320 120 L 520 120 L 650 230 L 640 360 L 380 360 L 85 300" stroke="#10B981" strokeWidth="3" fill="none" />
          <text x="450" y="240" textAnchor="middle" fill="#10B981" fontSize="12" fontWeight="bold">
            Fault-Tolerant Class A Loop (دونوں طرف سے سگنل گردش کرتا ہے)
          </text>
        </svg>
      );

    // ----------------------------------------------------
    // 25. ELEVATOR ELECTRICAL SAFETY CHAIN
    // ----------------------------------------------------
    case 'lift_safety_chain':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#FB923C" strokeWidth="1.5" />
          <text x="40" y="42" fill="#FB923C" fontSize="15" fontWeight="bold">
            ELEVATOR 110V AC SAFETY CIRCUIT CHAIN (EN 81-20 MANDATORY SERIES CHAIN)
          </text>

          {/* 110V AC Safety Transformer */}
          <rect x="40" y="90" width="130" height="110" rx="8" fill="#0F294E" stroke="#38BDF8" strokeWidth="2" />
          <text x="105" y="125" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="11">110V AC XFMR</text>
          <text x="105" y="145" textAnchor="middle" fill="#FFF" fontSize="9">Safety Supply</text>

          {/* Switches in Series */}
          {[
            { tag: 'GOV', name: 'Overspeed Governor', x: 200, y: 110 },
            { tag: 'FINAL', name: 'Top Final Limit', x: 340, y: 110 },
            { tag: 'CAR STOP', name: 'Car Top Inspection Stop', x: 480, y: 110 },
            { tag: 'GATE', name: 'Car Door Gate Switch', x: 620, y: 110 },
            { tag: 'DOOR 1', name: 'Floor 1 Landing Interlock', x: 620, y: 240 },
            { tag: 'DOOR 2', name: 'Floor 2 Landing Interlock', x: 480, y: 240 },
            { tag: 'PIT STOP', name: 'Bottom Pit Emergency Stop', x: 340, y: 240 },
            { tag: 'BUFFER', name: 'Pit Buffer Switch', x: 200, y: 240 },
          ].map((s) => (
            <g key={s.tag}>
              <rect x={s.x} y={s.y} width="115" height="70" rx="6" fill="#163768" stroke="#EF4444" strokeWidth="1.5" />
              <text x={s.x + 57} y={s.y + 25} textAnchor="middle" fill="#EF4444" fontWeight="bold" fontSize="10">{s.tag}</text>
              <text x={s.x + 57} y={s.y + 45} textAnchor="middle" fill="#FFF" fontSize="8">{s.name}</text>
            </g>
          ))}

          {/* Series Connecting Red Line */}
          <line x1="170" y1="145" x2="200" y2="145" stroke="#EF4444" strokeWidth="3" />
          <line x1="315" y1="145" x2="340" y2="145" stroke="#EF4444" strokeWidth="3" />
          <line x1="455" y1="145" x2="480" y2="145" stroke="#EF4444" strokeWidth="3" />
          <line x1="595" y1="145" x2="620" y2="145" stroke="#EF4444" strokeWidth="3" />
          <path d="M 680 180 L 680 240" stroke="#EF4444" strokeWidth="3" />
          <line x1="620" y1="275" x2="595" y2="275" stroke="#EF4444" strokeWidth="3" />
          <line x1="480" y1="275" x2="455" y2="275" stroke="#EF4444" strokeWidth="3" />
          <line x1="340" y1="275" x2="315" y2="275" stroke="#EF4444" strokeWidth="3" />

          {/* Final Safety Contactor Coil */}
          <circle cx="100" cy="275" r="30" fill="#0A1E3C" stroke="#10B981" strokeWidth="3" />
          <text x="100" y="275" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="10">SAFETY</text>
          <text x="100" y="290" textAnchor="middle" fill="#FFF" fontSize="9">CONTACTOR</text>
          <line x1="200" y1="275" x2="130" y2="275" stroke="#EF4444" strokeWidth="3" />

          {/* Warning banner */}
          <rect x="40" y="370" width="720" height="60" rx="8" fill="#1C1917" stroke="#DC2626" />
          <text x="60" y="395" fill="#EF4444" fontSize="11" fontWeight="bold">
            ⚠️ انتہائی اہم وارننگ: لفٹ کا کوئی بھی ڈور سوئچ یا لمٹ سوئچ ڈائریکٹ (بائی پاس) نہ کریں۔
          </text>
          <text x="60" y="415" fill="#CBD5E1" fontSize="10">
            ایک بھی سوئچ کھلنے پر مین سیفٹی کنٹیکٹر فوری ڈراپ ہوتا ہے اور لفٹ کی مکینکل بریک لگ جاتی ہے۔
          </text>
        </svg>
      );

    // ----------------------------------------------------
    // 26. ELEVATOR ARD (AUTOMATIC RESCUE DEVICE)
    // ----------------------------------------------------
    case 'lift_ard_power':
      return (
        <svg viewBox="0 0 800 480" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect width="100%" height="100%" fill="#071326" />
          <rect x="20" y="15" width="760" height="42" rx="8" fill="#0A1E3C" stroke="#FB923C" strokeWidth="1.5" />
          <text x="40" y="42" fill="#FB923C" fontSize="15" fontWeight="bold">
            ELEVATOR ARD (AUTOMATIC RESCUE DEVICE) BATTERY BACKUP WIRING
          </text>

          {/* 48V/96V Battery Bank */}
          <rect x="40" y="90" width="160" height="150" rx="8" fill="#0F294E" stroke="#10B981" strokeWidth="2" />
          <text x="120" y="125" textAnchor="middle" fill="#10B981" fontWeight="bold" fontSize="12">SLA BATTERIES</text>
          <text x="120" y="145" textAnchor="middle" fill="#FFF" fontSize="10">4x 12V 18Ah (48V Bank)</text>
          <circle cx="80" cy="185" r="6" fill="#10B981" />
          <text x="80" y="210" textAnchor="middle" fill="#10B981" fontSize="9">+48V DC</text>
          <circle cx="140" cy="185" r="6" fill="#1E3A8A" />
          <text x="140" y="210" textAnchor="middle" fill="#38BDF8" fontSize="9">0V GND</text>

          {/* Central ARD Controller Box */}
          <rect x="250" y="90" width="260" height="250" rx="12" fill="#0A1E3C" stroke="#FB923C" strokeWidth="3" />
          <rect x="270" y="110" width="220" height="40" rx="6" fill="#163768" />
          <text x="380" y="135" textAnchor="middle" fill="#FB923C" fontWeight="bold" fontSize="13">ARD RESCUE UNIT</text>
          <text x="380" y="175" textAnchor="middle" fill="#FFF" fontSize="11">Blackout Sensing Relay</text>
          <text x="380" y="195" textAnchor="middle" fill="#94A3B8" fontSize="10">3-Phase 400V Inverter</text>
          <text x="380" y="215" textAnchor="middle" fill="#FBBF24" fontSize="10">Brake Release Coil Output</text>
          <text x="380" y="235" textAnchor="middle" fill="#10B981" fontSize="10">Door Open Signal Trigger</text>

          {/* Lift Cabin & VVVF Drive */}
          <rect x="560" y="90" width="200" height="250" rx="12" fill="#0F294E" stroke="#38BDF8" strokeWidth="2.5" />
          <text x="660" y="125" textAnchor="middle" fill="#38BDF8" fontWeight="bold" fontSize="13">ELEVATOR CABIN</text>
          <text x="660" y="150" textAnchor="middle" fill="#FFF" fontSize="10">VVVF Motor Drive</text>
          <text x="660" y="200" textAnchor="middle" fill="#10B981" fontSize="11" fontWeight="bold">Nearest Floor Leveling</text>
          <text x="660" y="225" textAnchor="middle" fill="#FBBF24" fontSize="10">Doors Open Automatically</text>

          {/* Lines */}
          <path d="M 140 185 L 250 185" stroke="#10B981" strokeWidth="4" />
          <path d="M 510 200 L 560 200" stroke="#38BDF8" strokeWidth="4" />

          {/* Bottom explanation */}
          <rect x="40" y="370" width="720" height="60" rx="8" fill="#0F294E" stroke="#1E4680" />
          <text x="60" y="395" fill="#E8A85C" fontSize="11" fontWeight="bold">اے آر ڈی (ARD) کا خودکار ریسکیو طریقہ کار:</text>
          <text x="60" y="415" fill="#CBD5E1" fontSize="10">
            واپڈا بند ہوتے ہی 10 سیکنڈ میں اے آر ڈی بیٹریاں استعمال کر کے کیبن کو آہستہ سے قریبی فلور پر لا کر مسافروں کو باہر نکال دیتا ہے۔
          </text>
        </svg>
      );

    // ----------------------------------------------------
    // DEFAULT GENERIC SCHEMATIC
    // ----------------------------------------------------
    default:
      return (
        <svg viewBox="0 0 760 380" className={`w-full h-auto bg-[#071326] rounded-xl border border-[#1E4680] ${className}`}>
          <rect x="20" y="20" width="720" height="340" rx="12" fill="#0A1E3C" stroke="#E8A85C" strokeWidth="2" />
          <circle cx="380" cy="180" r="70" fill="none" stroke="#E8A85C" strokeWidth="2" strokeDasharray="8 6" />
          <circle cx="380" cy="180" r="40" fill="#0F294E" stroke="#38BDF8" strokeWidth="3" />
          <text x="380" y="185" textAnchor="middle" fill="#E8A85C" fontSize="16" fontWeight="bold">
            {type.toUpperCase().replace(/_/g, ' ')}
          </text>
          <text x="380" y="280" textAnchor="middle" fill="#94A3B8" fontSize="12">
            Interactive High-Definition Vector Schematic
          </text>
        </svg>
      );
  }
};
