import React, { useState, useRef, useEffect } from 'react';
import { X, ZoomIn, ZoomOut, RotateCcw, Maximize2, Minimize2, Move, Download, Zap } from 'lucide-react';
import { DiagramRenderer } from './DiagramRenderer';
import { DiagramItem } from '../types';
import { exportDiagramToPdf } from '../utils/pdfExport';

interface DiagramZoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  titleUrdu: string;
  diagramType: string;
  item?: DiagramItem;
}

export const DiagramZoomModal: React.FC<DiagramZoomModalProps> = ({
  isOpen,
  onClose,
  title,
  titleUrdu,
  diagramType,
  item,
}) => {
  const [scale, setScale] = useState<number>(1);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const initialTouchDistance = useRef<number | null>(null);

  useEffect(() => {
    if (isOpen) {
      setScale(1);
      setPosition({ x: 0, y: 0 });
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Zoom controls
  const handleZoomIn = () => setScale((s) => Math.min(s + 0.35, 4.0));
  const handleZoomOut = () => setScale((s) => Math.max(s - 0.35, 0.6));
  const handleReset = () => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  };

  // Mouse pan drag
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - position.x, y: e.clientY - position.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    }
  };

  const handleMouseUp = () => setIsDragging(false);

  // Wheel zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (e.deltaY < 0) {
      setScale((s) => Math.min(s + 0.15, 4.0));
    } else {
      setScale((s) => Math.max(s - 0.15, 0.6));
    }
  };

  // Touch pinch to zoom & pan
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      setDragStart({ x: e.touches[0].clientX - position.x, y: e.touches[0].clientY - position.y });
    } else if (e.touches.length === 2) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      initialTouchDistance.current = dist;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 1 && isDragging) {
      setPosition({
        x: e.touches[0].clientX - dragStart.x,
        y: e.touches[0].clientY - dragStart.y,
      });
    } else if (e.touches.length === 2 && initialTouchDistance.current !== null) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      const factor = dist / initialTouchDistance.current;
      setScale((s) => Math.min(Math.max(s * (1 + (factor - 1) * 0.05), 0.6), 4.0));
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    initialTouchDistance.current = null;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-2 sm:p-4 animate-fadeIn">
      <div
        className={`w-full rounded-2xl bg-[#0A1E3C] border-2 border-[#E8A85C] shadow-2xl flex flex-col overflow-hidden transition-all duration-300 ${
          isFullscreen ? 'h-full max-w-none rounded-none' : 'max-w-5xl h-[88vh]'
        }`}
      >
        {/* Header Toolbar */}
        <div className="px-4 py-3 bg-[#0F294E] border-b border-[#1E4680] flex items-center justify-between z-10">
          <div className="flex-1 min-w-0 pr-2">
            <h3 className="font-bold text-base sm:text-lg text-white truncate font-sans">{title}</h3>
            <p className="text-xs text-[#E8A85C] font-urdu truncate">{titleUrdu}</p>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <div className="flex items-center bg-[#071326] border border-[#1E4680] rounded-xl p-1 text-slate-300">
              <button
                onClick={handleZoomOut}
                title="Zoom Out (-)"
                className="p-1.5 hover:text-white hover:bg-[#163768] rounded-lg transition cursor-pointer"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="px-2 font-mono text-xs font-bold text-[#E8A85C] min-w-[48px] text-center">
                {Math.round(scale * 100)}%
              </span>
              <button
                onClick={handleZoomIn}
                title="Zoom In (+)"
                className="p-1.5 hover:text-white hover:bg-[#163768] rounded-lg transition cursor-pointer"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={handleReset}
                title="Reset (100%)"
                className="p-1.5 hover:text-white hover:bg-[#163768] rounded-lg transition border-l border-slate-700 ml-1 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>

            {/* Simulation Toggle */}
            <button
              onClick={() => setIsSimulating(!isSimulating)}
              title="Simulate Power Flow"
              className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer ${
                isSimulating
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500'
                  : 'bg-[#163768] text-slate-300 border-[#1E4680] hover:text-white'
              }`}
            >
              <Zap className={`w-3.5 h-3.5 ${isSimulating ? 'text-emerald-400 animate-pulse' : 'text-[#38BDF8]'}`} />
              <span className="hidden sm:inline">{isSimulating ? 'Power ON' : 'Simulate'}</span>
            </button>

            {/* Download as PDF Button */}
            {item && (
              <button
                onClick={() => exportDiagramToPdf(item)}
                title="Download Diagram as Professional PDF (PDF محفوظ کریں)"
                className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-[#B87333]/30 to-[#E8A85C]/30 hover:from-[#B87333]/50 hover:to-[#E8A85C]/50 text-[#E8A85C] border border-[#E8A85C]/50 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Download PDF</span>
              </button>
            )}

            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
              className="p-2 rounded-xl bg-[#163768] hover:bg-[#1E4680] text-slate-200 border border-[#1E4680] transition cursor-pointer hidden sm:block"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <button
              onClick={onClose}
              title="Close"
              className="p-2 rounded-xl bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-700/60 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Viewport Canvas with Drag / Zoom */}
        <div
          ref={containerRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onWheel={handleWheel}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          className="flex-1 overflow-hidden relative flex items-center justify-center cursor-grab active:cursor-grabbing bg-[#050F1E] select-none touch-none"
        >
          {/* Zoom Instructions Overlay */}
          <div className="absolute top-3 left-3 z-10 flex items-center gap-2 pointer-events-none opacity-70 bg-black/60 px-3 py-1.5 rounded-full text-[11px] text-slate-300">
            <Move className="w-3.5 h-3.5 text-[#E8A85C]" />
            <span>Pinch or wheel to zoom • Drag to pan (کھینچ کر بڑا کریں)</span>
          </div>

          {/* Interactive Transform Container */}
          <div
            style={{
              transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
              transformOrigin: 'center center',
              transition: isDragging ? 'none' : 'transform 0.1s ease-out',
            }}
            className="w-full max-w-4xl p-4 flex items-center justify-center pointer-events-none"
          >
            <DiagramRenderer type={diagramType} isSimulating={isSimulating} className="shadow-2xl pointer-events-auto" />
          </div>
        </div>

        {/* Bottom Status bar */}
        <div className="px-4 py-2 bg-[#0A1E3C] border-t border-[#1E4680] text-xs text-slate-400 flex items-center justify-between">
          <span className="text-[#E8A85C] font-semibold">HD Vector Vectorized Diagram</span>
          <span className="font-urdu">شاہد الیکٹریشن - واضح اور زوم ایبل وائرنگ ڈایاگرام</span>
        </div>
      </div>
    </div>
  );
};
