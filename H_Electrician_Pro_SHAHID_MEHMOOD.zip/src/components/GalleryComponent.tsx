import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  X,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Download,
  Zap,
  Info,
  Maximize2,
  CheckCircle,
  AlertTriangle,
  Move,
} from 'lucide-react';
import { DiagramItem } from '../types';
import { DiagramRenderer } from './DiagramRenderer';
import { exportDiagramToPdf } from '../utils/pdfExport';

interface GalleryComponentProps {
  isOpen: boolean;
  onClose: () => void;
  items: DiagramItem[];
  initialIndex?: number;
  onSelectIndex?: (index: number) => void;
}

export const GalleryComponent: React.FC<GalleryComponentProps> = ({
  isOpen,
  onClose,
  items,
  initialIndex = 0,
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(initialIndex);
  const [scale, setScale] = useState<number>(1);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [showDetails, setShowDetails] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  // Touch gesture state
  const touchStartX = useRef<number>(0);
  const touchStartY = useRef<number>(0);
  const initialPinchDist = useRef<number | null>(null);

  // Sync initialIndex
  useEffect(() => {
    if (isOpen) {
      setCurrentIndex(Math.min(Math.max(0, initialIndex), Math.max(0, items.length - 1)));
      setScale(1);
      setPosition({ x: 0, y: 0 });
      setIsSimulating(false);
    }
  }, [isOpen, initialIndex, items.length]);

  // Reset zoom on slide change
  const handleIndexChange = useCallback((newIndex: number) => {
    setCurrentIndex(newIndex);
    setScale(1);
    setPosition({ x: 0, y: 0 });
  }, []);

  const handlePrev = useCallback(() => {
    if (currentIndex > 0) {
      handleIndexChange(currentIndex - 1);
    } else {
      handleIndexChange(items.length - 1); // Loop to end
    }
  }, [currentIndex, items.length, handleIndexChange]);

  const handleNext = useCallback(() => {
    if (currentIndex < items.length - 1) {
      handleIndexChange(currentIndex + 1);
    } else {
      handleIndexChange(0); // Loop to start
    }
  }, [currentIndex, items.length, handleIndexChange]);

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'Escape') onClose();
      if (e.key === '+' || e.key === '=') setScale((s) => Math.min(s + 0.25, 4));
      if (e.key === '-') setScale((s) => Math.max(s - 0.25, 0.6));
      if (e.key === '0') {
        setScale(1);
        setPosition({ x: 0, y: 0 });
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, handlePrev, handleNext, onClose]);

  if (!isOpen || items.length === 0) return null;

  const currentItem = items[currentIndex] || items[0];

  // Zoom helpers
  const handleZoomIn = () => setScale((s) => Math.min(s + 0.35, 4.0));
  const handleZoomOut = () => setScale((s) => Math.max(s - 0.35, 0.6));
  const handleResetZoom = () => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  };

  // Mouse pan drag
  const handleMouseDown = (e: React.MouseEvent) => {
    if (scale > 1) {
      setIsDragging(true);
      setDragStart({ x: e.clientX - position.x, y: e.clientY - position.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging && scale > 1) {
      setPosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    }
  };

  const handleMouseUp = () => setIsDragging(false);

  // Wheel zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (e.deltaY < 0) {
      setScale((s) => Math.min(s + 0.15, 4.0));
    } else {
      setScale((s) => Math.max(s - 0.15, 0.6));
    }
  };

  // Touch pinch & swipe gestures
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      touchStartX.current = e.touches[0].clientX;
      touchStartY.current = e.touches[0].clientY;
      if (scale > 1) {
        setIsDragging(true);
        setDragStart({ x: e.touches[0].clientX - position.x, y: e.touches[0].clientY - position.y });
      }
    } else if (e.touches.length === 2) {
      // Pinch to zoom start
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      initialPinchDist.current = dist;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 1 && scale > 1 && isDragging) {
      setPosition({
        x: e.touches[0].clientX - dragStart.x,
        y: e.touches[0].clientY - dragStart.y,
      });
    } else if (e.touches.length === 2 && initialPinchDist.current !== null) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      const factor = dist / initialPinchDist.current;
      setScale((s) => Math.min(Math.max(s * (1 + (factor - 1) * 0.05), 0.6), 4.0));
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    setIsDragging(false);
    initialPinchDist.current = null;

    // Detect horizontal swipe if scale is 1
    if (scale <= 1.05 && e.changedTouches.length === 1) {
      const deltaX = e.changedTouches[0].clientX - touchStartX.current;
      const deltaY = e.changedTouches[0].clientY - touchStartY.current;

      // Horizontal swipe threshold 50px and more horizontal than vertical
      if (Math.abs(deltaX) > 50 && Math.abs(deltaX) > Math.abs(deltaY) * 1.5) {
        if (deltaX < 0) {
          handleNext();
        } else {
          handlePrev();
        }
      }
    }
  };

  const handleDownloadPdf = () => {
    if (currentItem) {
      exportDiagramToPdf(currentItem);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#050E1F]/98 backdrop-blur-xl animate-fadeIn select-none">
      {/* Top Gallery Toolbar */}
      <div className="px-3 sm:px-5 py-2.5 bg-[#0A1A33] border-b border-[#1E3A70] flex items-center justify-between gap-2 z-20 shadow-md">
        {/* Left Info & Slide Counter */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="px-2.5 py-1 rounded-lg bg-[#0284C7] text-white text-xs font-mono font-bold shadow">
              {currentIndex + 1} / {items.length}
            </span>
          </div>

          <div className="min-w-0 truncate">
            <h3 className="text-sm sm:text-base font-bold text-white truncate font-sans">
              {currentItem.title}
            </h3>
            <p className="text-xs text-[#E8A85C] font-urdu truncate hidden xs:block">
              {currentItem.titleUrdu}
            </p>
          </div>
        </div>

        {/* Right Action Tools */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Zoom Level Indicator & Controls */}
          <div className="hidden sm:flex items-center bg-[#071326] border border-[#1E4680] rounded-xl p-1 text-slate-300">
            <button
              onClick={handleZoomOut}
              title="Zoom Out (-)"
              className="p-1 hover:text-white hover:bg-[#163768] rounded-lg transition cursor-pointer"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="px-1.5 font-mono text-xs font-bold text-[#E8A85C] min-w-[42px] text-center">
              {Math.round(scale * 100)}%
            </span>
            <button
              onClick={handleZoomIn}
              title="Zoom In (+)"
              className="p-1 hover:text-white hover:bg-[#163768] rounded-lg transition cursor-pointer"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={handleResetZoom}
              title="Reset Zoom (100%)"
              className="p-1 hover:text-white hover:bg-[#163768] rounded-lg transition ml-1 border-l border-slate-700 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Simulation Toggle */}
          <button
            onClick={() => setIsSimulating(!isSimulating)}
            title="Simulate Power Flow"
            className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border transition flex items-center gap-1.5 cursor-pointer ${
              isSimulating
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500 shadow-sm'
                : 'bg-[#0B172E] text-slate-300 border-[#1E3A70] hover:text-white'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${isSimulating ? 'text-emerald-400 animate-pulse' : 'text-[#38BDF8]'}`} />
            <span className="hidden md:inline">{isSimulating ? 'Power ON' : 'Simulate'}</span>
          </button>

          {/* Download as PDF Button */}
          <button
            onClick={handleDownloadPdf}
            title="Download Diagram as Professional PDF"
            className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-[#B87333]/30 to-[#E8A85C]/30 hover:from-[#B87333]/50 hover:to-[#E8A85C]/50 text-[#E8A85C] border border-[#E8A85C]/40 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Save PDF</span>
          </button>

          {/* Details / Guide Drawer Toggle */}
          <button
            onClick={() => setShowDetails(!showDetails)}
            title="Toggle Details & Wiring Steps"
            className={`p-2 rounded-xl border text-xs font-bold transition cursor-pointer ${
              showDetails
                ? 'bg-[#0284C7] text-white border-[#38BDF8]'
                : 'bg-[#0B172E] text-slate-300 border-[#1E3A70] hover:text-white'
            }`}
          >
            <Info className="w-4 h-4" />
          </button>

          {/* Close Modal */}
          <button
            onClick={onClose}
            title="Close Gallery (Esc)"
            className="p-2 rounded-xl bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-700/60 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Viewport & Canvas Area */}
      <div className="flex-1 relative overflow-hidden flex items-center justify-center">
        {/* Previous Button Arrow */}
        <button
          onClick={handlePrev}
          title="Previous Diagram (Left Arrow / Swipe Right)"
          className="absolute left-2 sm:left-4 z-20 p-2.5 sm:p-3.5 rounded-2xl bg-[#0A1A33]/80 hover:bg-[#163768] text-white border border-[#1E3A70] hover:border-[#38BDF8] shadow-2xl transition backdrop-blur-sm cursor-pointer active:scale-95"
        >
          <ChevronLeft className="w-6 h-6 sm:w-7 sm:h-7 text-[#38BDF8]" />
        </button>

        {/* Next Button Arrow */}
        <button
          onClick={handleNext}
          title="Next Diagram (Right Arrow / Swipe Left)"
          className="absolute right-2 sm:right-4 z-20 p-2.5 sm:p-3.5 rounded-2xl bg-[#0A1A33]/80 hover:bg-[#163768] text-white border border-[#1E3A70] hover:border-[#38BDF8] shadow-2xl transition backdrop-blur-sm cursor-pointer active:scale-95"
        >
          <ChevronRight className="w-6 h-6 sm:w-7 sm:h-7 text-[#38BDF8]" />
        </button>

        {/* Gesture Guidance Overlay (fades out) */}
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-10 flex items-center gap-2 pointer-events-none opacity-70 bg-black/60 px-3 py-1 rounded-full text-[11px] text-slate-300">
          <Move className="w-3.5 h-3.5 text-[#E8A85C]" />
          <span>Swipe left/right to change • Pinch to zoom</span>
        </div>

        {/* Transformable SVG Container */}
        <div
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onWheel={handleWheel}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          style={{
            transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
            transformOrigin: 'center center',
            transition: isDragging ? 'none' : 'transform 0.15s ease-out',
          }}
          className="w-full max-w-5xl h-full p-4 flex items-center justify-center cursor-grab active:cursor-grabbing touch-none select-none"
        >
          <div className="w-full max-h-[80vh] flex items-center justify-center" data-diagram-id={currentItem.id}>
            <DiagramRenderer
              type={currentItem.diagramType}
              isSimulating={isSimulating}
              className="max-h-[75vh] w-auto shadow-2xl rounded-2xl"
            />
          </div>
        </div>

        {/* Slide-out / Expandable Wiring Details Drawer */}
        {showDetails && (
          <div className="absolute top-0 right-0 bottom-0 w-full sm:w-96 bg-[#0B1A33]/95 border-l border-[#1E3A70] p-4 sm:p-5 overflow-y-auto z-30 shadow-2xl space-y-4 animate-slideLeft">
            <div className="flex items-center justify-between pb-3 border-b border-[#1E3A70]">
              <span className="font-bold text-sm text-[#38BDF8] flex items-center gap-1.5">
                <Info className="w-4 h-4" /> Diagram Specs & Guide
              </span>
              <button
                onClick={() => setShowDetails(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <h4 className="font-bold text-base text-white">{currentItem.title}</h4>
              <p className="text-xs text-[#E8A85C] font-urdu mt-0.5">{currentItem.titleUrdu}</p>
              <div className="flex gap-2 mt-2">
                {currentItem.voltageRating && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#163768] text-[#38BDF8] border border-[#1E4680]">
                    ⚡ {currentItem.voltageRating}
                  </span>
                )}
                {currentItem.standardRef && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#163768] text-[#E8A85C] border border-[#1E4680]">
                    📜 {currentItem.standardRef}
                  </span>
                )}
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">{currentItem.description}</p>
            <p className="text-xs text-slate-400 font-urdu leading-relaxed">{currentItem.descriptionUrdu}</p>

            {/* Components Checklist */}
            <div className="space-y-2 pt-2 border-t border-[#1E3A70]">
              <span className="text-xs font-bold text-[#38BDF8] uppercase tracking-wider block">
                Components (پرزہ جات):
              </span>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {currentItem.componentsUsed.map((comp, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{comp}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Wiring Steps */}
            <div className="space-y-2 pt-2 border-t border-[#1E3A70]">
              <span className="text-xs font-bold text-[#E8A85C] uppercase tracking-wider block">
                Wiring Guide (طریقہ کار):
              </span>
              <ol className="space-y-2 text-xs text-slate-300">
                {currentItem.wiringSteps.map((step, i) => (
                  <li key={i} className="border-l-2 border-[#0284C7] pl-2 py-0.5">
                    <p className="font-medium text-white">{step}</p>
                    {currentItem.wiringStepsUrdu[i] && (
                      <p className="font-urdu text-[11px] text-[#E8A85C] mt-0.5">
                        {currentItem.wiringStepsUrdu[i]}
                      </p>
                    )}
                  </li>
                ))}
              </ol>
            </div>

            {/* Safety Rules */}
            <div className="p-3 rounded-xl bg-red-950/40 border border-red-700/60 text-xs space-y-1.5">
              <span className="font-bold text-red-300 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5 text-red-400" /> Safety Rules
              </span>
              {currentItem.safetyNotes.map((note, i) => (
                <p key={i} className="text-red-100 text-[11px]">
                  • {note}
                </p>
              ))}
            </div>

            {/* Export PDF Button inside drawer */}
            <button
              onClick={handleDownloadPdf}
              className="w-full py-2.5 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-white text-xs font-bold flex items-center justify-center gap-2 shadow cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download PDF Engineering Sheet</span>
            </button>
          </div>
        )}
      </div>

      {/* Bottom Thumbnail Strip */}
      <div className="px-3 py-2 bg-[#0A1A33] border-t border-[#1E3A70] flex items-center gap-2 overflow-x-auto scrollbar-none z-20">
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider shrink-0 pl-1">
          Thumbnails ({items.length}):
        </span>
        {items.map((item, idx) => {
          const isActive = idx === currentIndex;
          return (
            <button
              key={item.id}
              onClick={() => handleIndexChange(idx)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
                isActive
                  ? 'bg-[#0284C7] text-white font-bold ring-2 ring-[#38BDF8] shadow-md'
                  : 'bg-[#0F2042] hover:bg-[#162C58] text-slate-300 border border-[#1E3A70]'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#E8A85C]" />
              <span className="max-w-[130px] truncate">{item.title}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
