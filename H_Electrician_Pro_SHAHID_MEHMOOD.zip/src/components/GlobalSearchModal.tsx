import React, { useState, useMemo } from 'react';
import { Search, X, Calculator, BookOpen, GitFork, Box, Wrench, ArrowRight } from 'lucide-react';
import { FORMULAS_DATA } from '../data/formulasData';
import { CALCULATORS_DATA } from '../data/calculatorsData';
import { DIAGRAMS_DATA } from '../data/diagramsData';
import { COMPONENTS_DATA } from '../data/componentsData';
import { FAULTS_DATA } from '../data/faultsData';
import { SENSORS_DATA } from '../data/sensorsData';
import { ModuleId } from '../types';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectResult: (moduleId: ModuleId, itemId: string) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectResult,
}) => {
  const [query, setQuery] = useState<string>('');

  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];

    const results: {
      id: string;
      moduleId: ModuleId;
      category: string;
      title: string;
      titleUrdu: string;
      snippet: string;
      iconType: 'calc' | 'formula' | 'diagram' | 'component' | 'fault';
    }[] = [];

    // Search Calculators
    CALCULATORS_DATA.forEach((calc) => {
      if (
        calc.title.toLowerCase().includes(q) ||
        calc.titleUrdu.includes(q) ||
        calc.formula.toLowerCase().includes(q)
      ) {
        results.push({
          id: calc.id,
          moduleId: 'calculators',
          category: 'Calculators',
          title: calc.title,
          titleUrdu: calc.titleUrdu,
          snippet: calc.formula,
          iconType: 'calc',
        });
      }
    });

    // Search Formulas
    FORMULAS_DATA.forEach((f) => {
      if (
        f.title.toLowerCase().includes(q) ||
        f.titleUrdu.includes(q) ||
        f.formula.toLowerCase().includes(q) ||
        f.explanation.toLowerCase().includes(q) ||
        f.explanationUrdu.includes(q)
      ) {
        results.push({
          id: f.id,
          moduleId: 'formulas',
          category: `Formula: ${f.categoryTitle}`,
          title: f.title,
          titleUrdu: f.titleUrdu,
          snippet: f.formula,
          iconType: 'formula',
        });
      }
    });

    // Search Diagrams
    DIAGRAMS_DATA.forEach((d) => {
      if (
        d.title.toLowerCase().includes(q) ||
        d.titleUrdu.includes(q) ||
        d.description.toLowerCase().includes(q) ||
        d.descriptionUrdu.includes(q)
      ) {
        results.push({
          id: d.id,
          moduleId: 'diagrams',
          category: 'Wiring Diagram',
          title: d.title,
          titleUrdu: d.titleUrdu,
          snippet: d.description.slice(0, 80) + '...',
          iconType: 'diagram',
        });
      }
    });

    // Search Components
    COMPONENTS_DATA.forEach((c) => {
      if (
        c.name.toLowerCase().includes(q) ||
        c.nameUrdu.includes(q) ||
        c.function.toLowerCase().includes(q) ||
        c.priceRangePKR.toLowerCase().includes(q)
      ) {
        results.push({
          id: c.id,
          moduleId: 'components',
          category: 'Component Library',
          title: c.name,
          titleUrdu: c.nameUrdu,
          snippet: c.priceRangePKR,
          iconType: 'component',
        });
      }
    });

    // Search Sensors
    SENSORS_DATA.forEach((s) => {
      if (
        s.title.toLowerCase().includes(q) ||
        s.titleUrdu.includes(q) ||
        s.workingPrinciple.toLowerCase().includes(q)
      ) {
        results.push({
          id: s.id,
          moduleId: 'sensors',
          category: 'Sensors & Limits',
          title: s.title,
          titleUrdu: s.titleUrdu,
          snippet: s.workingPrinciple.slice(0, 80) + '...',
          iconType: 'component',
        });
      }
    });

    // Search Fault Finding Guru
    FAULTS_DATA.forEach((ft) => {
      if (
        ft.problem.toLowerCase().includes(q) ||
        ft.problemUrdu.includes(q) ||
        ft.categoryTitle.toLowerCase().includes(q) ||
        ft.solutions.some((s) => s.toLowerCase().includes(q))
      ) {
        results.push({
          id: ft.id,
          moduleId: 'fault_finding',
          category: `Fault: ${ft.categoryTitle}`,
          title: ft.problem,
          titleUrdu: ft.problemUrdu,
          snippet: ft.solutions[0] || '',
          iconType: 'fault',
        });
      }
    });

    return results.slice(0, 25);
  }, [query]);

  if (!isOpen) return null;

  const quickSearchSuggestions = [
    'Ohm Law',
    'Wire Size',
    'Motor FLA',
    'Star Delta',
    'VFD Danfoss',
    'Compressor CSR',
    'RCCB 30mA',
    'Gas Pressure R410A',
    'Earthing Pit',
    'PNP Sensor',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/85 backdrop-blur-md p-3 pt-10 sm:pt-14 animate-fadeIn">
      <div className="w-full max-w-2xl rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-2xl p-4 sm:p-5 text-white flex flex-col max-h-[85vh] overflow-hidden">
        {/* Search Bar Header */}
        <div className="flex items-center gap-2.5 pb-3 border-b border-[#1E3A70]">
          <div className="relative flex-1">
            <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#38BDF8]" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search formulas, diagrams, components or faults... (سرچ کریں)"
              className="w-full rounded-xl bg-[#070F1E] border border-[#1E3A70] focus:border-[#0EA5E9] focus:outline-none pl-11 pr-4 py-2.5 text-sm text-slate-100 placeholder-slate-400 font-sans shadow-inner transition"
            />
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-[#162C58] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Suggestion Chips */}
        {!query && (
          <div className="py-3 border-b border-[#1E3A70]/60">
            <p className="text-xs text-slate-400 mb-2 font-medium">Quick Searches (فوری تلاش):</p>
            <div className="flex flex-wrap gap-1.5">
              {quickSearchSuggestions.map((item) => (
                <button
                  key={item}
                  onClick={() => setQuery(item)}
                  className="px-2.5 py-1 rounded-lg bg-[#0F2042] hover:bg-[#162C58] text-xs text-[#38BDF8] border border-[#1E3A70] transition cursor-pointer"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Results List */}
        <div className="flex-1 overflow-y-auto py-2 space-y-2 pr-1">
          {query && searchResults.length === 0 ? (
            <div className="text-center py-10 text-slate-400">
              <Search className="w-8 h-8 mx-auto text-slate-500 mb-2" />
              <p>No results found for "{query}"</p>
              <p className="text-xs text-[#E8A85C] font-urdu mt-1">کوئی ریکارڈ نہیں ملا - انگریزی یا اردو میں کوشش کریں</p>
            </div>
          ) : (
            searchResults.map((item) => (
              <div
                key={`${item.moduleId}-${item.id}`}
                onClick={() => {
                  onSelectResult(item.moduleId, item.id);
                  onClose();
                }}
                className="p-3 rounded-xl bg-[#0F2042] hover:bg-[#162C58] border border-[#1E3A70] hover:border-[#0EA5E9] transition cursor-pointer flex items-center justify-between gap-3 group"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-[#070F1E] border border-[#1E3A70] text-[#38BDF8] flex items-center justify-center flex-shrink-0 mt-0.5">
                    {item.iconType === 'calc' && <Calculator className="w-4 h-4" />}
                    {item.iconType === 'formula' && <BookOpen className="w-4 h-4" />}
                    {item.iconType === 'diagram' && <GitFork className="w-4 h-4" />}
                    {item.iconType === 'component' && <Box className="w-4 h-4" />}
                    {item.iconType === 'fault' && <Wrench className="w-4 h-4" />}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase font-bold text-[#38BDF8] tracking-wider">
                        {item.category}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-white group-hover:text-[#38BDF8] transition truncate">
                      {item.title}
                    </h4>
                    <p className="text-xs text-[#E8A85C] font-urdu truncate">{item.titleUrdu}</p>
                    <p className="text-[11px] text-slate-400 font-mono mt-0.5 truncate">{item.snippet}</p>
                  </div>
                </div>

                <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-[#38BDF8] group-hover:translate-x-1 transition flex-shrink-0" />
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="pt-2.5 border-t border-[#1E3A70] text-[11px] text-slate-400 flex items-center justify-between">
          <span>Found {searchResults.length} matches</span>
          <span className="font-urdu text-[#E8A85C]">100% آف لائن سرچ</span>
        </div>
      </div>
    </div>
  );
};
