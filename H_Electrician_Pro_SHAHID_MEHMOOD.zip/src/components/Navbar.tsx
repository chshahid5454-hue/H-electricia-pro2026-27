import React from 'react';
import { Menu, Search, Lock, DollarSign, Globe, Star, ShieldCheck } from 'lucide-react';
import { Language } from '../types';

interface NavbarProps {
  onOpenDrawer: () => void;
  onOpenSearch: () => void;
  onOpenVoice: () => void;
  onLockApp: () => void;
  onOpenRates: () => void;
  language: Language;
  onToggleLanguage: () => void;
  onOpenFavorites: () => void;
  favoritesCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenDrawer,
  onOpenSearch,
  onOpenVoice,
  onLockApp,
  onOpenRates,
  language,
  onToggleLanguage,
  onOpenFavorites,
  favoritesCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#070F1E]/95 backdrop-blur-md border-b border-[#1E3A70] shadow-lg px-3 sm:px-5 py-2.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Zone 1: Drawer Toggle & Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenDrawer}
            title="Open 15 Modules Menu"
            className="p-2 rounded-xl bg-[#0B172E] hover:bg-[#162C58] text-slate-200 border border-[#1E3A70] hover:border-[#0EA5E9] active:scale-95 transition cursor-pointer"
          >
            <Menu className="w-5 h-5 text-[#38BDF8]" />
          </button>

          <div className="flex items-center gap-2.5">
            {/* Launcher H Logo Icon */}
            <div className="w-9 h-9 rounded-xl bg-[#0B172E] border border-[#E8A85C]/70 p-1 flex items-center justify-center shadow-md relative group">
              <img src="/icon.svg" alt="H Logo" className="w-full h-full object-contain" />
            </div>

            <div className="leading-tight">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-sm sm:text-base tracking-tight text-white font-sans flex items-center gap-1">
                  H Electrician <span className="text-[#38BDF8]">Pro</span>
                </span>
                <span className="hidden xs:inline-block text-[9px] font-bold bg-[#0284C7]/20 text-[#38BDF8] border border-[#0EA5E9]/40 px-1.5 py-0.2 rounded font-mono">
                  OFFLINE
                </span>
              </div>
              <p className="text-[10px] text-[#E8A85C] font-urdu truncate max-w-[150px] sm:max-w-xs leading-none mt-0.5">
                شاہد الیکٹریشن · انڈسٹریل انسائیکلوپیڈیا
              </p>
            </div>
          </div>
        </div>

        {/* Zone 2: Middle Search Trigger */}
        <div className="flex-1 max-w-md hidden md:block">
          <button
            onClick={onOpenSearch}
            className="w-full flex items-center justify-between px-3.5 py-1.5 rounded-xl bg-[#0B172E] hover:bg-[#0F2042] text-slate-300 border border-[#1E3A70] hover:border-[#0EA5E9] text-xs font-medium transition cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-[#38BDF8]" />
              <span className="text-slate-400">Search formulas, diagrams, PLC, faults...</span>
            </div>
            <kbd className="bg-[#070F1E] px-1.5 py-0.5 rounded text-[10px] text-slate-400 font-mono border border-[#1E3A70]">
              Ctrl+K
            </kbd>
          </button>
        </div>

        {/* Zone 3: Actions Strip */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Top MIC Button: Bol Ke Dikhao */}
          <button
            onClick={onOpenVoice}
            title="Voice Search: Bol Ke Dikhao (بول کے دکھاؤ)"
            className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#0284C7] to-[#0369A1] hover:from-[#0369A1] hover:to-[#0284C7] text-white border border-[#38BDF8] text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-sky-950/60 active:scale-95 group"
          >
            <span className="text-sm group-hover:scale-110 transition-transform">🎤</span>
            <span className="font-urdu font-bold tracking-wide">بول کے دکھاؤ</span>
            <span className="hidden xl:inline text-[9px] font-mono bg-sky-900/80 px-1 py-0.2 rounded border border-sky-400/40 text-sky-200">
              MIC
            </span>
          </button>

          {/* Mobile Search Button */}
          <button
            onClick={onOpenSearch}
            title="Search"
            className="md:hidden p-2 rounded-xl bg-[#0B172E] hover:bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] transition cursor-pointer"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Favorites Button */}
          <button
            onClick={onOpenFavorites}
            title="Saved Favorites (محفوظ شدہ)"
            className="relative p-2 rounded-xl bg-[#0B172E] hover:bg-[#162C58] text-[#E8A85C] border border-[#1E3A70] hover:border-[#E8A85C]/50 transition cursor-pointer"
          >
            <Star className="w-4 h-4" />
            {favoritesCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#E8A85C] text-[#070F1E] font-bold text-[9px] flex items-center justify-center font-mono">
                {favoritesCount}
              </span>
            )}
          </button>

          {/* Owner Rates Secret Shortcut */}
          <button
            onClick={onOpenRates}
            title="My Rates (میری ریٹ لسٹ - PIN)"
            className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-[#B87333]/25 to-[#E8A85C]/25 hover:from-[#B87333]/40 hover:to-[#E8A85C]/40 text-[#E8A85C] border border-[#E8A85C]/40 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span className="hidden sm:inline font-urdu">ریٹ لسٹ</span>
          </button>

          {/* Language Switch */}
          <button
            onClick={onToggleLanguage}
            title="Switch Language (Urdu / English)"
            className="px-2.5 py-1.5 rounded-xl bg-[#0B172E] hover:bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] text-xs font-bold transition flex items-center gap-1 cursor-pointer font-sans"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{language === 'ur' ? 'اردو' : 'EN'}</span>
          </button>

          {/* Quick Lock Button */}
          <button
            onClick={onLockApp}
            title="Lock App with PIN (لاک کریں)"
            className="p-2 rounded-xl bg-red-950/30 hover:bg-red-900/50 text-red-300 border border-red-800/40 transition cursor-pointer"
          >
            <Lock className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
