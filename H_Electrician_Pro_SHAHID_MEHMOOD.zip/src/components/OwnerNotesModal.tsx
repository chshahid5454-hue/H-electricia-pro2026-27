import React, { useState, useEffect } from 'react';
import { X, Save, Trash2, Edit3, Lock, ShieldCheck, Sparkles, MessageSquare } from 'lucide-react';
import { StorageService } from '../services/storage';
import { OwnerNote } from '../types';

interface OwnerNotesModalProps {
  isOpen: boolean;
  onClose: () => void;
  topicId: string;
  topicTitle: string;
  topicTitleUrdu: string;
}

export const OwnerNotesModal: React.FC<OwnerNotesModalProps> = ({
  isOpen,
  onClose,
  topicId,
  topicTitle,
  topicTitleUrdu,
}) => {
  const [noteText, setNoteText] = useState<string>('');
  const [savedNote, setSavedNote] = useState<OwnerNote | null>(null);
  const [isSavedAlert, setIsSavedAlert] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen && topicId) {
      const existing = StorageService.getOwnerNote(topicId);
      if (existing) {
        setSavedNote(existing);
        setNoteText(existing.noteText);
      } else {
        setSavedNote(null);
        setNoteText('');
      }
      setIsSavedAlert(false);
    }
  }, [isOpen, topicId]);

  if (!isOpen) return null;

  const handleSave = () => {
    if (!noteText.trim()) return;
    StorageService.saveOwnerNote(topicId, noteText.trim());
    const updated = StorageService.getOwnerNote(topicId);
    setSavedNote(updated);
    setIsSavedAlert(true);
    setTimeout(() => setIsSavedAlert(false), 2500);
  };

  const handleDelete = () => {
    if (window.confirm('کیا آپ واقعی یہ ذاتی نوٹ ڈیلیٹ کرنا چاہتے ہیں؟ (Delete note?)')) {
      StorageService.deleteOwnerNote(topicId);
      setSavedNote(null);
      setNoteText('');
    }
  };

  const handleQuickSnippet = (snippet: string) => {
    setNoteText((prev) => (prev ? `${prev}\n${snippet}` : snippet));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-fadeIn">
      <div className="w-full max-w-lg rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-2xl p-5 text-white relative flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-[#1E3A70]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#0284C7]/20 text-[#38BDF8] border border-[#0EA5E9]/40">
              <Edit3 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg text-white font-sans">Owner's Private Field Notes</h3>
                <span className="inline-flex items-center gap-1 text-[10px] bg-amber-500/20 text-[#E8A85C] px-2 py-0.5 rounded-full border border-[#E8A85C]/40 font-semibold">
                  <Lock className="w-3 h-3" /> Private
                </span>
              </div>
              <p className="text-xs text-slate-300 font-urdu">{topicTitleUrdu} - میرا ذاتی تجربہ اور ڈائری</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#162C58] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Topic Context Bar */}
        <div className="mt-3 px-3 py-2 rounded-lg bg-[#070F1E] border border-[#1E3A70] text-xs text-slate-300 flex items-center justify-between">
          <span className="font-medium text-slate-200 truncate">{topicTitle}</span>
          <span className="text-[11px] text-[#38BDF8] font-urdu">صرف آپ کے موبائل میں محفوظ</span>
        </div>

        {/* Quick Urdu Snippet Suggestions */}
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          <button
            type="button"
            onClick={() => handleQuickSnippet('اوکاڑہ کی چیلر میں یہ فالٹ آیا تھا اور فلو سوئچ سیٹ کرنے سے حل ہوا: ')}
            className="text-[11px] px-2.5 py-1 rounded bg-[#0F2042] hover:bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] font-urdu transition cursor-pointer"
          >
            + اوکاڑہ چیلر فالٹ
          </button>
          <button
            type="button"
            onClick={() => handleQuickSnippet('فیصل آباد ٹیکسٹائل مل میں یہ کنٹیکٹر بدلا: ')}
            className="text-[11px] px-2.5 py-1 rounded bg-[#0F2042] hover:bg-[#162C58] text-slate-200 border border-[#1E3A70] font-urdu transition cursor-pointer"
          >
            + فیکٹری تجربہ
          </button>
          <button
            type="button"
            onClick={() => handleQuickSnippet('اس جگہ کاپر وائر 16mm² لگائی اور ٹائمر 7 سیکنڈ رکھا۔')}
            className="text-[11px] px-2.5 py-1 rounded bg-[#0F2042] hover:bg-[#162C58] text-slate-200 border border-[#1E3A70] font-urdu transition cursor-pointer"
          >
            + وائر سائز / سیٹنگ
          </button>
        </div>

        {/* Text Area */}
        <div className="mt-3 flex-1 flex flex-col">
          <label className="text-xs font-semibold text-slate-300 mb-1 flex items-center justify-between">
            <span>Write Personal Experience (اردو یا انگریزی میں لکھیں):</span>
            {savedNote && (
              <span className="text-[10px] text-slate-400">
                Last updated: {new Date(savedNote.updatedAt).toLocaleDateString()}
              </span>
            )}
          </label>
          <textarea
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            placeholder="یہاں اپنا ذاتی تجربہ لکھیں... مثلاً: 'اوکاڑہ کی چیلر میں یہ فالٹ آیا تھا، فلو سوئچ جام تھا، پیڈل صاف کیا تو ٹھیک چلا۔ آئندہ پہلے فلو چیک کرنا ہے۔'"
            rows={7}
            className="w-full flex-1 rounded-xl bg-[#070F1E] border border-[#1E3A70] focus:border-[#0EA5E9] focus:outline-none p-3.5 text-sm text-slate-100 placeholder-slate-500 font-urdu resize-none leading-relaxed transition"
            dir="auto"
          />
        </div>

        {/* Success Alert */}
        {isSavedAlert && (
          <div className="mt-2 py-1.5 px-3 rounded-lg bg-emerald-950/80 border border-emerald-500 text-emerald-200 text-xs font-semibold flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            آپ کا ذاتی نوٹ آف لائن محفوظ ہو گیا ہے! (Note saved securely)
          </div>
        )}

        {/* Action Buttons */}
        <div className="mt-4 pt-3 border-t border-[#1E3A70] flex items-center justify-between gap-2">
          {savedNote ? (
            <button
              onClick={handleDelete}
              className="px-3.5 py-2 rounded-xl bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-700/60 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              Delete Note
            </button>
          ) : (
            <div />
          )}

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-[#070F1E] hover:bg-[#162C58] text-xs font-semibold text-slate-300 border border-[#1E3A70] transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-xs font-bold text-white flex items-center gap-1.5 shadow-lg shadow-[#0284C7]/20 transition cursor-pointer"
            >
              <Save className="w-4 h-4" />
              Save Note | محفوظ کریں
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
