import React, { useState, useEffect } from 'react';
import { X, Plus, Edit2, Trash2, Search, Share2, DollarSign, Wrench, Shield, Check, RotateCcw, AlertCircle } from 'lucide-react';
import { StorageService } from '../services/storage';
import { OwnerRateItem } from '../types';

interface OwnerRatesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const OwnerRatesModal: React.FC<OwnerRatesModalProps> = ({ isOpen, onClose }) => {
  const [rates, setRates] = useState<OwnerRateItem[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [editingItem, setEditingItem] = useState<OwnerRateItem | null>(null);
  const [isAddingNew, setIsAddingNew] = useState<boolean>(false);
  const [showShareToast, setShowShareToast] = useState<string>('');

  // Form states for add/edit
  const [formName, setFormName] = useState<string>('');
  const [formNameUrdu, setFormNameUrdu] = useState<string>('');
  const [formRate, setFormRate] = useState<number>(1000);
  const [formUnit, setFormUnit] = useState<string>('Per Point');
  const [formUnitUrdu, setFormUnitUrdu] = useState<string>('فی پوائنٹ');
  const [formCategory, setFormCategory] = useState<OwnerRateItem['category']>('labour');
  const [formNotes, setFormNotes] = useState<string>('');
  const [formNotesUrdu, setFormNotesUrdu] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      loadRates();
    }
  }, [isOpen]);

  const loadRates = () => {
    const list = StorageService.getOwnerRates();
    setRates(list);
  };

  if (!isOpen) return null;

  const categories = [
    { id: 'all', label: 'All Rates (سب ریٹس)' },
    { id: 'labour', label: 'Labour (لیبر مزدوری)' },
    { id: 'motor_winding', label: 'Motor Winding (موٹر وائنڈنگ)' },
    { id: 'panels', label: 'Panels (پینل وائرنگ)' },
    { id: 'solar', label: 'Solar & UPS (سولر فٹنگ)' },
    { id: 'emergency', label: 'Emergency (وزٹ فیس)' },
  ];

  const filteredRates = rates.filter((item) => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      !q ||
      item.serviceName.toLowerCase().includes(q) ||
      item.serviceNameUrdu.includes(q) ||
      item.categoryTitle.toLowerCase().includes(q);
    return matchesCategory && matchesSearch;
  });

  const handleStartEdit = (item: OwnerRateItem) => {
    setEditingItem(item);
    setFormName(item.serviceName);
    setFormNameUrdu(item.serviceNameUrdu);
    setFormRate(item.ratePKR);
    setFormUnit(item.unit);
    setFormUnitUrdu(item.unitUrdu);
    setFormCategory(item.category);
    setFormNotes(item.notes);
    setFormNotesUrdu(item.notesUrdu);
    setIsAddingNew(false);
  };

  const handleStartAdd = () => {
    setIsAddingNew(true);
    setEditingItem(null);
    setFormName('');
    setFormNameUrdu('');
    setFormRate(2500);
    setFormUnit('Per Job');
    setFormUnitUrdu('فی کام');
    setFormCategory('labour');
    setFormNotes('');
    setFormNotesUrdu('');
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    const newItem: OwnerRateItem = {
      id: editingItem ? editingItem.id : `rate-custom-${Date.now()}`,
      category: formCategory,
      categoryTitle:
        formCategory === 'motor_winding'
          ? 'Motor Winding Rates'
          : formCategory === 'panels'
          ? 'Panel Fabrication & Wiring'
          : formCategory === 'solar'
          ? 'Solar & UPS Installation'
          : formCategory === 'emergency'
          ? 'Emergency Field Calls'
          : 'Electrical Labour',
      categoryTitleUrdu:
        formCategory === 'motor_winding'
          ? 'موٹر وائنڈنگ ریٹس'
          : formCategory === 'panels'
          ? 'پینل وائرنگ ریٹس'
          : formCategory === 'solar'
          ? 'سولر انسٹالیشن ریٹس'
          : formCategory === 'emergency'
          ? 'ایمرجنسی وزٹ فیس'
          : 'لیبر اور مزدوری',
      serviceName: formName.trim(),
      serviceNameUrdu: formNameUrdu.trim() || formName.trim(),
      ratePKR: Number(formRate) || 0,
      unit: formUnit.trim() || 'Per Job',
      unitUrdu: formUnitUrdu.trim() || 'فی کام',
      notes: formNotes.trim(),
      notesUrdu: formNotesUrdu.trim(),
    };

    StorageService.updateRateItem(newItem);
    loadRates();
    setEditingItem(null);
    setIsAddingNew(false);
  };

  const handleDeleteItem = (id: string) => {
    if (window.confirm('کیا آپ واقعی یہ ریٹ لسٹ سے ڈیلیٹ کرنا چاہتے ہیں؟ (Delete item?)')) {
      StorageService.deleteRateItem(id);
      loadRates();
    }
  };

  const handleResetDefaults = () => {
    if (window.confirm('تمام ریٹس فیکٹری ڈیفالٹ پر ری سیٹ کریں؟ (Reset to default rates?)')) {
      const defs = StorageService.resetRatesToDefault();
      setRates(defs);
    }
  };

  const handleShareQuote = (item: OwnerRateItem) => {
    const text = `*شاہد الیکٹریشن - کام کی ریٹ لسٹ*\n\n📌 *کام:* ${item.serviceNameUrdu}\n💰 *ریٹ:* PKR ${item.ratePKR.toLocaleString()} (${item.unitUrdu})\n📝 *نوٹ:* ${item.notesUrdu || item.notes}\n\n_رابطہ: شاہد الیکٹریشن - انڈسٹریل و ہوم سروسز_`;
    if (navigator.share) {
      navigator.share({ title: 'Shahid Electrician Rates', text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      setShowShareToast(`کاپی ہو گیا! واٹس ایپ پر پیسٹ کریں (Copied)`);
      setTimeout(() => setShowShareToast(''), 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-5 animate-fadeIn">
      <div className="w-full max-w-3xl rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-2xl p-4 sm:p-6 text-white relative flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#1E3A70]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#B87333] to-[#E8A85C] flex items-center justify-center text-[#050F1E] font-bold shadow-lg">
              <DollarSign className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-bold text-white font-sans">My Rates | میری خفیہ ریٹ لسٹ</h2>
                <span className="text-[10px] bg-amber-500/20 text-[#E8A85C] border border-[#E8A85C]/40 px-2 py-0.5 rounded-full font-semibold">
                  PIN Protected
                </span>
              </div>
              <p className="text-xs text-slate-300 font-urdu">شاہد الیکٹریشن - مزدوری، موٹر وائنڈنگ اور پینل فکس ریٹس</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#162C58] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Actions Bar */}
        <div className="mt-3 flex flex-wrap sm:flex-nowrap gap-2 items-center justify-between">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ریٹ تلاش کریں... (Search labour, winding, panel...)"
              className="w-full rounded-xl bg-[#070F1E] border border-[#1E3A70] focus:border-[#0EA5E9] focus:outline-none pl-9 pr-3 py-2 text-xs text-slate-100 placeholder-slate-400 font-urdu"
            />
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleStartAdd}
              className="px-3 py-2 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-xs font-bold text-white flex items-center gap-1.5 shadow transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Add Rate (نیا ریٹ)
            </button>
            <button
              onClick={handleResetDefaults}
              title="Reset to defaults"
              className="p-2 rounded-xl bg-[#070F1E] hover:bg-[#162C58] text-slate-300 border border-[#1E3A70] text-xs transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Category Pills */}
        <div className="mt-3 flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveCategory(c.id)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                activeCategory === c.id
                  ? 'bg-[#0284C7] text-white font-bold shadow'
                  : 'bg-[#0F2042] hover:bg-[#162C58] text-slate-300 border border-[#1E3A70]'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Toast Alert */}
        {showShareToast && (
          <div className="mt-2 py-1.5 px-3 rounded-lg bg-emerald-950 border border-emerald-500 text-emerald-200 text-xs font-semibold flex items-center gap-1.5">
            <Check className="w-4 h-4 text-emerald-400" />
            {showShareToast}
          </div>
        )}

        {/* Add / Edit Form Modal Sub-view */}
        {(isAddingNew || editingItem) && (
          <form onSubmit={handleSaveForm} className="my-3 p-4 rounded-xl bg-[#0F294E] border border-[#E8A85C] text-xs">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-700">
              <h4 className="font-bold text-sm text-[#E8A85C]">
                {editingItem ? 'Edit Service Rate | ریٹ تبدیل کریں' : 'Add New Service Rate | نیا ریٹ شامل کریں'}
              </h4>
              <button
                type="button"
                onClick={() => {
                  setEditingItem(null);
                  setIsAddingNew(false);
                }}
                className="text-slate-400 hover:text-white"
              >
                Cancel
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-slate-300 font-medium">Service Name (English):</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. 5 HP Motor Rewinding"
                  className="w-full mt-1 rounded-lg bg-[#071326] border border-slate-700 p-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-300 font-medium font-urdu">کام کا نام (اردو):</label>
                <input
                  type="text"
                  value={formNameUrdu}
                  onChange={(e) => setFormNameUrdu(e.target.value)}
                  placeholder="مثلاً: 5 ایچ پی موٹر وائنڈنگ"
                  className="w-full mt-1 rounded-lg bg-[#071326] border border-slate-700 p-2 text-white font-urdu"
                  dir="rtl"
                />
              </div>
              <div>
                <label className="text-slate-300 font-medium">Rate in PKR (روپے):</label>
                <input
                  type="number"
                  required
                  value={formRate}
                  onChange={(e) => setFormRate(Number(e.target.value))}
                  className="w-full mt-1 rounded-lg bg-[#071326] border border-slate-700 p-2 text-white font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-slate-300 font-medium">Unit / Basis (یونٹ):</label>
                <input
                  type="text"
                  value={formUnit}
                  onChange={(e) => setFormUnit(e.target.value)}
                  placeholder="Per Point / Per Motor / Per Day"
                  className="w-full mt-1 rounded-lg bg-[#071326] border border-slate-700 p-2 text-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="text-slate-300 font-medium">Category:</label>
                <select
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value as OwnerRateItem['category'])}
                  className="w-full mt-1 rounded-lg bg-[#071326] border border-slate-700 p-2 text-white"
                >
                  <option value="labour">Electrical Labour (مزدوری)</option>
                  <option value="motor_winding">Motor Winding (موٹر وائنڈنگ)</option>
                  <option value="panels">Panel Fabrication (پینل وائرنگ)</option>
                  <option value="solar">Solar & UPS (سولر فٹنگ)</option>
                  <option value="emergency">Emergency Field Visit (وزٹ فیس)</option>
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className="text-slate-300 font-medium font-urdu">نوٹ یا تفصیل (Urdu Notes):</label>
                <input
                  type="text"
                  value={formNotesUrdu}
                  onChange={(e) => setFormNotesUrdu(e.target.value)}
                  placeholder="مثلاً: پیور کاپر تار اور ٹیسٹنگ کے ساتھ"
                  className="w-full mt-1 rounded-lg bg-[#071326] border border-slate-700 p-2 text-white font-urdu"
                  dir="rtl"
                />
              </div>
            </div>
            <div className="mt-3 flex justify-end gap-2">
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-[#E8A85C] text-[#050F1E] font-bold shadow hover:bg-[#F7C58B]"
              >
                Save Rate (محفوظ کریں)
              </button>
            </div>
          </form>
        )}

        {/* Rates List Container */}
        <div className="mt-3 flex-1 overflow-y-auto pr-1 space-y-2.5">
          {filteredRates.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <AlertCircle className="w-8 h-8 mx-auto text-[#E8A85C] opacity-60 mb-2" />
              <p>کوئی ریٹ نہیں ملا (No matching rate found)</p>
            </div>
          ) : (
            filteredRates.map((item) => (
              <div
                key={item.id}
                className="p-3 sm:p-3.5 rounded-xl bg-[#0F2042] hover:bg-[#162C58] border border-[#1E3A70] hover:border-[#0EA5E9] transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm sm:text-base font-bold text-white">{item.serviceName}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-[#162C58] text-[#38BDF8] font-mono border border-[#1E3A70]">
                      {item.unit}
                    </span>
                  </div>
                  <p className="text-xs text-[#E8A85C] font-urdu font-medium mt-0.5">{item.serviceNameUrdu}</p>
                  {(item.notesUrdu || item.notes) && (
                    <p className="text-[11px] text-slate-400 mt-1 font-urdu">{item.notesUrdu || item.notes}</p>
                  )}
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#1E3A70]">
                  <div className="text-left sm:text-right">
                    <span className="text-lg font-black text-[#E8A85C] font-mono tabular-nums">
                      PKR {item.ratePKR.toLocaleString()}
                    </span>
                    <span className="block text-[10px] text-slate-400 font-urdu">{item.unitUrdu}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleShareQuote(item)}
                      title="Share quote on WhatsApp"
                      className="p-2 rounded-lg bg-[#070F1E] hover:bg-[#0284C7] hover:text-white text-[#38BDF8] border border-[#1E3A70] transition cursor-pointer"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleStartEdit(item)}
                      title="Edit rate"
                      className="p-2 rounded-lg bg-[#070F1E] hover:bg-amber-950 hover:text-[#E8A85C] text-slate-300 border border-[#1E3A70] transition cursor-pointer"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      title="Delete rate"
                      className="p-2 rounded-lg bg-[#070F1E] hover:bg-red-950 hover:text-red-400 text-slate-300 border border-[#1E3A70] transition cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="mt-3 pt-3 border-t border-[#1E4680] flex items-center justify-between text-xs text-slate-400">
          <span>Total Services: {rates.length} Items</span>
          <span className="text-[#E8A85C] font-urdu">شاہد الیکٹریشن - محفوظ ذاتی ریٹ لسٹ</span>
        </div>
      </div>
    </div>
  );
};
