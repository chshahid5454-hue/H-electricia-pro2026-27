import React, { useState, useEffect } from 'react';
import { Download, Smartphone, Check, HelpCircle, X, Shield, Code, Copy } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const PWAInstallButton: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState<boolean>(false);
  const [showGuideModal, setShowGuideModal] = useState<boolean>(false);
  const [copiedSnippet, setCopiedSnippet] = useState<string>('');

  useEffect(() => {
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    } else {
      setShowGuideModal(true);
    }
  };

  const copyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedSnippet(id);
    setTimeout(() => setCopiedSnippet(''), 2500);
  };

  const androidManifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.shahid.helectricianpro">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="H Electrician Pro"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.HElectricianPro">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.HElectricianPro.Fullscreen">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const mainActivityKotlin = `package com.shahid.helectricianpro

import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK

        webView.webViewClient = WebViewClient()
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}`;

  return (
    <>
      <button
        onClick={handleInstallClick}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#B87333] to-[#E8A85C] hover:opacity-95 text-[#050F1E] text-xs font-bold shadow-md shadow-[#E8A85C]/20 transition cursor-pointer"
      >
        <Smartphone className="w-4 h-4" />
        <span>{isInstalled ? 'App Ready (انسٹال شدہ)' : 'Install APK / App'}</span>
      </button>

      {/* APK Guide & Source Code Modal */}
      {showGuideModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-fadeIn">
          <div className="w-full max-w-2xl rounded-2xl bg-[#0A1E3C] border-2 border-[#E8A85C] shadow-2xl p-5 text-white flex flex-col max-h-[90vh] overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-[#1E4680]">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#E8A85C]/20 text-[#E8A85C]">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-white font-sans">
                    Android APK & Installation Ready | موبائل میں انسٹال کریں
                  </h3>
                  <p className="text-xs text-slate-300 font-urdu">
                    100% آف لائن اینڈرائڈ ایپ - کوئی انٹرنیٹ درکار نہیں
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowGuideModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#163768] transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto py-3 space-y-4 pr-1 text-xs">
              {/* Method 1: Instant Chrome 1-Click Install */}
              <div className="p-3.5 rounded-xl bg-[#0F294E] border border-[#1E4680]">
                <div className="flex items-center gap-2 text-[#E8A85C] font-bold text-sm mb-1.5">
                  <Download className="w-4 h-4" />
                  <span>طریقہ نمبر 1: براہِ راست موبائل ہوم سکرین پر انسٹال کریں (Instant PWA)</span>
                </div>
                <p className="text-slate-300 font-urdu leading-relaxed">
                  1. اپنے موبائل میں کروم (Chrome) براؤزر پر اوپر دائیں کونے میں تین نقطوں (⋮) پر کلک کریں۔<br />
                  2. مینو میں سے <strong className="text-white">"Install app"</strong> یا <strong className="text-white">"Add to Home screen"</strong> منتخب کریں۔<br />
                  3. موبائل ہوم سکرین پر کاپر پائپ والے 'H' لوگو کے ساتھ ایپ انسٹال ہو جائے گی اور بغیر انٹرنیٹ کے کھلے گی!
                </p>
              </div>

              {/* Method 2: Android Studio APK Build Ready Source Files */}
              <div className="p-3.5 rounded-xl bg-[#0F294E] border border-[#1E4680]">
                <div className="flex items-center gap-2 text-[#38BDF8] font-bold text-sm mb-2">
                  <Code className="w-4 h-4" />
                  <span>Android Studio APK Source Code Files (مکمل سورس کوڈ)</span>
                </div>
                <p className="text-slate-300 mb-3 font-urdu">
                  اگر آپ اس ایپ کی باقاعدہ .APK فائل بنانا چاہتے ہیں تو اینڈرائڈ اسٹوڈیو میں درج ذیل کوڈ کاپی کریں:
                </p>

                {/* AndroidManifest.xml */}
                <div className="mb-3">
                  <div className="flex items-center justify-between pb-1 text-slate-300 font-mono text-[11px]">
                    <span>AndroidManifest.xml</span>
                    <button
                      onClick={() => copyCode(androidManifestXml, 'manifest')}
                      className="flex items-center gap-1 text-[#E8A85C] hover:underline"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      {copiedSnippet === 'manifest' ? 'Copied!' : 'Copy XML'}
                    </button>
                  </div>
                  <pre className="p-2.5 rounded-lg bg-[#071326] text-slate-300 font-mono text-[10px] overflow-x-auto border border-slate-700">
                    {androidManifestXml}
                  </pre>
                </div>

                {/* MainActivity.kt */}
                <div>
                  <div className="flex items-center justify-between pb-1 text-slate-300 font-mono text-[11px]">
                    <span>MainActivity.kt (Kotlin Offline WebView)</span>
                    <button
                      onClick={() => copyCode(mainActivityKotlin, 'kotlin')}
                      className="flex items-center gap-1 text-[#E8A85C] hover:underline"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      {copiedSnippet === 'kotlin' ? 'Copied!' : 'Copy Kotlin'}
                    </button>
                  </div>
                  <pre className="p-2.5 rounded-lg bg-[#071326] text-slate-300 font-mono text-[10px] overflow-x-auto border border-slate-700">
                    {mainActivityKotlin}
                  </pre>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="pt-3 border-t border-[#1E4680] flex justify-end">
              <button
                onClick={() => setShowGuideModal(false)}
                className="px-4 py-2 rounded-xl bg-[#163768] hover:bg-[#1E4680] font-bold text-xs text-white"
              >
                Close (بند کریں)
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
