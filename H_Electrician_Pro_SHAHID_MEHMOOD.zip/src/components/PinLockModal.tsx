import React, { useState, useEffect } from 'react';
import { Lock, Unlock, Delete, ShieldAlert, Sparkles, KeyRound } from 'lucide-react';
import { StorageService } from '../services/storage';

interface PinLockModalProps {
  isOpen: boolean;
  onUnlocked: () => void;
  title?: string;
  subtitle?: string;
  canCancel?: boolean;
  onCancel?: () => void;
}

export const PinLockModal: React.FC<PinLockModalProps> = ({
  isOpen,
  onUnlocked,
  title = 'Owner PIN Lock | مالک کا ذاتی لاک',
  subtitle = 'Enter 4-digit PIN to access private data (Default: 7860)',
  canCancel = false,
  onCancel,
}) => {
  const [pinInput, setPinInput] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [showForgotHint, setShowForgotHint] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setPinInput('');
      setErrorMsg('');
      setShowForgotHint(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleKeyPress = (num: string) => {
    if (pinInput.length < 4) {
      const nextPin = pinInput + num;
      setPinInput(nextPin);
      setErrorMsg('');

      if (nextPin.length === 4) {
        verifyPin(nextPin);
      }
    }
  };

  const handleDelete = () => {
    setPinInput((prev) => prev.slice(0, -1));
    setErrorMsg('');
  };

  const handleClear = () => {
    setPinInput('');
    setErrorMsg('');
  };

  const verifyPin = (pinToTest: string) => {
    const settings = StorageService.getSettings();
    const correctPin = settings.pin || '7860';

    if (pinToTest === correctPin) {
      // Success
      setPinInput('');
      setErrorMsg('');
      onUnlocked();
    } else {
      setErrorMsg('غلط پن کوڈ! دوبارہ کوشش کریں (Incorrect PIN)');
      setPinInput('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-fadeIn">
      <div className="w-full max-w-sm rounded-2xl bg-gradient-to-b from-[#0B172E] to-[#070F1E] border border-[#1E3A70] shadow-2xl p-6 text-white text-center relative overflow-hidden">
        {/* Decorative Top Glow */}
        <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-48 h-48 bg-[#0EA5E9]/15 rounded-full blur-3xl pointer-events-none" />

        {/* Lock Icon */}
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#0F2042] border border-[#0EA5E9] text-[#38BDF8] shadow-lg mb-4">
          <Lock className="w-8 h-8" />
        </div>

        <h2 className="text-xl font-bold tracking-wide text-white font-sans">{title}</h2>
        <p className="text-xs text-slate-300 mt-1">{subtitle}</p>
        <p className="text-xs text-[#E8A85C] font-urdu mt-0.5">شاہد الیکٹریشن - ذاتی ریکارڈ محفوظ ہے</p>

        {/* PIN Dots Display */}
        <div className="flex justify-center items-center gap-4 my-6">
          {[0, 1, 2, 3].map((index) => {
            const isFilled = pinInput.length > index;
            return (
              <div
                key={index}
                className={`w-4 h-4 rounded-full transition-all duration-200 border-2 ${
                  isFilled
                    ? 'bg-[#0EA5E9] border-[#38BDF8] scale-125 shadow-[0_0_12px_#0EA5E9]'
                    : 'bg-[#070F1E] border-slate-600'
                }`}
              />
            );
          })}
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="mb-4 py-1.5 px-3 rounded-lg bg-red-950/80 border border-red-500 text-red-200 text-xs font-semibold animate-shake">
            {errorMsg}
          </div>
        )}

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-3 max-w-[260px] mx-auto">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              onClick={() => handleKeyPress(digit)}
              className="h-14 rounded-xl bg-[#0F2042] hover:bg-[#162C58] active:scale-95 text-2xl font-bold font-mono text-white border border-[#1E3A70] hover:border-[#0EA5E9] transition shadow flex items-center justify-center cursor-pointer"
            >
              {digit}
            </button>
          ))}
          <button
            onClick={handleClear}
            className="h-14 rounded-xl bg-[#070F1E] hover:bg-[#162C58] active:scale-95 text-xs font-semibold text-slate-300 border border-[#1E3A70] transition flex items-center justify-center cursor-pointer"
          >
            Clear
          </button>
          <button
            onClick={() => handleKeyPress('0')}
            className="h-14 rounded-xl bg-[#0F2042] hover:bg-[#162C58] active:scale-95 text-2xl font-bold font-mono text-white border border-[#1E3A70] hover:border-[#0EA5E9] transition shadow flex items-center justify-center cursor-pointer"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="h-14 rounded-xl bg-[#070F1E] hover:bg-red-900/40 active:scale-95 text-red-400 border border-[#1E3A70] transition flex items-center justify-center cursor-pointer"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Forgot PIN / Reset Hint */}
        <div className="mt-5 pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs">
          <button
            onClick={() => setShowForgotHint(!showForgotHint)}
            className="text-[#E8A85C] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <KeyRound className="w-3.5 h-3.5" />
            Default PIN: 7860
          </button>

          {canCancel && onCancel && (
            <button
              onClick={onCancel}
              className="text-slate-400 hover:text-white px-3 py-1 rounded cursor-pointer"
            >
              Cancel
            </button>
          )}
        </div>

        {showForgotHint && (
          <div className="mt-3 p-2.5 rounded-lg bg-[#071326] border border-[#E8A85C]/30 text-left text-xs text-slate-300">
            <p className="font-semibold text-[#E8A85C]">Owner Shahid Electrician Master Key:</p>
            <p className="mt-1">
              The default code is <span className="font-bold text-white font-mono text-sm">7860</span>. You can change your PIN at any time inside the app Settings!
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
