import React, { useState } from 'react';
import {
  X,
  Calculator,
  BookOpen,
  GitFork,
  Cpu,
  Radar,
  Gauge,
  Wind,
  Building,
  Flame,
  ArrowUpDown,
  Layers,
  Box,
  ShieldAlert,
  Wrench,
  FileText,
  DollarSign,
  Download,
  HardDrive,
  ChevronDown,
  ChevronRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { MODULES_CATALOG } from '../data/modules';
import { ModuleId, ModuleInfo } from '../types';

interface SideDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeModule: ModuleId;
  onSelectModule: (id: ModuleId) => void;
  onOpenRates: () => void;
  onOpenApkGuide: () => void;
  onOpenBackup: () => void;
}

const ICON_MAP: Record<string, React.ReactNode> = {
  Calculator: <Calculator className="w-4 h-4" />,
  BookOpen: <BookOpen className="w-4 h-4" />,
  GitFork: <GitFork className="w-4 h-4" />,
  Cpu: <Cpu className="w-4 h-4" />,
  Radar: <Radar className="w-4 h-4" />,
  Gauge: <Gauge className="w-4 h-4" />,
  Wind: <Wind className="w-4 h-4" />,
  Building: <Building className="w-4 h-4" />,
  Flame: <Flame className="w-4 h-4" />,
  ArrowUpDown: <ArrowUpDown className="w-4 h-4" />,
  Layers: <Layers className="w-4 h-4" />,
  Box: <Box className="w-4 h-4" />,
  ShieldAlert: <ShieldAlert className="w-4 h-4" />,
  Wrench: <Wrench className="w-4 h-4" />,
  FileText: <FileText className="w-4 h-4" />,
};

interface CategoryGroup {
  id: string;
  name: string;
  nameUrdu: string;
  modules: ModuleInfo[];
}

export const SideDrawer: React.FC<SideDrawerProps> = ({
  isOpen,
  onClose,
  activeModule,
  onSelectModule,
  onOpenRates,
  onOpenApkGuide,
  onOpenBackup,
}) => {
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({
    core: true,
    automation: true,
    systems: true,
    field: true,
  });

  if (!isOpen) return null;

  const toggleCategory = (catId: string) => {
    setExpandedCategories((prev) => ({
      ...prev,
      [catId]: !prev[catId],
    }));
  };

  const categories: CategoryGroup[] = [
    {
      id: 'core',
      name: 'Power & Calculators',
      nameUrdu: 'پاور و حساب',
      modules: MODULES_CATALOG.filter((m) => m.category === 'core'),
    },
    {
      id: 'automation',
      name: 'Industrial Automation',
      nameUrdu: 'انڈسٹریل آٹومیشن',
      modules: MODULES_CATALOG.filter((m) => m.category === 'automation'),
    },
    {
      id: 'systems',
      name: 'Building & Facilities',
      nameUrdu: 'بلڈنگ و ایچ وی اے سی',
      modules: MODULES_CATALOG.filter((m) => m.category === 'systems'),
    },
    {
      id: 'field',
      name: 'Safety & Field Diary',
      nameUrdu: 'سیفٹی و کسٹمر کھاتہ',
      modules: MODULES_CATALOG.filter((m) => m.category === 'field_work'),
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
      />

      {/* Drawer Body */}
      <div className="relative w-full max-w-xs sm:max-w-sm bg-[#070F1E] border-r border-[#1E3A70] shadow-2xl flex flex-col h-full z-10 text-white animate-slideRight">
        {/* Drawer Header */}
        <div className="p-4 bg-[#0B172E] border-b border-[#1E3A70] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#070F1E] border border-[#E8A85C] p-1 flex items-center justify-center shadow-md">
              <img src="/icon.svg" alt="H Logo" className="w-full h-full object-contain" />
            </div>
            <div>
              <h2 className="font-extrabold text-base text-white tracking-wide font-sans">
                H Electrician <span className="text-[#38BDF8]">Pro</span>
              </h2>
              <p className="text-xs text-[#E8A85C] font-urdu leading-none mt-0.5">
                شاہد الیکٹریشن · 15 ماڈیولز
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#162C58] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Owner Secret Shortcuts Bar */}
        <div className="p-3 bg-[#091427] border-b border-[#1E3A70] flex items-center gap-2">
          <button
            onClick={() => {
              onClose();
              onOpenRates();
            }}
            className="flex-1 py-2 px-2.5 rounded-xl bg-gradient-to-r from-[#B87333]/25 to-[#E8A85C]/25 hover:from-[#B87333]/40 hover:to-[#E8A85C]/40 border border-[#E8A85C]/40 text-[#E8A85C] text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer shadow-sm"
          >
            <DollarSign className="w-4 h-4" />
            <span className="font-urdu">میری ریٹ لسٹ (PIN)</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onSelectModule('work_diary');
            }}
            className="py-2 px-3 rounded-xl bg-[#0B172E] hover:bg-[#162C58] border border-[#1E3A70] text-slate-200 text-xs font-medium flex items-center gap-1.5 transition cursor-pointer"
          >
            <FileText className="w-4 h-4 text-[#38BDF8]" />
            <span className="font-urdu">ڈائری</span>
          </button>
        </div>

        {/* 15 Modules Categorized Accordion */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {categories.map((cat) => {
            const isExpanded = expandedCategories[cat.id] ?? true;
            return (
              <div key={cat.id} className="space-y-1">
                {/* Section Header */}
                <button
                  onClick={() => toggleCategory(cat.id)}
                  className="w-full flex items-center justify-between px-2 py-1 text-left text-slate-400 hover:text-slate-200 text-xs font-semibold uppercase tracking-wider cursor-pointer"
                >
                  <div className="flex items-center gap-1.5">
                    <span>{cat.name}</span>
                    <span className="text-[10px] text-[#E8A85C] font-urdu font-normal">({cat.nameUrdu})</span>
                  </div>
                  {isExpanded ? (
                    <ChevronDown className="w-3.5 h-3.5" />
                  ) : (
                    <ChevronRight className="w-3.5 h-3.5" />
                  )}
                </button>

                {/* Modules in this Category */}
                {isExpanded && (
                  <div className="space-y-1">
                    {cat.modules.map((mod) => {
                      const isActive = activeModule === mod.id;
                      return (
                        <button
                          key={mod.id}
                          onClick={() => {
                            onSelectModule(mod.id);
                            onClose();
                          }}
                          className={`w-full p-2.5 rounded-xl text-left transition flex items-center justify-between gap-3 cursor-pointer ${
                            isActive
                              ? 'bg-[#0284C7] text-white font-bold shadow-md shadow-[#0284C7]/30 border border-[#38BDF8]'
                              : 'bg-[#0B172E] hover:bg-[#112547] text-slate-200 border border-[#1E3A70]/70'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div
                              className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${
                                isActive
                                  ? 'bg-white/20 text-white'
                                  : 'bg-[#070F1E] text-[#38BDF8] border border-[#1E3A70]'
                              }`}
                            >
                              {ICON_MAP[mod.iconName] || <Box className="w-3.5 h-3.5" />}
                            </div>
                            <div className="min-w-0 truncate">
                              <div className="flex items-center gap-1.5">
                                <span
                                  className={`text-[9px] font-mono px-1 rounded ${
                                    isActive ? 'bg-white/20 text-white' : 'bg-[#162C58] text-[#38BDF8]'
                                  }`}
                                >
                                  M{mod.moduleNumber}
                                </span>
                                <span className="text-xs font-semibold truncate">{mod.title}</span>
                              </div>
                              <p
                                className={`text-[10px] font-urdu truncate ${
                                  isActive ? 'text-blue-100' : 'text-[#E8A85C]'
                                }`}
                              >
                                {mod.titleUrdu}
                              </p>
                            </div>
                          </div>

                          <span
                            className={`text-[9px] font-mono px-1.5 py-0.5 rounded-md flex-shrink-0 ${
                              isActive ? 'bg-white/20 text-white' : 'bg-[#070F1E] text-slate-400'
                            }`}
                          >
                            {mod.topicsCount}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Drawer Footer Actions */}
        <div className="p-3 bg-[#0B172E] border-t border-[#1E3A70] space-y-2 text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onOpenApkGuide();
              }}
              className="flex-1 py-2 px-2 rounded-lg bg-[#070F1E] hover:bg-[#162C58] text-slate-200 font-semibold flex items-center justify-center gap-1.5 border border-[#1E3A70] transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span>Android APK Guide</span>
            </button>
            <button
              onClick={() => {
                onClose();
                onOpenBackup();
              }}
              className="py-2 px-2.5 rounded-lg bg-[#070F1E] hover:bg-[#162C58] text-slate-200 font-semibold flex items-center gap-1.5 border border-[#1E3A70] transition cursor-pointer"
              title="Backup & Restore Database"
            >
              <HardDrive className="w-3.5 h-3.5 text-[#E8A85C]" />
              <span>Backup</span>
            </button>
          </div>

          <div className="text-center text-[10px] text-slate-400 font-mono">
            100% OFFLINE SQLITE · 2026 PRO EDITION
          </div>
        </div>
      </div>
    </div>
  );
};
