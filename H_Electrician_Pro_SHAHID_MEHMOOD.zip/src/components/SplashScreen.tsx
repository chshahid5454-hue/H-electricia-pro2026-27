import React, { useEffect, useState } from 'react';
import { Zap, Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState<number>(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 400);
          return 100;
        }
        return prev + 15;
      });
    }, 150);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#071426] text-white p-6 select-none overflow-hidden animate-fadeIn">
      {/* Background Circuit Texture Ambient Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#E8A85C]/15 rounded-full blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute bottom-10 left-10 w-72 h-72 bg-[#2563EB]/15 rounded-full blur-3xl pointer-events-none" />

      {/* Launcher Icon with Copper Pipe H and Glowing LED Bulb */}
      <div className="relative mb-6">
        <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-3xl bg-[#0A1E3C] border-3 border-[#E8A85C] p-2 shadow-2xl flex items-center justify-center relative overflow-hidden group">
          <img
            src="/icon.svg"
            alt="H Electrician Pro Logo"
            className="w-full h-full object-contain animate-pulse"
          />
        </div>
        {/* Glow halo */}
        <div className="absolute -inset-2 bg-gradient-to-r from-[#B87333] via-[#E8A85C] to-[#B87333] rounded-3xl blur-md opacity-40 -z-10" />
      </div>

      {/* Opening invocation and owner introduction */}
      <div className="text-center space-y-2 max-w-sm mb-5">
        <p
          className="text-xl sm:text-2xl font-bold text-[#F7C58B] font-urdu"
          lang="ur"
          dir="rtl"
        >
          بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ
        </p>
        <p className="text-sm sm:text-base text-slate-200 font-urdu leading-relaxed" lang="ur" dir="rtl">
          السلام علیکم! میرا نام شاہد محمود (SHAHID MEHMOOD) ہے۔ میں الیکٹریکل ٹیکنیشن ہوں۔ اس ایپ کا مقصد الیکٹریکل ٹولز،
          وائرنگ، سیفٹی، فالٹ فائنڈنگ اور انڈسٹریل آٹومیشن سیکھنے میں مدد دینا ہے۔
        </p>
      </div>

      {/* App Title & Branding */}
      <div className="text-center space-y-2 max-w-sm">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#163768] border border-[#1E4680] text-[#E8A85C] text-xs font-bold font-mono">
          <Zap className="w-3.5 h-3.5" />
          INDUSTRIAL ENCYCLOPEDIA
        </div>

        <h1 className="text-2xl sm:text-3xl font-black tracking-wide text-white font-sans">
          H Electrician <span className="text-[#E8A85C]">Pro</span>
        </h1>

        <p className="text-sm text-[#E8A85C] font-urdu font-semibold">
          SHAHID MEHMOOD · شاہد الیکٹریشن - برقی انسائیکلوپیڈیا
        </p>

        <p className="text-xs text-slate-400">
          100% Offline SQLite Architecture • Ready for Android APK
        </p>
      </div>

      {/* Loading Progress Bar */}
      <div className="w-64 max-w-xs mt-8 space-y-2">
        <div className="w-full h-2 rounded-full bg-[#0F294E] border border-[#1E4680] overflow-hidden p-0.5">
          <div
            className="h-full rounded-full bg-gradient-to-r from-[#B87333] via-[#E8A85C] to-[#F7C58B] transition-all duration-200"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
          <span>Loading 15 Modules...</span>
          <span className="text-[#E8A85C] font-bold">{progress}%</span>
        </div>
      </div>
    </div>
  );
};
