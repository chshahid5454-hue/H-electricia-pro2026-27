import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  X,
  Volume2,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Radio,
  ArrowRight,
} from 'lucide-react';
import { ModuleId } from '../types';

export interface VoiceCommandMatch {
  action: 'open_diagram' | 'open_module' | 'open_rates';
  diagramType?: string;
  diagramId?: string;
  moduleId?: ModuleId;
  title: string;
  titleUrdu: string;
  detectedKeyword: string;
}

interface VoiceSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExecuteCommand: (match: VoiceCommandMatch) => void;
}

export const VoiceSearchModal: React.FC<VoiceSearchModalProps> = ({
  isOpen,
  onClose,
  onExecuteCommand,
}) => {
  const [isListening, setIsListening] = useState<boolean>(false);
  const [transcript, setTranscript] = useState<string>('');
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [recognizedMatch, setRecognizedMatch] = useState<VoiceCommandMatch | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [selectedLang, setSelectedLang] = useState<'ur-PK' | 'en-US'>('ur-PK');

  const recognitionRef = useRef<any>(null);

  // Command quick examples
  const commandShortcuts: { label: string; labelUrdu: string; query: string }[] = [
    { label: 'Star Delta', labelUrdu: 'سٹار ڈیلٹا', query: 'Star Delta' },
    { label: 'VFD Drive', labelUrdu: 'وی ایف ڈی ڈرائیو', query: 'Bhai VFD wala diagram kholo' },
    { label: 'Lift & ARD', labelUrdu: 'لفٹ ریسکیو وائرنگ', query: 'Lift ARD' },
    { label: 'Fire Alarm', labelUrdu: 'فائر الارم لوپ', query: 'Fire alarm loop' },
    { label: 'PLC S7-1200', labelUrdu: 'پی ایل سی کنٹرولر', query: 'PLC S7-1200' },
    { label: 'Sensor PNP/NPN', labelUrdu: 'سینسر کنکشنز', query: 'Sensor PNP NPN' },
    { label: 'ATS Generator', labelUrdu: 'اے ٹی ایس جنریٹر', query: 'ATS Wapda Generator' },
    { label: 'APFC Capacitor', labelUrdu: 'پاور فیکٹر پینل', query: 'APFC Capacitor Bill' },
    { label: 'Chiller & HVAC', labelUrdu: 'چلر اور ایچ وی اے سی', query: 'Chiller HVAC AHU' },
    { label: 'My Rates', labelUrdu: 'میری ریٹ لسٹ', query: 'Electrician Rates Hisab Paisa' },
    { label: 'Fault Guru', labelUrdu: 'فالٹ ٹریسنگ خرابی', query: 'Fault Guru Kharabi' },
  ];

  // Logic Parser strictly matching prompt rules:
  // if voice_input contains "star" or "delta" -> show Star-Delta Diagram
  // if "vfd" or "drive" -> show VFD Diagram
  // if "lift" or "ard" -> show Lift Diagram
  // if "fire" -> show Fire Alarm Loop Diagram
  // if "plc" or "motor" -> show PLC S7-1200 Diagram
  // if "sensor" or "pnp" -> show PNP vs NPN Diagram
  // if "ats" or "wapda" or "generator" -> show ATS Diagram
  // if "apfc" or "capacitor" or "bill" -> show APFC Diagram
  // if "chiller" or "hvac" or "ahu" -> show HVAC Diagram
  // if "rate" or "paisa" or "hisab" -> show My Rates Sheet
  // if "fault" or "kharabi" -> show Fault Guru Sheet
  const evaluateVoiceText = (rawText: string): VoiceCommandMatch | null => {
    const text = rawText.toLowerCase().trim();

    if (text.includes('star') || text.includes('delta')) {
      return {
        action: 'open_diagram',
        diagramType: 'star_delta_power',
        diagramId: 'star-delta-power',
        title: 'Star-Delta Motor Starter Diagram',
        titleUrdu: 'سٹار ڈیلٹا موٹر سٹارٹر ڈایاگرام',
        detectedKeyword: 'Star / Delta',
      };
    }

    if (text.includes('vfd') || text.includes('drive')) {
      return {
        action: 'open_diagram',
        diagramType: 'vfd_power_control',
        diagramId: 'vfd-power-control',
        title: 'VFD Power & Multi-Speed Control Diagram',
        titleUrdu: 'وی ایف ڈی پاور و کنٹرول وائرنگ',
        detectedKeyword: 'VFD / Drive',
      };
    }

    if (text.includes('lift') || text.includes('ard') || text.includes('elevator')) {
      return {
        action: 'open_diagram',
        diagramType: 'lift_ard_power',
        diagramId: 'lift-ard-power',
        title: 'Elevator Safety Chain & ARD Power Diagram',
        titleUrdu: 'لفٹ سیفٹی چین اور اے آر ڈی ریسکیو',
        detectedKeyword: 'Lift / ARD',
      };
    }

    if (text.includes('fire') || text.includes('alarm') || text.includes('aag')) {
      return {
        action: 'open_diagram',
        diagramType: 'fire_addressable_loop',
        diagramId: 'fire-addressable-loop',
        title: 'Fire Alarm Addressable SLC Loop Diagram',
        titleUrdu: 'فائر الارم ایڈریسیبل لوپ ڈایاگرام',
        detectedKeyword: 'Fire Alarm',
      };
    }

    if (text.includes('plc') || text.includes('motor') || text.includes('s7')) {
      return {
        action: 'open_diagram',
        diagramType: 'plc_s7_inputs',
        diagramId: 'plc-s7-inputs',
        title: 'Siemens S7-1200 PLC Wiring & Ladder Diagram',
        titleUrdu: 'سیمنز پی ایل سی ان پٹ و آؤٹ پٹ وائرنگ',
        detectedKeyword: 'PLC / Motor',
      };
    }

    if (text.includes('sensor') || text.includes('pnp') || text.includes('npn') || text.includes('proximity')) {
      return {
        action: 'open_diagram',
        diagramType: 'sensor_pnp_npn',
        diagramId: 'sensor-pnp-npn',
        title: 'PNP vs NPN Proximity Sensor Wiring Diagram',
        titleUrdu: 'پی این پی اور این پی این سینسر وائرنگ',
        detectedKeyword: 'Sensor / PNP / NPN',
      };
    }

    if (text.includes('ats') || text.includes('wapda') || text.includes('generator') || text.includes('changeover')) {
      return {
        action: 'open_diagram',
        diagramType: 'ats',
        diagramId: 'ats-generator',
        title: 'Automatic Transfer Switch (ATS) WAPDA/Generator Diagram',
        titleUrdu: 'اے ٹی ایس چینج اوور (واپڈا / جنریٹر) ڈایاگرام',
        detectedKeyword: 'ATS / WAPDA / Generator',
      };
    }

    if (text.includes('apfc') || text.includes('capacitor') || text.includes('bill') || text.includes('factor')) {
      return {
        action: 'open_diagram',
        diagramType: 'apfc_panel',
        diagramId: 'apfc-power-factor',
        title: 'Automatic Power Factor Correction (APFC) Panel Diagram',
        titleUrdu: 'اے پی ایف سی کپیسیٹر بینک اور بل سیونگ پینل',
        detectedKeyword: 'APFC / Capacitor / Bill',
      };
    }

    if (text.includes('chiller') || text.includes('hvac') || text.includes('ahu') || text.includes('ac')) {
      return {
        action: 'open_diagram',
        diagramType: 'chiller_plant_bms',
        diagramId: 'chiller-plant-bms',
        title: 'HVAC Chiller Plant & BMS Integration Diagram',
        titleUrdu: 'ایچ وی اے سی چلر پلانٹ و بی ایم ایس انضمام',
        detectedKeyword: 'Chiller / HVAC / AHU',
      };
    }

    if (text.includes('rate') || text.includes('paisa') || text.includes('hisab') || text.includes('qeemat')) {
      return {
        action: 'open_rates',
        title: 'Owner Rates Sheet (ریٹ لسٹ)',
        titleUrdu: 'شاہد الیکٹریشن ریٹ لسٹ و چارجز',
        detectedKeyword: 'Rates / Paisa / Hisab',
      };
    }

    if (text.includes('fault') || text.includes('kharabi') || text.includes('masla') || text.includes('trouble')) {
      return {
        action: 'open_module',
        moduleId: 'fault_finding',
        title: 'Fault Guru & Troubleshooting Sheet',
        titleUrdu: 'فالٹ فائنڈنگ اور برقی خرابیوں کا حل',
        detectedKeyword: 'Fault / Kharabi',
      };
    }

    return null;
  };

  const processSpokenText = (text: string) => {
    setTranscript(text);
    const match = evaluateVoiceText(text);
    if (match) {
      setRecognizedMatch(match);
      setErrorMessage(null);
      // Auto-trigger navigation after a brief feedback delay
      setTimeout(() => {
        onExecuteCommand(match);
        onClose();
      }, 900);
    } else {
      setErrorMessage(`Not matched yet. Bolein: "Star Delta", "VFD", "Lift", "Fire", "PLC", "Sensor", "ATS", "APFC", "Chiller", "Rates", "Fault"`);
    }
  };

  const startListening = () => {
    setErrorMessage(null);
    setTranscript('');
    setInterimTranscript('');
    setRecognizedMatch(null);

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setErrorMessage('Speech recognition is not supported in this browser. You can click any shortcut button below to test!');
      return;
    }

    try {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }

      const recognition = new SpeechRecognition();
      recognition.lang = selectedLang;
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.maxAlternatives = 3;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        if (interim) {
          setInterimTranscript(interim);
          // Also try early match on interim results for lightning fast UX
          const interimMatch = evaluateVoiceText(interim);
          if (interimMatch && !recognizedMatch) {
            setRecognizedMatch(interimMatch);
          }
        }

        if (final) {
          processSpokenText(final);
        }
      };

      recognition.onerror = (event: any) => {
        setIsListening(false);
        if (event.error === 'not-allowed') {
          setErrorMessage('Microphone permission was denied. Please allow microphone in browser or tap any command button below.');
        } else if (event.error === 'no-speech') {
          setErrorMessage('No voice detected. Please speak clearly into the microphone.');
        } else {
          setErrorMessage(`Listening ended: ${event.error}. You can also click the quick buttons below.`);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      setIsListening(false);
      setErrorMessage('Could not initialize microphone. Please click any shortcut command below.');
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  // Auto-start listening on open
  useEffect(() => {
    if (isOpen) {
      startListening();
    } else {
      stopListening();
    }
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, [isOpen, selectedLang]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-4 animate-fadeIn">
      <div className="w-full max-w-lg rounded-3xl bg-[#09172E] border-2 border-[#0284C7] shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 bg-[#0F2445] border-b border-[#1E3E75] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#0284C7]/20 border border-[#38BDF8] flex items-center justify-center text-xl">
              🎤
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg text-white font-sans flex items-center gap-2">
                بول کے دکھاؤ <span className="text-[#38BDF8]">| Voice Search</span>
              </h3>
              <p className="text-[11px] text-[#E8A85C] font-urdu">
                بولیے اور فوراً مطلوبہ ایچ ڈی ڈایاگرام یا ریٹ شیٹ کھولیے
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language toggle for speech engine */}
            <button
              onClick={() => setSelectedLang(selectedLang === 'ur-PK' ? 'en-US' : 'ur-PK')}
              title="Toggle Recognition Accent (Urdu / English)"
              className="px-2 py-1 rounded-lg bg-[#071326] border border-[#1E3A70] text-[11px] font-bold text-[#38BDF8] hover:text-white transition cursor-pointer"
            >
              {selectedLang === 'ur-PK' ? 'Urdu (پاکستان)' : 'English (US)'}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Central Visualizer Area */}
        <div className="p-6 flex flex-col items-center justify-center text-center space-y-4 bg-gradient-to-b from-[#09172E] to-[#061022]">
          {/* Big Glowing Mic Button */}
          <div className="relative">
            {isListening && (
              <>
                <span className="absolute -inset-4 rounded-full bg-[#0284C7]/20 animate-ping" />
                <span className="absolute -inset-8 rounded-full bg-[#38BDF8]/10 animate-pulse" />
              </>
            )}

            <button
              onClick={isListening ? stopListening : startListening}
              className={`relative z-10 w-24 h-24 rounded-full flex flex-col items-center justify-center transition-all duration-300 shadow-2xl cursor-pointer ${
                isListening
                  ? 'bg-gradient-to-tr from-[#0284C7] to-[#38BDF8] text-white ring-4 ring-[#38BDF8]/50 scale-105'
                  : 'bg-[#0F2445] text-slate-300 hover:text-white border-2 border-[#1E3E75] hover:border-[#38BDF8]'
              }`}
            >
              {isListening ? (
                <>
                  <Mic className="w-10 h-10 animate-bounce" />
                  <span className="text-[10px] font-bold uppercase tracking-wider mt-1 font-mono">Listening...</span>
                </>
              ) : (
                <>
                  <MicOff className="w-9 h-9" />
                  <span className="text-[10px] font-bold uppercase tracking-wider mt-1 font-mono">Tap to Speak</span>
                </>
              )}
            </button>
          </div>

          {/* Sound Wave Frequency Bars (Simulated active speech visualization) */}
          {isListening && (
            <div className="flex items-center gap-1.5 h-6">
              {[40, 75, 95, 60, 100, 80, 50, 90, 70, 30].map((h, i) => (
                <span
                  key={i}
                  style={{
                    height: `${h}%`,
                    animationDelay: `${i * 0.1}s`,
                  }}
                  className="w-1 rounded-full bg-gradient-to-t from-[#0284C7] to-[#E8A85C] animate-pulse"
                />
              ))}
            </div>
          )}

          {/* Live Transcript / Feedback */}
          <div className="w-full min-h-[56px] p-3 rounded-2xl bg-[#0B1A33] border border-[#1E3E75] flex items-center justify-center">
            {recognizedMatch ? (
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm animate-fadeIn">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span>
                  پہچان لیا: {recognizedMatch.title} ({recognizedMatch.detectedKeyword})
                </span>
              </div>
            ) : transcript || interimTranscript ? (
              <div className="space-y-0.5">
                <p className="text-xs text-slate-400 font-urdu">آپ نے فرمایا:</p>
                <p className="text-sm font-bold text-white font-mono">
                  "{transcript || interimTranscript}"
                </p>
              </div>
            ) : (
              <p className="text-xs text-slate-400 font-urdu">
                {isListening
                  ? 'بولیں... جیسے: "Bhai VFD wala diagram kholo" یا "Star Delta"'
                  : 'مائیک پر کلک کریں اور بولیں'}
              </p>
            )}
          </div>

          {/* Error Message if any */}
          {errorMessage && (
            <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-600/50 text-amber-300 text-xs flex items-center gap-2 text-left">
              <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
              <span>{errorMessage}</span>
            </div>
          )}
        </div>

        {/* Quick Shortcut Buttons for Electricians */}
        <div className="p-4 bg-[#071326] border-t border-[#1E3E75] space-y-2">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium">
            <span className="flex items-center gap-1 text-[#38BDF8]">
              <Sparkles className="w-3.5 h-3.5" /> یا نیچے کلک کر کے فوری ٹیسٹ کریں:
            </span>
            <span className="font-urdu text-[#E8A85C]">11 فوری احکامات</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {commandShortcuts.map((item, idx) => (
              <button
                key={idx}
                onClick={() => processSpokenText(item.query)}
                className="p-2 rounded-xl bg-[#0F2042] hover:bg-[#162C58] border border-[#1E3A70] hover:border-[#38BDF8] text-left transition flex items-center justify-between group cursor-pointer"
              >
                <div className="min-w-0 pr-1">
                  <div className="text-xs font-bold text-white group-hover:text-[#38BDF8] truncate font-sans">
                    {item.label}
                  </div>
                  <div className="text-[10px] text-[#E8A85C] font-urdu truncate">
                    {item.labelUrdu}
                  </div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white shrink-0 group-hover:translate-x-0.5 transition" />
              </button>
            ))}
          </div>
        </div>

        {/* Voice Search Hint Footer */}
        <div className="px-5 py-2.5 bg-[#050D1A] border-t border-[#162C58] text-[11px] text-slate-400 flex items-center justify-between font-urdu">
          <span>اردو اور انگریزی دونوں میں کام کرتا ہے</span>
          <span className="text-[#38BDF8]">H Electrician Pro · شاہد الیکٹریشن</span>
        </div>
      </div>
    </div>
  );
};
