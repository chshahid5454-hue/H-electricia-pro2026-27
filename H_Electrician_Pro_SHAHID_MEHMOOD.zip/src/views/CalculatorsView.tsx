import React, { useState } from 'react';
import {
  Calculator,
  RotateCcw,
  Copy,
  Check,
  Edit3,
  HelpCircle,
  Lightbulb,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { CALCULATORS_DATA, CalculatorConfig } from '../data/calculatorsData';
import { OwnerNotesModal } from '../components/OwnerNotesModal';
import { StorageService } from '../services/storage';

export const CalculatorsView: React.FC = () => {
  const [activeCalcId, setActiveCalcId] = useState<string>(CALCULATORS_DATA[0].id);
  const [inputValues, setInputValues] = useState<Record<string, Record<string, number | string>>>(() => {
    const init: Record<string, Record<string, number | string>> = {};
    CALCULATORS_DATA.forEach((calc) => {
      init[calc.id] = {};
      calc.inputs.forEach((inp) => {
        init[calc.id][inp.id] = inp.defaultValue;
      });
    });
    return init;
  });

  const [copied, setCopied] = useState<boolean>(false);
  const [activeNoteTopic, setActiveNoteTopic] = useState<{ id: string; title: string; titleUrdu: string } | null>(null);

  const currentCalc = CALCULATORS_DATA.find((c) => c.id === activeCalcId) || CALCULATORS_DATA[0];
  const currentInputs = inputValues[currentCalc.id] || {};
  const result = currentCalc.calculate(currentInputs);

  const handleInputChange = (calcId: string, inputId: string, value: number | string) => {
    setInputValues((prev) => ({
      ...prev,
      [calcId]: {
        ...(prev[calcId] || {}),
        [inputId]: value,
      },
    }));
  };

  const handleResetInputs = () => {
    const defaultObj: Record<string, number | string> = {};
    currentCalc.inputs.forEach((inp) => {
      defaultObj[inp.id] = inp.defaultValue;
    });
    setInputValues((prev) => ({
      ...prev,
      [currentCalc.id]: defaultObj,
    }));
  };

  const handleCopyResult = () => {
    const text = `*${currentCalc.title}*\n${result.primaryResult.label}: ${result.primaryResult.value} ${result.primaryResult.unit}\n` +
      result.secondaryResults.map((s) => `${s.label}: ${s.value} ${s.unit}`).join('\n') +
      `\n- Shahid Electrician Pro App`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const hasOwnerNote = Boolean(StorageService.getOwnerNote(currentCalc.id));

  return (
    <div className="space-y-4 pb-12">
      {/* Top Selector Grid */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {CALCULATORS_DATA.map((calc, idx) => {
          const isSelected = calc.id === currentCalc.id;
          return (
            <button
              key={calc.id}
              onClick={() => setActiveCalcId(calc.id)}
              className={`px-3.5 py-2.5 rounded-xl text-left flex-shrink-0 transition-all border cursor-pointer ${
                isSelected
                  ? 'bg-[#0284C7] text-white border-[#38BDF8] font-bold shadow-md shadow-[#0284C7]/20'
                  : 'bg-[#0B172E] hover:bg-[#162C58] text-slate-200 border-[#1E3A70]'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono opacity-80">#{idx + 1}</span>
                <span className="text-xs font-bold whitespace-nowrap">{calc.title.split('(')[0]}</span>
              </div>
              <p className={`text-[11px] font-urdu truncate max-w-[170px] ${isSelected ? 'text-blue-100' : 'text-[#E8A85C]'}`}>
                {calc.titleUrdu.split('(')[0]}
              </p>
            </button>
          );
        })}
      </div>

      {/* Main Calculator Card */}
      <div className="rounded-2xl bg-[#0B172E] border border-[#1E3A70] p-4 sm:p-6 shadow-xl relative overflow-hidden">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#1E3A70]">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg sm:text-xl font-bold text-white font-sans">{currentCalc.title}</h2>
              <span className="text-[10px] bg-[#0284C7]/20 text-[#38BDF8] border border-[#0EA5E9]/40 px-2 py-0.5 rounded-md font-bold font-mono">
                LIVE CALCULATOR
              </span>
            </div>
            <p className="text-xs text-[#E8A85C] font-urdu mt-0.5">{currentCalc.titleUrdu}</p>
            <p className="text-xs text-slate-400 mt-1">{currentCalc.tagline}</p>
          </div>

          {/* Action Buttons: Notes, Reset, Copy */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() =>
                setActiveNoteTopic({
                  id: currentCalc.id,
                  title: currentCalc.title,
                  titleUrdu: currentCalc.titleUrdu,
                })
              }
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition border cursor-pointer ${
                hasOwnerNote
                  ? 'bg-amber-500/20 text-[#E8A85C] border-[#E8A85C]'
                  : 'bg-[#162C58] text-slate-300 border-[#1E3A70] hover:text-white'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5 text-[#E8A85C]" />
              <span className="font-urdu">My Notes {hasOwnerNote && '✓'}</span>
            </button>

            <button
              onClick={handleResetInputs}
              title="Reset inputs to default"
              className="p-2 rounded-xl bg-[#0F2042] hover:bg-[#162C58] text-slate-300 border border-[#1E3A70] text-xs transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={handleCopyResult}
              className="px-3 py-1.5 rounded-xl bg-[#162C58] hover:bg-[#1E3A70] text-slate-200 border border-[#1E3A70] text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-[#38BDF8]" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {/* Formula Bar Banner */}
        <div className="my-4 p-3 rounded-xl bg-[#070F1E] border border-[#1E3A70] flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Calculator className="w-4 h-4 text-[#38BDF8]" />
            <span className="text-xs font-mono font-bold text-[#38BDF8]">{currentCalc.formula}</span>
          </div>
          <span className="text-xs text-slate-300 font-urdu">{currentCalc.formulaUrdu}</span>
        </div>

        {/* Two-Column Grid: Inputs on Left, Results on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Inputs Section */}
          <div className="lg:col-span-6 space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Input Parameters (پیرامیٹرز درج کریں)
            </h3>

            {currentCalc.inputs.map((input) => (
              <div key={input.id} className="p-3.5 rounded-xl bg-[#0F2042] border border-[#1E3A70]">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-white">{input.label}</label>
                  <span className="text-xs font-urdu text-[#E8A85C]">{input.labelUrdu}</span>
                </div>

                {input.options ? (
                  <select
                    value={String(currentInputs[input.id] ?? input.defaultValue)}
                    onChange={(e) => handleInputChange(currentCalc.id, input.id, e.target.value)}
                    className="w-full rounded-lg bg-[#070F1E] border border-[#1E3A70] p-2.5 text-xs text-white focus:border-[#0EA5E9] focus:outline-none font-medium"
                  >
                    {input.options.map((opt) => (
                      <option key={String(opt.value)} value={String(opt.value)}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                ) : (
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      step={input.step || 1}
                      value={Number(currentInputs[input.id] ?? input.defaultValue)}
                      onChange={(e) => handleInputChange(currentCalc.id, input.id, parseFloat(e.target.value) || 0)}
                      className="flex-1 rounded-lg bg-[#070F1E] border border-[#1E3A70] p-2.5 text-base font-bold text-white font-mono focus:border-[#0EA5E9] focus:outline-none tabular-nums"
                    />
                    {input.unit && (
                      <span className="px-3 py-2 rounded-lg bg-[#162C58] text-xs font-bold text-slate-300 font-mono">
                        {input.unit}
                      </span>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Results Section */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-4">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Calculated Output (حتمی نتیجہ)
              </h3>

              {/* Primary High-Impact Output Box */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#0F2042] to-[#162C58] border border-[#0EA5E9] shadow-lg relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#0EA5E9]/10 rounded-full blur-2xl pointer-events-none" />
                <span className="text-xs uppercase font-bold text-[#38BDF8] tracking-wider block">
                  {result.primaryResult.label} • {result.primaryResult.labelUrdu}
                </span>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight tabular-nums">
                    {result.primaryResult.value}
                  </span>
                  <span className="text-sm sm:text-base font-bold text-[#38BDF8]">
                    {result.primaryResult.unit}
                  </span>
                </div>
              </div>

              {/* Secondary Metrics Grid */}
              <div className="grid grid-cols-2 gap-2.5 mt-3">
                {result.secondaryResults.map((sec, i) => (
                  <div key={i} className="p-3 rounded-xl bg-[#0F2042] border border-[#1E3A70]">
                    <span className="text-[10px] text-slate-400 block truncate">{sec.label}</span>
                    <span className="text-[11px] font-urdu text-[#E8A85C] block truncate">{sec.labelUrdu}</span>
                    <div className="mt-1 flex items-baseline gap-1">
                      <span className="text-base font-bold text-white font-mono tabular-nums">{sec.value}</span>
                      <span className="text-[10px] text-slate-400">{sec.unit}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Step-by-Step Calculation Formula Explanation */}
            <div className="p-3.5 rounded-xl bg-[#070F1E] border border-[#1E3A70] text-xs space-y-2">
              <span className="text-slate-400 font-bold uppercase tracking-wider block text-[10px]">
                Calculation Steps (حل کرنے کا طریقہ):
              </span>
              {result.steps.map((st, i) => (
                <div key={i} className="space-y-0.5 border-l-2 border-[#0EA5E9] pl-2.5 py-0.5">
                  <p className="font-mono text-slate-200">{st.stepEn}</p>
                  <p className="font-urdu text-[#E8A85C] text-[11px]">{st.stepUrdu}</p>
                </div>
              ))}

              {result.recommendation && (
                <div className="mt-2 pt-2 border-t border-[#1E3A70] flex items-start gap-2 text-slate-300">
                  <Lightbulb className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-amber-200">{result.recommendation.en}</p>
                    <p className="font-urdu text-[#E8A85C] text-[11px] mt-0.5">{result.recommendation.ur}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Owner Notes Modal */}
      {activeNoteTopic && (
        <OwnerNotesModal
          isOpen={true}
          onClose={() => setActiveNoteTopic(null)}
          topicId={activeNoteTopic.id}
          topicTitle={activeNoteTopic.title}
          topicTitleUrdu={activeNoteTopic.titleUrdu}
        />
      )}
    </div>
  );
};
