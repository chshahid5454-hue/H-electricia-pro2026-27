import React, { useState } from 'react';
import { Box, Wrench, DollarSign, Edit3, CheckCircle, Search, ShieldCheck } from 'lucide-react';
import { COMPONENTS_DATA } from '../data/componentsData';
import { ComponentItem } from '../types';
import { OwnerNotesModal } from '../components/OwnerNotesModal';
import { StorageService } from '../services/storage';

export const ComponentsView: React.FC = () => {
  const [selectedComp, setSelectedComp] = useState<ComponentItem>(COMPONENTS_DATA[0]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeNoteTopic, setActiveNoteTopic] = useState<ComponentItem | null>(null);

  const hasOwnerNote = Boolean(StorageService.getOwnerNote(selectedComp.id));

  const filteredComponents = COMPONENTS_DATA.filter((c) => {
    const q = searchQuery.toLowerCase();
    return (
      !q ||
      c.name.toLowerCase().includes(q) ||
      c.nameUrdu.includes(q) ||
      c.function.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-4 pb-12">
      {/* Header Bar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white font-sans flex items-center gap-2">
              <Box className="w-5 h-5 text-[#38BDF8]" />
              Components Library & Testing | الیکٹریکل پرزہ جات لائبریری
            </h2>
            <p className="text-xs text-slate-300 font-urdu mt-0.5">
              ایم سی بی، کنٹیکٹر، ریلے، ٹائمر، سی ٹی: کام کا اصول، ملٹی میٹر سے ٹیسٹنگ اور مارکیٹ ریٹس
            </p>
          </div>
          <span className="text-xs font-mono bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] px-3 py-1 rounded-md font-bold">
            Pak Market PKR Prices
          </span>
        </div>

        {/* Search */}
        <div className="relative mb-3">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="پرزہ یا بریکر تلاش کریں... (Search MCB, Contactor, Relay...)"
            className="w-full rounded-xl bg-[#070F1E] border border-[#1E3A70] focus:border-[#0EA5E9] focus:outline-none pl-10 pr-4 py-2 text-xs sm:text-sm text-slate-100 placeholder-slate-400 font-urdu"
          />
        </div>

        {/* Horizontal Selector */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {filteredComponents.map((comp) => {
            const isSelected = selectedComp.id === comp.id;
            return (
              <button
                key={comp.id}
                onClick={() => setSelectedComp(comp)}
                className={`px-3 py-2 rounded-xl text-left flex-shrink-0 transition border cursor-pointer ${
                  isSelected
                    ? 'bg-[#0284C7] text-white font-bold border-[#38BDF8] shadow'
                    : 'bg-[#0F2042] hover:bg-[#162C58] text-slate-200 border-[#1E3A70]'
                }`}
              >
                <span className="text-xs font-bold block truncate max-w-[150px]">{comp.name.split('(')[0]}</span>
                <span className={`text-[11px] font-urdu block truncate max-w-[150px] ${isSelected ? 'text-blue-100' : 'text-[#E8A85C]'}`}>
                  {comp.nameUrdu.split('(')[0]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Component Detail View */}
      <div className="p-4 sm:p-6 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl space-y-4">
        {/* Card Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1E3A70]">
          <div>
            <h3 className="text-base sm:text-xl font-bold text-white font-sans">{selectedComp.name}</h3>
            <p className="text-xs sm:text-sm text-[#E8A85C] font-urdu font-medium mt-0.5">{selectedComp.nameUrdu}</p>
          </div>

          <button
            onClick={() => setActiveNoteTopic(selectedComp)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer self-start sm:self-auto ${
              hasOwnerNote
                ? 'bg-amber-500/20 text-[#E8A85C] border-[#E8A85C]'
                : 'bg-[#162C58] text-slate-300 border-[#1E3A70] hover:text-white'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5 text-[#E8A85C]" />
            <span className="font-urdu">My Notes {hasOwnerNote && '✓'}</span>
          </button>
        </div>

        {/* Pakistan Price Range Highlight Banner */}
        <div className="p-4 rounded-xl bg-gradient-to-r from-[#0F2042] to-[#162C58] border border-[#1E3A70] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0284C7]/20 border border-[#0EA5E9] flex items-center justify-center text-[#38BDF8]">
              <DollarSign className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-300 tracking-wider">
                Price Range in Pakistan (مقامی مارکیٹ کے ریٹس):
              </span>
              <p className="text-base sm:text-lg font-black text-[#E8A85C] font-mono tabular-nums">{selectedComp.priceRangePKR}</p>
            </div>
          </div>
          <span className="text-xs text-slate-200 font-urdu sm:text-right">{selectedComp.priceNoteUrdu}</span>
        </div>

        {/* Function & Working Description */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-[#0F2042] border border-[#1E3A70] space-y-2 text-xs">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#38BDF8] block">
              Electrical Function & Principle:
            </span>
            <p className="text-slate-200 leading-relaxed font-sans">{selectedComp.function}</p>
          </div>

          <div className="p-4 rounded-xl bg-[#0F2042] border border-[#1E3A70] space-y-2 text-xs sm:text-sm">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#E8A85C] block">
              اردو میں کام اور مقصد:
            </span>
            <p className="text-slate-200 leading-relaxed font-urdu" dir="rtl">{selectedComp.functionUrdu}</p>
          </div>
        </div>

        {/* Step-by-Step Multimeter Testing Instructions */}
        <div className="p-4 rounded-xl bg-[#070F1E] border border-emerald-500/40 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
            <Wrench className="w-4 h-4 text-emerald-400" />
            How to Test with Multimeter (ملٹی میٹر سے ٹیسٹ کرنے کا طریقہ):
          </span>
          <div className="space-y-2 pl-2">
            {selectedComp.testingSteps?.map((step, idx) => (
              <div key={idx} className="flex items-start gap-2 text-xs">
                <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                  {idx + 1}
                </span>
                <div className="flex-1">
                  <p className="text-slate-200">{step}</p>
                  {selectedComp.testingStepsUrdu?.[idx] && (
                    <p className="text-[#E8A85C] font-urdu text-[11px] mt-0.5" dir="rtl">
                      {selectedComp.testingStepsUrdu[idx]}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Owner Notes Modal */}
      {activeNoteTopic && (
        <OwnerNotesModal
          isOpen={true}
          onClose={() => setActiveNoteTopic(null)}
          topicId={activeNoteTopic.id}
          topicTitle={activeNoteTopic.name}
          topicTitleUrdu={activeNoteTopic.nameUrdu}
        />
      )}
    </div>
  );
};
