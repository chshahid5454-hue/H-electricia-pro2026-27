import React, { useState, useMemo } from 'react';
import {
  GitFork,
  Maximize2,
  AlertTriangle,
  CheckCircle,
  Edit3,
  Search,
  Zap,
  Shield,
  Layers,
  Cpu,
  Gauge,
  Wind,
  Flame,
  ArrowUpDown,
  Home,
  X,
  Share2,
  Check,
  Palette,
  Images,
  Download,
} from 'lucide-react';
import { DIAGRAMS_DATA } from '../data/diagramsData';
import { DiagramItem } from '../types';
import { DiagramRenderer } from '../components/DiagramRenderer';
import { DiagramZoomModal } from '../components/DiagramZoomModal';
import { GalleryComponent } from '../components/GalleryComponent';
import { OwnerNotesModal } from '../components/OwnerNotesModal';
import { StorageService } from '../services/storage';
import { exportDiagramToPdf } from '../utils/pdfExport';

export const DiagramsView: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [zoomedDiagram, setZoomedDiagram] = useState<DiagramItem | null>(null);
  const [activeNoteTopic, setActiveNoteTopic] = useState<DiagramItem | null>(null);
  const [simulatedDiagramId, setSimulatedDiagramId] = useState<string | null>(null);
  const [showColorGuide, setShowColorGuide] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isGalleryOpen, setIsGalleryOpen] = useState<boolean>(false);
  const [galleryInitialIndex, setGalleryInitialIndex] = useState<number>(0);

  const categories = [
    { id: 'all', title: 'All Schematics', titleUrdu: 'تمام ڈایاگرامز', icon: Layers },
    { id: 'industrial_panels', title: 'Industrial Panels & Starters', titleUrdu: 'انڈسٹریل پینلز و سٹارٹرز', icon: Layers },
    { id: 'plc_automation', title: 'PLC & Automation', titleUrdu: 'پی ایل سی و آٹومیشن', icon: Cpu },
    { id: 'vfd_scada', title: 'VFD, HMI & SCADA', titleUrdu: 'وی ایف ڈی، ایچ ایم آئی و اسکاڈا', icon: Gauge },
    { id: 'hvac_bms', title: 'HVAC & Smart BMS', titleUrdu: 'ایچ وی اے سی و بی ایم ایس', icon: Wind },
    { id: 'fire_lift', title: 'Fire Alarm & Elevators', titleUrdu: 'فائر الارم اور لفٹ', icon: Flame },
    { id: 'residential_solar', title: 'House Wiring & Solar', titleUrdu: 'گھریلو وائرنگ و سولر', icon: Home },
  ];

  // Filtering based on category and live search
  const filteredDiagrams = useMemo(() => {
    return DIAGRAMS_DATA.filter((diag) => {
      // Category match
      let matchCat = false;
      if (selectedCategory === 'all') {
        matchCat = true;
      } else if (selectedCategory === 'residential_solar') {
        matchCat =
          diag.category === 'residential_solar' ||
          diag.category === 'house_wiring' ||
          diag.category === 'solar_ups';
      } else if (selectedCategory === 'industrial_panels') {
        matchCat =
          diag.category === 'industrial_panels' ||
          diag.category === 'ats_generator';
      } else {
        matchCat = diag.category === selectedCategory;
      }

      if (!matchCat) return false;

      // Search match
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        diag.title.toLowerCase().includes(q) ||
        diag.titleUrdu.includes(q) ||
        diag.description.toLowerCase().includes(q) ||
        diag.descriptionUrdu.includes(q) ||
        diag.diagramType.toLowerCase().includes(q) ||
        diag.componentsUsed.some((c) => c.toLowerCase().includes(q)) ||
        diag.componentsUsedUrdu.some((c) => c.includes(q))
      );
    });
  }, [selectedCategory, searchQuery]);

  const handleCopySteps = (diag: DiagramItem) => {
    const text = `${diag.title} (${diag.titleUrdu})\n\n` +
      `Components:\n${diag.componentsUsed.join('\n')}\n\n` +
      `Wiring Steps:\n${diag.wiringSteps.join('\n')}\n\n` +
      `Safety:\n${diag.safetyNotes.join('\n')}`;
    navigator.clipboard.writeText(text);
    setCopiedId(diag.id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  return (
    <div className="space-y-4 pb-16">
      {/* Visual Learning System Banner Header */}
      <div className="p-4 sm:p-6 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-[#0284C7]/20 text-[#38BDF8] border border-[#0284C7]/40">
                Visual Learning System
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-500/20 text-[#E8A85C] border border-amber-500/40">
                HD Zoomable Schematics
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-sans flex items-center gap-2">
              <GitFork className="w-6 h-6 text-[#38BDF8]" />
              Electrical Diagrams & Visual Learning System
            </h2>
            <p className="text-sm text-[#E8A85C] font-urdu mt-0.5">
              مکمل بصری ڈایاگرامز: بی ایم ایس، ایچ وی اے سی، پی ایل سی، وی ایف ڈی، اسکاڈا، فائر الارم، لفٹ اور انڈسٹریل پینلز
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => {
                setGalleryInitialIndex(0);
                setIsGalleryOpen(true);
              }}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#0284C7] to-[#0369A1] hover:from-[#0369A1] hover:to-[#0284C7] text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-sky-950 transition cursor-pointer active:scale-95"
            >
              <Images className="w-4 h-4 text-sky-200" />
              <span>Swipe Gallery (گیلری ویو)</span>
            </button>

            <button
              onClick={() => setShowColorGuide(!showColorGuide)}
              className="px-3 py-2 rounded-xl bg-[#0F2042] hover:bg-[#162C58] text-slate-200 border border-[#1E3A70] text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            >
              <Palette className="w-4 h-4 text-[#38BDF8]" />
              <span>Color Codes</span>
            </button>
            <span className="text-xs font-mono bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] px-3 py-2 rounded-xl font-bold">
              {filteredDiagrams.length} Schematics
            </span>
          </div>
        </div>

        {/* Live Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by circuit name, PLC, VFD, BMS, HVAC, Motor, Lift, Star-Delta, Urdu keywords..."
            className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-[#070F1E] border border-[#1E3A70] text-white text-xs sm:text-sm focus:outline-none focus:border-[#38BDF8] placeholder:text-slate-500 transition"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Wire Color Code Drawer / Banner (Expandable) */}
        {showColorGuide && (
          <div className="p-4 rounded-xl bg-[#070F1E] border border-[#1E4680] space-y-3 animate-fadeIn">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-[#E8A85C] uppercase tracking-wider flex items-center gap-1.5">
                <Palette className="w-4 h-4" /> International & Pakistani Wire Color Standards (تاروں کے معیاری رنگ)
              </span>
              <button onClick={() => setShowColorGuide(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="p-2 rounded-lg bg-[#0F2042] border border-[#1E3A70]">
                <span className="font-bold text-red-400 block">Phase 1 / Live (L1)</span>
                <span className="text-slate-300 text-[11px]">Red (IEC: Brown) • سرخ</span>
              </div>
              <div className="p-2 rounded-lg bg-[#0F2042] border border-[#1E3A70]">
                <span className="font-bold text-yellow-400 block">Phase 2 (L2)</span>
                <span className="text-slate-300 text-[11px]">Yellow (IEC: Black) • پیلا</span>
              </div>
              <div className="p-2 rounded-lg bg-[#0F2042] border border-[#1E3A70]">
                <span className="font-bold text-blue-400 block">Phase 3 (L3)</span>
                <span className="text-slate-300 text-[11px]">Blue (IEC: Grey) • نیلا</span>
              </div>
              <div className="p-2 rounded-lg bg-[#0F2042] border border-[#1E3A70]">
                <span className="font-bold text-sky-400 block">Neutral (N)</span>
                <span className="text-slate-300 text-[11px]">Black / Light Blue • کالا / ہلکا نیلا</span>
              </div>
              <div className="p-2 rounded-lg bg-[#0F2042] border border-[#1E3A70]">
                <span className="font-bold text-emerald-400 block">Earth / PE</span>
                <span className="text-slate-300 text-[11px]">Green / Green-Yellow • سبز ارتھ</span>
              </div>
              <div className="p-2 rounded-lg bg-[#0F2042] border border-[#1E3A70]">
                <span className="font-bold text-amber-500 block">24V DC (+) Positive</span>
                <span className="text-slate-300 text-[11px]">Brown / Red • براؤن / لال</span>
              </div>
              <div className="p-2 rounded-lg bg-[#0F2042] border border-[#1E3A70]">
                <span className="font-bold text-indigo-400 block">24V DC (-) 0V / GND</span>
                <span className="text-slate-300 text-[11px]">Dark Blue / Black • نیلا / 0V</span>
              </div>
              <div className="p-2 rounded-lg bg-[#0F2042] border border-[#1E3A70]">
                <span className="font-bold text-orange-400 block">Analog Signals</span>
                <span className="text-slate-300 text-[11px]">0-10V / 4-20mA Shielded • شیلڈڈ تار</span>
              </div>
            </div>
          </div>
        )}

        {/* Mandatory Safety Warning Banner */}
        <div className="p-3.5 rounded-xl bg-red-950/40 border-2 border-red-600/70 shadow-lg flex items-start gap-3">
          <Shield className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="text-xs sm:text-sm font-bold text-red-200 uppercase tracking-wider block font-sans">
              ⚠️ MANDATORY SAFETY NOTICE: EDUCATIONAL & LEARNING SCHEMATICS ONLY
            </span>
            <p className="text-xs sm:text-sm text-red-100 font-urdu leading-relaxed font-medium">
              یہ تمام خاکے اور ڈایاگرامز صرف برقی اصولوں کو سمجھنے، فالٹ ٹریسنگ اور انجینئرنگ ٹریننگ کیلئے ہیں۔ 
              ہائی وولٹیج اور انڈسٹریل پاور پر اصل تنصیب یا کام صرف مجاز اور کوالیفائیڈ الیکٹریشن ہی سیفٹی پروٹوکولز (LOTO / PPE) کے ساتھ کرے۔ 
              غلط وائرنگ سے جان لیوا برقی جھٹکا یا بلاسٹ کا خطرہ ہوتا ہے۔
            </p>
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none pt-1">
          {categories.map((c) => {
            const Icon = c.icon;
            const isSelected = selectedCategory === c.id;
            return (
              <button
                key={c.id}
                onClick={() => setSelectedCategory(c.id)}
                className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-[#0284C7] text-white font-bold shadow-md shadow-sky-950'
                    : 'bg-[#0F2042] hover:bg-[#162C58] text-slate-300 border border-[#1E3A70]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-white' : 'text-[#38BDF8]'}`} />
                <span>{c.title}</span>
                <span className="font-urdu opacity-80 text-[11px]">• {c.titleUrdu}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* No results placeholder */}
      {filteredDiagrams.length === 0 && (
        <div className="p-8 rounded-2xl bg-[#0B172E] border border-[#1E3A70] text-center space-y-2">
          <AlertTriangle className="w-8 h-8 text-amber-400 mx-auto" />
          <h3 className="text-base font-bold text-white">No schematics match your search</h3>
          <p className="text-xs text-slate-400 font-urdu">
            کوئی ڈایاگرام نہیں ملا۔ براہ کرم تلاش کا لفظ تبدیل کریں یا 'All Schematics' منتخب کریں۔
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
            }}
            className="px-4 py-1.5 rounded-xl bg-[#0284C7] text-white text-xs font-bold mt-2 cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      )}

      {/* Diagrams Cards List */}
      <div className="space-y-6">
        {filteredDiagrams.map((diag, index) => {
          const hasOwnerNote = Boolean(StorageService.getOwnerNote(diag.id));
          const isSimulating = simulatedDiagramId === diag.id;

          return (
            <div
              key={diag.id}
              className="p-4 sm:p-6 rounded-2xl bg-[#0B172E] border border-[#1E3A70] hover:border-[#0EA5E9] shadow-xl space-y-4 transition"
            >
              {/* Card Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#1E3A70]">
                <div>
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    {diag.voltageRating && (
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-[#162C58] text-[#38BDF8] border border-[#1E3A70]">
                        ⚡ {diag.voltageRating}
                      </span>
                    )}
                    {diag.standardRef && (
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-[#162C58] text-[#E8A85C] border border-[#1E3A70]">
                        📜 {diag.standardRef}
                      </span>
                    )}
                  </div>
                  <h3 className="text-base sm:text-lg font-bold text-white font-sans">{diag.title}</h3>
                  <p className="text-xs text-[#E8A85C] font-urdu font-medium mt-0.5">{diag.titleUrdu}</p>
                </div>

                <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                  {/* Download as PDF Button */}
                  <button
                    onClick={() => exportDiagramToPdf(diag)}
                    title="Download as PDF (پی ڈی ایف محفوظ کریں)"
                    className="px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border border-[#E8A85C]/40 bg-gradient-to-r from-[#B87333]/25 to-[#E8A85C]/25 text-[#E8A85C] hover:from-[#B87333]/40 hover:to-[#E8A85C]/40 transition cursor-pointer active:scale-95 shadow-sm"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Save PDF</span>
                  </button>

                  {/* Simulation Toggle */}
                  <button
                    onClick={() => setSimulatedDiagramId(isSimulating ? null : diag.id)}
                    className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer ${
                      isSimulating
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500'
                        : 'bg-[#162C58] text-slate-300 border-[#1E3A70] hover:text-white'
                    }`}
                    title="Simulate active circuit voltage & current flow"
                  >
                    <Zap className={`w-3.5 h-3.5 ${isSimulating ? 'text-emerald-400 animate-bounce' : 'text-[#38BDF8]'}`} />
                    <span>{isSimulating ? 'Power ON' : 'Simulate'}</span>
                  </button>

                  {/* Owner Notes Button */}
                  <button
                    onClick={() => setActiveNoteTopic(diag)}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer ${
                      hasOwnerNote
                        ? 'bg-amber-500/20 text-[#E8A85C] border-[#E8A85C]'
                        : 'bg-[#162C58] text-slate-300 border-[#1E3A70] hover:text-white'
                    }`}
                  >
                    <Edit3 className="w-3.5 h-3.5 text-[#E8A85C]" />
                    <span className="font-urdu">Notes {hasOwnerNote && '✓'}</span>
                  </button>

                  {/* Swipe Gallery Shortcut */}
                  <button
                    onClick={() => {
                      setGalleryInitialIndex(index);
                      setIsGalleryOpen(true);
                    }}
                    title="Open in Swipe Gallery (گیلری ویو)"
                    className="p-1.5 rounded-xl bg-[#0F2042] hover:bg-[#162C58] text-slate-300 hover:text-white border border-[#1E3A70] transition cursor-pointer hidden md:flex items-center"
                  >
                    <Images className="w-4 h-4 text-[#38BDF8]" />
                  </button>

                  {/* HD Zoom Button */}
                  <button
                    onClick={() => setZoomedDiagram(diag)}
                    className="px-3.5 py-1.5 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-white text-xs font-bold flex items-center gap-1.5 shadow transition cursor-pointer"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>HD Zoom (بڑا کریں)</span>
                  </button>
                </div>
              </div>

              {/* Interactive Vector Graphic Preview */}
              <div
                onClick={() => setZoomedDiagram(diag)}
                className="relative rounded-xl overflow-hidden cursor-pointer group border border-[#1E3A70] bg-[#070F1E]"
              >
                <DiagramRenderer
                  type={diag.diagramType}
                  isSimulating={isSimulating}
                  className="transition-transform duration-300 group-hover:scale-[1.01]"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                  <span className="px-4 py-2 rounded-xl bg-[#0284C7] text-white font-bold text-xs flex items-center gap-1.5 shadow-xl">
                    <Maximize2 className="w-4 h-4" /> Click to Pinch & Zoom Fullscreen (کھینچ کر بڑا کریں)
                  </span>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1">
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">{diag.description}</p>
                <p className="text-xs sm:text-sm text-slate-300 font-urdu leading-relaxed">{diag.descriptionUrdu}</p>
              </div>

              {/* Two Column Grid: Components and Steps */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                {/* Components Used */}
                <div className="p-3.5 rounded-xl bg-[#0F294E] border border-[#1E4680]">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#38BDF8] block mb-2">
                    Components & Wire Specs (پرزہ جات اور تاریں):
                  </span>
                  <ul className="space-y-1.5 text-xs text-slate-200">
                    {diag.componentsUsed.map((comp, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                        <div>
                          <span>{comp}</span>
                          {diag.componentsUsedUrdu[idx] && (
                            <span className="block font-urdu text-[11px] text-[#E8A85C]">
                              {diag.componentsUsedUrdu[idx]}
                            </span>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Step-by-Step Wiring */}
                <div className="p-3.5 rounded-xl bg-[#0F294E] border border-[#1E4680]">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#E8A85C]">
                      Step-by-Step Wiring Guide (تاریں جوڑنے کا طریقہ):
                    </span>
                    <button
                      onClick={() => handleCopySteps(diag)}
                      className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                    >
                      {copiedId === diag.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Share2 className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                  <ol className="space-y-2 text-xs text-slate-200">
                    {diag.wiringSteps.map((step, idx) => (
                      <li key={idx} className="border-l-2 border-[#E8A85C] pl-2 py-0.5">
                        <p className="font-medium">{step}</p>
                        {diag.wiringStepsUrdu[idx] && (
                          <p className="font-urdu text-[11px] text-slate-300 mt-0.5">
                            {diag.wiringStepsUrdu[idx]}
                          </p>
                        )}
                      </li>
                    ))}
                  </ol>
                </div>
              </div>

              {/* Safety Rules Alert Banner */}
              <div className="p-3.5 rounded-xl bg-red-950/40 border border-red-700/60 flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                <div className="space-y-1 text-xs">
                  <span className="font-bold text-red-200 uppercase tracking-wider text-[11px]">
                    Critical Electrician Safety Rules (اہم ترین حفاظتی احتیاط):
                  </span>
                  {diag.safetyNotes.map((note, idx) => (
                    <div key={idx}>
                      <p className="text-red-100">{note}</p>
                      {diag.safetyNotesUrdu[idx] && (
                        <p className="text-amber-200 font-urdu text-[11px] mt-0.5">
                          {diag.safetyNotesUrdu[idx]}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* HD Zoom Modal */}
      {zoomedDiagram && (
        <DiagramZoomModal
          isOpen={true}
          onClose={() => setZoomedDiagram(null)}
          title={zoomedDiagram.title}
          titleUrdu={zoomedDiagram.titleUrdu}
          diagramType={zoomedDiagram.diagramType}
          item={zoomedDiagram}
        />
      )}

      {/* Swipeable Fullscreen Gallery */}
      <GalleryComponent
        isOpen={isGalleryOpen}
        onClose={() => setIsGalleryOpen(false)}
        items={filteredDiagrams.length > 0 ? filteredDiagrams : DIAGRAMS_DATA}
        initialIndex={galleryInitialIndex}
      />

      {/* Owner Notes Modal */}
      {activeNoteTopic && (
        <OwnerNotesModal
          isOpen={true}
          onClose={() => setActiveNoteTopic(null)}
          topicId={activeNoteTopic.id}
          topicTitle={activeNoteTopic.title}
          topicTitleUrdu={activeNoteTopic.titleUrdu}
        />
      )}
    </div>
  );
};
