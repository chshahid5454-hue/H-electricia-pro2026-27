import React, { useState, useMemo } from 'react';
import { Wrench, Search, AlertTriangle, CheckCircle, Edit3, ArrowRight, Shield } from 'lucide-react';
import { FAULTS_DATA } from '../data/faultsData';
import { FaultFindingItem } from '../types';
import { OwnerNotesModal } from '../components/OwnerNotesModal';
import { StorageService } from '../services/storage';

export const FaultFindingView: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeNoteTopic, setActiveNoteTopic] = useState<FaultFindingItem | null>(null);

  const categories = [
    { id: 'all', title: 'All Systems', titleUrdu: 'تمام فالٹس' },
    { id: 'motor', title: 'Motors', titleUrdu: 'موٹرز' },
    { id: 'plc', title: 'PLC Automation', titleUrdu: 'پی ایل سی' },
    { id: 'vfd', title: 'VFD & Inverter', titleUrdu: 'وی ایف ڈی' },
    { id: 'ac', title: 'HVAC & AC', titleUrdu: 'اے سی و چیلر' },
    { id: 'house_wiring', title: 'Wiring & DB', titleUrdu: 'وائرنگ و ڈی بی' },
  ];

  const filteredFaults = useMemo(() => {
    return FAULTS_DATA.filter((ft) => {
      const matchesCat = selectedCategory === 'all' || ft.category === selectedCategory;
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        !q ||
        ft.problem.toLowerCase().includes(q) ||
        ft.problemUrdu.includes(q) ||
        ft.categoryTitle.toLowerCase().includes(q) ||
        ft.causes.some((c) => c.toLowerCase().includes(q)) ||
        ft.solutions.some((s) => s.toLowerCase().includes(q));
      return matchesCat && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  return (
    <div className="space-y-4 pb-12">
      {/* Header & Search */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white font-sans flex items-center gap-2">
              <Wrench className="w-5 h-5 text-[#38BDF8]" />
              Fault Finding Guru | فالٹ فائنڈنگ گرو (مسئلہ | وجوہات | حل)
            </h2>
            <p className="text-xs text-slate-300 font-urdu mt-0.5">
              موٹر، پی ایل سی، انورٹر، اے سی اور وائرنگ کے پیچیدہ فالٹس تلاش کرنے کا جدول (Table Format)
            </p>
          </div>
          <span className="text-xs font-mono bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] px-3 py-1 rounded-md font-bold">
            Troubleshooting Master
          </span>
        </div>

        {/* Search */}
        <div className="relative mb-3">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="فالٹ تلاش کریں... (Search e.g. Motor hums, Overvoltage, RCCB tripping)"
            className="w-full rounded-xl bg-[#070F1E] border border-[#1E3A70] focus:border-[#0EA5E9] focus:outline-none pl-10 pr-4 py-2 text-xs sm:text-sm text-slate-100 placeholder-slate-400 font-urdu"
          />
        </div>

        {/* Category Filter Pills */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                selectedCategory === c.id
                  ? 'bg-[#0284C7] text-white font-bold shadow'
                  : 'bg-[#0F2042] hover:bg-[#162C58] text-slate-300 border border-[#1E3A70]'
              }`}
            >
              {c.title} • {c.titleUrdu}
            </button>
          ))}
        </div>
      </div>

      {/* Faults Cards in Clear Table-like Column Format */}
      <div className="space-y-4">
        {filteredFaults.map((item) => {
          const hasOwnerNote = Boolean(StorageService.getOwnerNote(item.id));

          return (
            <div
              key={item.id}
              className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#1E3A70] hover:border-[#0EA5E9] shadow-md space-y-4 transition"
            >
              {/* Problem Title & Category */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#1E3A70]">
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#38BDF8] tracking-wider bg-[#162C58] px-2 py-0.5 rounded border border-[#1E3A70]">
                    {item.categoryTitle}
                  </span>
                  <h3 className="text-base sm:text-lg font-bold text-red-300 mt-1 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                    <span>{item.problem}</span>
                  </h3>
                  <p className="text-xs sm:text-sm text-[#E8A85C] font-urdu font-medium mt-0.5">
                    {item.problemUrdu}
                  </p>
                </div>

                <button
                  onClick={() => setActiveNoteTopic(item)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer self-start sm:self-auto ${
                    hasOwnerNote
                      ? 'bg-amber-500/20 text-[#E8A85C] border-[#E8A85C]'
                      : 'bg-[#162C58] text-slate-300 border-[#1E3A70] hover:text-white'
                  }`}
                >
                  <Edit3 className="w-3.5 h-3.5 text-[#E8A85C]" />
                  <span className="font-urdu">My Notes {hasOwnerNote && '✓'}</span>
                </button>
              </div>

              {/* Table Format Columns: Root Causes on Left, Verified Solutions on Right */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Causes Column */}
                <div className="p-3.5 rounded-xl bg-[#0F2042] border border-red-950/80 space-y-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-red-400 block pb-1 border-b border-red-900/40">
                    Probable Root Causes (ممکنہ وجوہات):
                  </span>
                  <ul className="space-y-2 text-xs text-slate-300">
                    {item.causes.map((c, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5 flex-shrink-0" />
                        <div>
                          <p>{c}</p>
                          {item.causesUrdu[i] && (
                            <p className="font-urdu text-[11px] text-amber-200 mt-0.5">
                              {item.causesUrdu[i]}
                            </p>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Solutions Column */}
                <div className="p-3.5 rounded-xl bg-[#0F2042] border border-emerald-950/80 space-y-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block pb-1 border-b border-emerald-900/40">
                    Proven Solutions (حتمی حل):
                  </span>
                  <ul className="space-y-2 text-xs text-slate-300">
                    {item.solutions.map((s, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
                        <div>
                          <p>{s}</p>
                          {item.solutionsUrdu[i] && (
                            <p className="font-urdu text-[11px] text-emerald-200 mt-0.5">
                              {item.solutionsUrdu[i]}
                            </p>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Owner Notes Modal */}
      {activeNoteTopic && (
        <OwnerNotesModal
          isOpen={true}
          onClose={() => setActiveNoteTopic(null)}
          topicId={activeNoteTopic.id}
          topicTitle={activeNoteTopic.problem}
          topicTitleUrdu={activeNoteTopic.problemUrdu}
        />
      )}
    </div>
  );
};
