import React, { useState, useMemo } from 'react';
import { Search, BookOpen, Star, Edit3, ArrowRight, Check, HelpCircle, Download } from 'lucide-react';
import { FORMULAS_DATA } from '../data/formulasData';
import { FormulaItem } from '../types';
import { StorageService } from '../services/storage';
import { OwnerNotesModal } from '../components/OwnerNotesModal';
import { exportFormulaToPdf } from '../utils/pdfExport';

export const FormulasView: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeNoteTopic, setActiveNoteTopic] = useState<FormulaItem | null>(null);
  const [favorites, setFavorites] = useState<string[]>(() => StorageService.getFavorites());

  const categories = [
    { id: 'all', title: 'All Formulas', titleUrdu: 'تمام فارمولے' },
    { id: 'single_phase', title: 'Single Phase', titleUrdu: 'سنگل فیز' },
    { id: 'three_phase', title: 'Three Phase', titleUrdu: 'تھری فیز' },
    { id: 'motor', title: 'Motors', titleUrdu: 'موٹرز' },
    { id: 'transformer', title: 'Transformers', titleUrdu: 'ٹرانسفارمر' },
    { id: 'power_factor', title: 'Power Factor', titleUrdu: 'پاور فیکٹر' },
    { id: 'earthing', title: 'Earthing', titleUrdu: 'ارتھنگ' },
    { id: 'battery', title: 'Battery & Solar', titleUrdu: 'بیٹری و سولر' },
  ];

  const filteredFormulas = useMemo(() => {
    return FORMULAS_DATA.filter((f) => {
      const matchesCat = selectedCategory === 'all' || f.category === selectedCategory;
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        !q ||
        f.title.toLowerCase().includes(q) ||
        f.titleUrdu.includes(q) ||
        f.formula.toLowerCase().includes(q) ||
        f.explanation.toLowerCase().includes(q) ||
        f.explanationUrdu.includes(q);
      return matchesCat && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  const handleToggleFavorite = (id: string) => {
    StorageService.toggleFavorite(id);
    setFavorites(StorageService.getFavorites());
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header Bar & Search */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white font-sans flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#38BDF8]" />
              Formula Library | برقی فارمولا لائبریری
            </h2>
            <p className="text-xs text-slate-300 font-urdu mt-0.5">
              100+ مستند فارمولے بمعہ وضاحت، متغیرات اور حل شدہ مثالیں
            </p>
          </div>
          <span className="text-xs font-mono bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] px-3 py-1 rounded-md font-bold">
            {filteredFormulas.length} Formulas Available
          </span>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="فارمولا یا نام تلاش کریں... (Search by formula, term, or Urdu name)"
            className="w-full rounded-xl bg-[#070F1E] border border-[#1E3A70] focus:border-[#0EA5E9] focus:outline-none pl-10 pr-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-400 font-urdu"
          />
        </div>

        {/* Category Filter Pills */}
        <div className="flex gap-1.5 overflow-x-auto mt-3 pb-1 scrollbar-none">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                selectedCategory === c.id
                  ? 'bg-[#0284C7] text-white font-bold shadow-sm'
                  : 'bg-[#0F2042] hover:bg-[#162C58] text-slate-300 border border-[#1E3A70]'
              }`}
            >
              {c.title} • {c.titleUrdu}
            </button>
          ))}
        </div>
      </div>

      {/* Formulas List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredFormulas.map((formula) => {
          const isFav = favorites.includes(formula.id);
          const hasOwnerNote = Boolean(StorageService.getOwnerNote(formula.id));

          return (
            <div
              key={formula.id}
              className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#1E3A70] hover:border-[#0EA5E9] shadow-md flex flex-col justify-between transition-all group"
            >
              <div>
                {/* Header: Category & Action Buttons */}
                <div className="flex items-start justify-between gap-2 pb-2 border-b border-[#1E3A70]/60">
                  <span className="text-[10px] font-bold text-[#38BDF8] uppercase tracking-wider bg-[#162C58] px-2 py-0.5 rounded border border-[#1E3A70]">
                    {formula.categoryTitle}
                  </span>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => exportFormulaToPdf(formula)}
                      title="Download Formula as PDF (پی ڈی ایف محفوظ کریں)"
                      className="p-1.5 rounded-lg border text-xs transition cursor-pointer bg-[#0F2042] text-[#E8A85C] hover:text-white border-[#1E3A70] hover:border-[#E8A85C]/50"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() =>
                        setActiveNoteTopic(formula)
                      }
                      title="Write Private Note"
                      className={`p-1.5 rounded-lg border text-xs transition cursor-pointer ${
                        hasOwnerNote
                          ? 'bg-amber-500/20 text-[#E8A85C] border-[#E8A85C]'
                          : 'bg-[#0F2042] text-slate-400 hover:text-white border-[#1E3A70]'
                      }`}
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleToggleFavorite(formula.id)}
                      title="Bookmark Favorite"
                      className={`p-1.5 rounded-lg border text-xs transition cursor-pointer ${
                        isFav
                          ? 'bg-amber-500/20 text-[#E8A85C] border-[#E8A85C]'
                          : 'bg-[#0F2042] text-slate-400 hover:text-white border-[#1E3A70]'
                      }`}
                    >
                      <Star className={`w-3.5 h-3.5 ${isFav ? 'fill-[#E8A85C]' : ''}`} />
                    </button>
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-base font-bold text-white font-sans mt-2 group-hover:text-[#38BDF8] transition">
                  {formula.title}
                </h3>
                <p className="text-xs text-[#E8A85C] font-urdu font-medium mt-0.5">{formula.titleUrdu}</p>

                {/* Formula Highlight Box */}
                <div className="my-3 p-3 rounded-xl bg-[#071326] border border-[#E8A85C]/50 flex items-center justify-between">
                  <code className="text-sm sm:text-base font-bold font-mono text-[#E8A85C] tracking-wide">
                    {formula.formula}
                  </code>
                </div>

                {/* Explanation */}
                <p className="text-xs text-slate-300 leading-relaxed">{formula.explanation}</p>
                <p className="text-xs text-slate-400 font-urdu leading-relaxed mt-1.5">{formula.explanationUrdu}</p>

                {/* Variables Table */}
                <div className="mt-3 pt-2 border-t border-slate-700/60">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                    Variables (علامات اور پیمائش):
                  </span>
                  <div className="space-y-1">
                    {formula.variables.map((v, i) => (
                      <div key={i} className="flex items-center justify-between text-[11px] py-0.5">
                        <span className="font-mono font-bold text-[#38BDF8]">{v.symbol}</span>
                        <span className="text-slate-300">{v.name} ({v.unit})</span>
                        <span className="font-urdu text-[#E8A85C]">{v.nameUrdu}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Practical Worked Example */}
              <div className="mt-3 p-3 rounded-xl bg-[#0F294E] border border-[#1E4680] text-xs">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block mb-0.5">
                  Practical Example (عملی مثال):
                </span>
                <p className="text-slate-200 font-mono text-[11px]">{formula.example}</p>
                <p className="text-[#E8A85C] font-urdu text-[11px] mt-0.5">{formula.exampleUrdu}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Owner Notes Modal */}
      {activeNoteTopic && (
        <OwnerNotesModal
          isOpen={true}
          onClose={() => setActiveNoteTopic(null)}
          topicId={activeNoteTopic.id}
          topicTitle={activeNoteTopic.title}
          topicTitleUrdu={activeNoteTopic.titleUrdu}
        />
      )}
    </div>
  );
};
