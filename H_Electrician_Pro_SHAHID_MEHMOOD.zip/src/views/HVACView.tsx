import React, { useState } from 'react';
import { Wind, Maximize2, Edit3, Thermometer, CheckCircle, Calculator, Info } from 'lucide-react';
import { HVAC_TOPICS_DATA } from '../data/hvacData';
import { HVACTopic } from '../types';
import { DiagramRenderer } from '../components/DiagramRenderer';
import { DiagramZoomModal } from '../components/DiagramZoomModal';
import { OwnerNotesModal } from '../components/OwnerNotesModal';
import { StorageService } from '../services/storage';

export const HVACView: React.FC = () => {
  const [selectedTopic, setSelectedTopic] = useState<HVACTopic>(HVAC_TOPICS_DATA[0]);
  const [zoomedDiagram, setZoomedDiagram] = useState<{ title: string; titleUrdu: string; type: string } | null>(null);
  const [activeNoteTopic, setActiveNoteTopic] = useState<HVACTopic | null>(null);

  // Interactive CSR Live Multimeter Resistance Tester Tool
  const [r12, setR12] = useState<number>(6.2);
  const [r23, setR23] = useState<number>(4.1);
  const [r13, setR13] = useState<number>(2.1);

  const hasOwnerNote = Boolean(StorageService.getOwnerNote(selectedTopic.id));

  // Determine which is Common, Start, and Run
  const maxVal = Math.max(r12, r23, r13);
  let identifiedCommon = 'Pin 3';
  let identifiedStart = 'Pin 1';
  let identifiedRun = 'Pin 2';

  if (maxVal === r12) {
    identifiedCommon = 'Pin 3';
    identifiedStart = r23 > r13 ? 'Pin 2' : 'Pin 1';
    identifiedRun = r23 > r13 ? 'Pin 1' : 'Pin 2';
  } else if (maxVal === r23) {
    identifiedCommon = 'Pin 1';
    identifiedStart = r12 > r13 ? 'Pin 2' : 'Pin 3';
    identifiedRun = r12 > r13 ? 'Pin 3' : 'Pin 2';
  } else {
    identifiedCommon = 'Pin 2';
    identifiedStart = r12 > r23 ? 'Pin 1' : 'Pin 3';
    identifiedRun = r12 > r23 ? 'Pin 3' : 'Pin 1';
  }

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white font-sans flex items-center gap-2">
              <Wind className="w-5 h-5 text-[#38BDF8]" />
              HVAC & AC Systems | ایچ وی اے سی اور ائیر کنڈیشنگ
            </h2>
            <p className="text-xs text-slate-300 font-urdu mt-0.5">
              سپلیٹ اے سی، کمپریسر CSR ٹیسٹ، چیلر پلانٹ، 7-وائر تھرموسٹیٹ اور گیس پریشر چارٹ
            </p>
          </div>
          <span className="text-xs font-mono bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] px-3 py-1 rounded-md font-bold">
            R22, R410A, R32
          </span>
        </div>

        {/* Topic Pills */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {HVAC_TOPICS_DATA.map((t) => {
            const isSelected = selectedTopic.id === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setSelectedTopic(t)}
                className={`px-3 py-2 rounded-xl text-left flex-shrink-0 transition border cursor-pointer ${
                  isSelected
                    ? 'bg-[#0284C7] text-white font-bold border-[#38BDF8] shadow'
                    : 'bg-[#0F2042] hover:bg-[#162C58] text-slate-200 border-[#1E3A70]'
                }`}
              >
                <span className="text-xs font-bold block truncate max-w-[210px]">{t.title.split('(')[0]}</span>
                <span className={`text-[11px] font-urdu block truncate max-w-[210px] ${isSelected ? 'text-blue-100' : 'text-[#E8A85C]'}`}>
                  {t.titleUrdu.split('(')[0]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Topic Content */}
      <div className="p-4 sm:p-6 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl space-y-4">
        {/* Title Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1E3A70]">
          <div>
            <h3 className="text-base sm:text-xl font-bold text-white font-sans">{selectedTopic.title}</h3>
            <p className="text-xs sm:text-sm text-[#E8A85C] font-urdu font-medium mt-0.5">{selectedTopic.titleUrdu}</p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveNoteTopic(selectedTopic)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer ${
                hasOwnerNote
                  ? 'bg-amber-500/20 text-[#E8A85C] border-[#E8A85C]'
                  : 'bg-[#162C58] text-slate-300 border-[#1E3A70] hover:text-white'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5 text-[#E8A85C]" />
              <span className="font-urdu">My Notes {hasOwnerNote && '✓'}</span>
            </button>

            {selectedTopic.diagramType && (
              <button
                onClick={() =>
                  setZoomedDiagram({
                    title: selectedTopic.title,
                    titleUrdu: selectedTopic.titleUrdu,
                    type: selectedTopic.diagramType || 'compressor_csr',
                  })
                }
                className="px-3.5 py-1.5 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-white text-xs font-bold flex items-center gap-1.5 shadow transition cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>HD Zoom</span>
              </button>
            )}
          </div>
        </div>

        {/* Vector Diagram Preview if present */}
        {selectedTopic.diagramType && (
          <div
            onClick={() =>
              setZoomedDiagram({
                title: selectedTopic.title,
                titleUrdu: selectedTopic.titleUrdu,
                type: selectedTopic.diagramType || 'compressor_csr',
              })
            }
            className="rounded-xl overflow-hidden cursor-pointer group border border-[#1E3A70] bg-[#070F1E] relative"
          >
            <DiagramRenderer type={selectedTopic.diagramType} className="group-hover:scale-[1.01] transition duration-300" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
              <span className="px-4 py-2 rounded-xl bg-[#E8A85C] text-[#050F1E] font-bold text-xs flex items-center gap-1.5 shadow-xl">
                <Maximize2 className="w-4 h-4" /> Tap to Zoom HVAC Diagram
              </span>
            </div>
          </div>
        )}

        {/* Live Compressor CSR Resistance Finder Widget (If Split AC topic) */}
        {selectedTopic.id === 'split-ac-csr-wiring' && (
          <div className="p-4 rounded-xl bg-[#0F294E] border border-[#E8A85C] space-y-3">
            <div className="flex items-center gap-2 text-[#E8A85C] font-bold text-sm">
              <Calculator className="w-4 h-4" />
              <span>Live CSR Multimeter Test Simulator (سی، ایس، آر ٹیسٹر)</span>
            </div>
            <p className="text-xs text-slate-300 font-urdu">
              کمپریسر کی تینوں پنوں پر میٹر رکھ کر آنے والے اوہم یہاں لکھیں، ایپ فوراً بتا دے گی کہ کون سا کامن ہے اور کون سا سٹارٹ یا رن:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-slate-300 block mb-1">Pair 1-2 Resistance (Ω):</label>
                <input
                  type="number"
                  step="0.1"
                  value={r12}
                  onChange={(e) => setR12(parseFloat(e.target.value) || 0)}
                  className="w-full rounded-lg bg-[#071326] border border-slate-700 p-2 text-white font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-xs text-slate-300 block mb-1">Pair 2-3 Resistance (Ω):</label>
                <input
                  type="number"
                  step="0.1"
                  value={r23}
                  onChange={(e) => setR23(parseFloat(e.target.value) || 0)}
                  className="w-full rounded-lg bg-[#071326] border border-slate-700 p-2 text-white font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-xs text-slate-300 block mb-1">Pair 1-3 Resistance (Ω):</label>
                <input
                  type="number"
                  step="0.1"
                  value={r13}
                  onChange={(e) => setR13(parseFloat(e.target.value) || 0)}
                  className="w-full rounded-lg bg-[#071326] border border-slate-700 p-2 text-white font-mono font-bold"
                />
              </div>
            </div>

            {/* Calculated CSR Result Banner */}
            <div className="p-3 rounded-lg bg-[#071326] border border-emerald-500/60 flex items-center justify-between text-xs font-mono">
              <span className="text-emerald-400 font-bold">COMMON (C): {identifiedCommon}</span>
              <span className="text-amber-400 font-bold">START (S): {identifiedStart}</span>
              <span className="text-cyan-400 font-bold">RUN (R): {identifiedRun}</span>
            </div>
          </div>
        )}

        {/* Text Description */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-[#0F294E] border border-[#1E4680] text-xs text-slate-200 leading-relaxed font-sans space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#38BDF8] block">
              HVAC Engineering Specification:
            </span>
            <div className="whitespace-pre-line font-mono-code text-[11px] sm:text-xs">
              {selectedTopic.description}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#0F294E] border border-[#1E4680] text-xs sm:text-sm text-slate-200 leading-relaxed font-urdu space-y-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#E8A85C] block">
              اردو رہنمائی:
            </span>
            <div className="whitespace-pre-line" dir="rtl">
              {selectedTopic.descriptionUrdu}
            </div>
          </div>
        </div>

        {/* Gas Pressure Table if present */}
        {selectedTopic.pressureTable && (
          <div className="p-4 rounded-xl bg-[#071326] border border-[#1E4680]">
            <span className="text-xs font-bold uppercase tracking-wider text-[#E8A85C] block mb-3">
              Standard Gas Pressures at 35°C Ambient (گیس چارجنگ پریشر ٹیبل):
            </span>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-[#0F294E] text-[#E8A85C] uppercase text-[10px] font-bold border-b border-[#1E4680]">
                  <tr>
                    <th className="p-2.5 font-bold">Refrigerant Gas</th>
                    <th className="p-2.5">Suction Pressure (Low)</th>
                    <th className="p-2.5">Discharge Pressure (High)</th>
                    <th className="p-2.5">Standing Pressure</th>
                    <th className="p-2.5 font-urdu text-right">خصوصی احتیاط</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {selectedTopic.pressureTable.map((g, idx) => (
                    <tr key={idx} className="hover:bg-[#0F294E]/60 transition">
                      <td className="p-2.5 font-bold text-white font-mono">{g.gas}</td>
                      <td className="p-2.5 font-mono text-emerald-400 font-bold">{g.suctionPsi}</td>
                      <td className="p-2.5 font-mono text-amber-400 font-bold">{g.dischargePsi}</td>
                      <td className="p-2.5 font-mono text-slate-300">{g.standingPsi}</td>
                      <td className="p-2.5 font-urdu text-[#E8A85C] text-right">{g.notesUrdu}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Thermostat Wiring Table if present */}
        {selectedTopic.thermostatWiring && (
          <div className="p-4 rounded-xl bg-[#071326] border border-[#1E4680]">
            <span className="text-xs font-bold uppercase tracking-wider text-[#38BDF8] block mb-3">
              Thermostat Standard Color Codes (تھرموسٹیٹ تاروں کے رنگ):
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {selectedTopic.thermostatWiring.map((tw, idx) => (
                <div key={idx} className="p-2.5 rounded-lg bg-[#0F294E] border border-slate-700/60 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-mono font-bold text-[#E8A85C] text-sm">{tw.terminal}</span>
                    <span className="text-slate-300 ml-2 font-medium">({tw.wireColor} Wire)</span>
                    <p className="text-[11px] text-slate-400">{tw.function}</p>
                  </div>
                  <span className="font-urdu text-[#38BDF8] text-[11px] text-right">{tw.functionUrdu}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Zoom Modal */}
      {zoomedDiagram && (
        <DiagramZoomModal
          isOpen={true}
          onClose={() => setZoomedDiagram(null)}
          title={zoomedDiagram.title}
          titleUrdu={zoomedDiagram.titleUrdu}
          diagramType={zoomedDiagram.type}
        />
      )}

      {/* Owner Notes Modal */}
      {activeNoteTopic && (
        <OwnerNotesModal
          isOpen={true}
          onClose={() => setActiveNoteTopic(null)}
          topicId={activeNoteTopic.id}
          topicTitle={activeNoteTopic.title}
          topicTitleUrdu={activeNoteTopic.titleUrdu}
        />
      )}
    </div>
  );
};
