import React, { useState, useMemo } from 'react';
import {
  Calculator,
  BookOpen,
  GitFork,
  Cpu,
  Radar,
  Gauge,
  Wind,
  Building,
  Flame,
  ArrowUpDown,
  Layers,
  Box,
  ShieldAlert,
  Wrench,
  FileText,
  DollarSign,
  ArrowRight,
  Search,
  Zap,
  CheckCircle2,
  Lock,
  Compass,
  Activity,
  SlidersHorizontal,
  ChevronRight,
  Sparkles,
  HardDriveDownload,
  AlertTriangle,
} from 'lucide-react';
import { MODULES_CATALOG } from '../data/modules';
import { FORMULAS_DATA } from '../data/formulasData';
import { CALCULATORS_DATA } from '../data/calculatorsData';
import { DIAGRAMS_DATA } from '../data/diagramsData';
import { ModuleId, ModuleInfo } from '../types';

interface HomeViewProps {
  onSelectModule: (id: ModuleId) => void;
  onOpenRates: () => void;
  onOpenSearch: () => void;
  onOpenVoice?: () => void;
}

const ICON_MAP: Record<string, React.ReactNode> = {
  Calculator: <Calculator className="w-5 h-5" />,
  BookOpen: <BookOpen className="w-5 h-5" />,
  GitFork: <GitFork className="w-5 h-5" />,
  Cpu: <Cpu className="w-5 h-5" />,
  Radar: <Radar className="w-5 h-5" />,
  Gauge: <Gauge className="w-5 h-5" />,
  Wind: <Wind className="w-5 h-5" />,
  Building: <Building className="w-5 h-5" />,
  Flame: <Flame className="w-5 h-5" />,
  ArrowUpDown: <ArrowUpDown className="w-5 h-5" />,
  Layers: <Layers className="w-5 h-5" />,
  Box: <Box className="w-5 h-5" />,
  ShieldAlert: <ShieldAlert className="w-5 h-5" />,
  Wrench: <Wrench className="w-5 h-5" />,
  FileText: <FileText className="w-5 h-5" />,
};

type CategoryFilter = 'all' | 'core' | 'automation' | 'systems' | 'field_work';

export const HomeView: React.FC<HomeViewProps> = ({
  onSelectModule,
  onOpenRates,
  onOpenSearch,
  onOpenVoice,
}) => {
  const [activeCategory, setActiveCategory] = useState<CategoryFilter>('all');
  const [inlineSearch, setInlineSearch] = useState<string>('');
  const [showQuickCalc, setShowQuickCalc] = useState<boolean>(false);

  // Quick live mini-calculator states for dashboard convenience
  const [quickVoltage, setQuickVoltage] = useState<number>(400);
  const [quickPowerHP, setQuickPowerHP] = useState<number>(10);
  const [quickPF, setQuickPF] = useState<number>(0.85);

  // 3-Phase Current formula: I = (HP * 746) / (sqrt(3) * V * PF * 0.88)
  const quickCurrentAmps = useMemo(() => {
    const v = Number(quickVoltage) || 400;
    const hp = Number(quickPowerHP) || 0;
    const pf = Number(quickPF) || 0.85;
    const watts = hp * 746;
    const current = watts / (1.732 * v * pf * 0.88);
    return isFinite(current) ? current.toFixed(1) : '0.0';
  }, [quickVoltage, quickPowerHP, quickPF]);

  // Filter modules based on category
  const filteredModules = useMemo(() => {
    return MODULES_CATALOG.filter((mod) => {
      const matchesCategory = activeCategory === 'all' || mod.category === activeCategory;
      const q = inlineSearch.trim().toLowerCase();
      const matchesSearch =
        !q ||
        mod.title.toLowerCase().includes(q) ||
        mod.titleUrdu.includes(q) ||
        mod.tagline.toLowerCase().includes(q) ||
        mod.taglineUrdu.includes(q);
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, inlineSearch]);

  // Real-time quick search suggestions
  const quickChips = [
    { label: 'Ohm’s Law', urdu: 'اوہم لاء', mod: 'calculators' as ModuleId },
    { label: 'Motor FLA', urdu: 'موٹر ایمپئر', mod: 'calculators' as ModuleId },
    { label: 'Star-Delta', urdu: 'سٹار ڈیلٹا', mod: 'plc' as ModuleId },
    { label: 'VFD Danfoss', urdu: 'وی ایف ڈی پیرامیٹرز', mod: 'vfd' as ModuleId },
    { label: 'House Wiring', urdu: 'گھریلو وائرنگ', mod: 'diagrams' as ModuleId },
    { label: 'HVAC CSR', urdu: 'کمپریسر CSR', mod: 'hvac' as ModuleId },
    { label: 'Sensors PNP/NPN', urdu: 'سینسرز', mod: 'sensors' as ModuleId },
    { label: 'Fire Alarm', urdu: 'فائر پینل', mod: 'fire_alarm' as ModuleId },
    { label: 'Work Diary', urdu: 'کسٹمر کھاتہ', mod: 'work_diary' as ModuleId },
  ];

  return (
    <div className="space-y-6 pb-14">
      {/* 1. Modern Engineering Hero Section */}
      <section className="relative rounded-2xl bg-gradient-to-br from-[#0B172E] via-[#0D1E3A] to-[#070F1E] border border-[#1E3A70] p-5 sm:p-7 shadow-xl overflow-hidden">
        {/* Subtle Engineering Blueprint Accent */}
        <div className="absolute inset-0 engineering-grid opacity-25 pointer-events-none" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#0EA5E9]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-72 h-72 bg-[#E8A85C]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            {/* System Status Row */}
            <div className="flex items-center gap-2 flex-wrap text-xs">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#0284C7]/20 border border-[#0EA5E9]/40 text-[#38BDF8] font-mono font-medium">
                <Zap className="w-3.5 h-3.5 text-[#38BDF8]" />
                100% OFFLINE ENCYCLOPEDIA
              </span>
              <span className="text-slate-400 font-mono text-[11px]">
                VERSION 2026 PRO · BY SHAHID MEHMOOD
              </span>
            </div>

            {/* Main Title */}
            <div>
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight font-sans">
                H Electrician <span className="text-[#38BDF8]">Pro</span>
                <span className="text-sm font-semibold text-[#E8A85C] ml-2 font-mono">INDUSTRIAL</span>
              </h1>
              <p className="text-sm sm:text-base text-[#E8A85C] font-urdu font-medium mt-1 leading-relaxed">
                شاہد محمود (SHAHID MEHMOOD) کا مکمل انڈسٹریل آٹومیشن اور برقی انجینئرنگ انسائیکلوپیڈیا
              </p>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans max-w-xl">
              Unified offline workspace featuring 15 modules: live step-by-step electrical calculators, 100+ formula references, HD wiring diagrams, Siemens S7-1200 PLC, VFDs, sensors, HVAC chillers, and customer work billing.
            </p>

            {/* Quick Metrics Strip */}
            <div className="pt-2 flex items-center gap-3 sm:gap-6 flex-wrap text-xs text-slate-300 font-mono">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#38BDF8]" />
                <span className="font-bold text-white">15</span> Modules
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="font-bold text-white">20+</span> HD Schematics
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#E8A85C]" />
                <span className="font-bold text-white">100+</span> Formulas
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-indigo-400" />
                <span>Offline DB</span>
              </div>
            </div>
          </div>

          {/* Quick Action Dock */}
          <div className="flex flex-row lg:flex-col gap-2.5 flex-shrink-0">
            {/* Voice Search Primary Action */}
            {onOpenVoice && (
              <button
                onClick={onOpenVoice}
                className="flex-1 lg:flex-initial px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#0284C7] via-[#0369A1] to-[#0284C7] hover:opacity-95 text-white font-bold text-xs flex items-center justify-center gap-2 border border-[#38BDF8] shadow-lg shadow-sky-950/60 transition cursor-pointer active:scale-95 group"
              >
                <span className="text-base group-hover:scale-125 transition-transform">🎤</span>
                <div className="text-left leading-tight">
                  <div className="flex items-center gap-1.5">
                    <span>Voice Search</span>
                    <span className="text-[9px] font-mono bg-sky-900/90 text-sky-200 px-1 py-0.2 rounded border border-sky-400/40">BOLAIN</span>
                  </div>
                  <div className="text-[10px] font-urdu font-normal text-sky-200">🎤 بول کے دکھاؤ</div>
                </div>
              </button>
            )}

            <button
              onClick={() => onSelectModule('diagrams')}
              className="flex-1 lg:flex-initial px-4 py-2.5 rounded-xl bg-[#0F2042] hover:bg-[#162C58] text-white font-bold text-xs flex items-center justify-center gap-2 border border-[#1E3A70] hover:border-[#38BDF8] shadow-sm transition cursor-pointer"
            >
              <GitFork className="w-4 h-4 text-[#38BDF8]" />
              <div className="text-left leading-tight">
                <div>Visual Schematics (HD)</div>
                <div className="text-[10px] font-urdu font-normal text-[#E8A85C]">بصری وائرنگ خاکے</div>
              </div>
            </button>

            <button
              onClick={onOpenRates}
              className="flex-1 lg:flex-initial px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#B87333] to-[#E8A85C] hover:opacity-95 text-[#070F1E] font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-[#E8A85C]/20 transition cursor-pointer"
            >
              <DollarSign className="w-4 h-4" />
              <div className="text-left leading-tight">
                <div>My Rates (PIN)</div>
                <div className="text-[10px] font-urdu font-normal text-amber-950">میری ریٹ لسٹ</div>
              </div>
            </button>

            <button
              onClick={() => onSelectModule('work_diary')}
              className="flex-1 lg:flex-initial px-4 py-2.5 rounded-xl bg-[#0B172E] hover:bg-[#162C58] text-slate-100 font-semibold text-xs flex items-center justify-center gap-2 border border-[#1E3A70] hover:border-[#0EA5E9]/60 transition cursor-pointer"
            >
              <FileText className="w-4 h-4 text-[#38BDF8]" />
              <div className="text-left leading-tight">
                <div>Work Diary & Billing</div>
                <div className="text-[10px] font-urdu font-normal text-slate-300">کسٹمر کھاتہ و بلنگ</div>
              </div>
            </button>

            <button
              onClick={() => setShowQuickCalc(!showQuickCalc)}
              className="hidden sm:flex px-4 py-2 rounded-xl bg-[#0F2042] hover:bg-[#162C58] text-[#38BDF8] text-xs font-semibold items-center justify-center gap-2 border border-[#1E3A70] transition cursor-pointer"
            >
              <Calculator className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span>{showQuickCalc ? 'Hide Mini Calc' : 'Quick FLA Tool'}</span>
            </button>
          </div>
        </div>
      </section>

      {/* 2. Interactive Quick Motor FLA / Ohm's Mini-Calculator Widget (Collapsible) */}
      {showQuickCalc && (
        <section className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#0EA5E9]/50 shadow-xl space-y-3 animate-fadeIn">
          <div className="flex items-center justify-between pb-2 border-b border-[#1E3A70]">
            <div className="flex items-center gap-2">
              <Calculator className="w-4 h-4 text-[#38BDF8]" />
              <h3 className="text-sm font-bold text-white font-sans">
                Quick Field Motor Current Calculator (تھری فیز موٹر ایمپئر)
              </h3>
            </div>
            <button
              onClick={() => onSelectModule('calculators')}
              className="text-xs text-[#38BDF8] hover:underline flex items-center gap-1 font-semibold"
            >
              Open Full 7 Calculators <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="text-slate-300 font-medium block mb-1">Motor Power (HP / ہارس پاور):</label>
              <input
                type="number"
                min="0.5"
                step="0.5"
                value={quickPowerHP}
                onChange={(e) => setQuickPowerHP(Number(e.target.value))}
                className="w-full rounded-lg bg-[#070F1E] border border-[#1E3A70] focus:border-[#0EA5E9] focus:outline-none p-2 text-white font-mono font-bold"
              />
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">Line Voltage (V / وولٹیج):</label>
              <input
                type="number"
                value={quickVoltage}
                onChange={(e) => setQuickVoltage(Number(e.target.value))}
                className="w-full rounded-lg bg-[#070F1E] border border-[#1E3A70] focus:border-[#0EA5E9] focus:outline-none p-2 text-white font-mono font-bold"
              />
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">Power Factor (cos φ):</label>
              <input
                type="number"
                min="0.5"
                max="1.0"
                step="0.05"
                value={quickPF}
                onChange={(e) => setQuickPF(Number(e.target.value))}
                className="w-full rounded-lg bg-[#070F1E] border border-[#1E3A70] focus:border-[#0EA5E9] focus:outline-none p-2 text-white font-mono font-bold"
              />
            </div>

            <div className="p-3 rounded-xl bg-[#0F2042] border border-[#0EA5E9]/40 flex flex-col justify-center">
              <span className="text-[10px] text-slate-400 block font-mono uppercase">Full Load Amps (FLA)</span>
              <div className="flex items-baseline gap-1">
                <span className="text-xl font-extrabold text-[#38BDF8] font-mono">{quickCurrentAmps}</span>
                <span className="text-xs text-slate-300 font-mono">Amps</span>
              </div>
              <span className="text-[10px] text-[#E8A85C] font-urdu">فل لوڈ کرنٹ (ایمپئر)</span>
            </div>
          </div>
        </section>
      )}

      {/* 3. Clean Engineering Search Bar */}
      <div className="space-y-2.5">
        <div className="relative">
          <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#38BDF8]" />
          <input
            type="text"
            value={inlineSearch}
            onChange={(e) => setInlineSearch(e.target.value)}
            placeholder="Search formulas, diagrams, PLC ladder, VFD parameters, parts or faults... (سرچ کریں)"
            className="w-full rounded-xl bg-[#0B172E] border border-[#1E3A70] focus:border-[#0EA5E9] focus:outline-none pl-11 pr-24 py-3 text-sm text-slate-100 placeholder-slate-400 shadow-md font-sans transition"
          />
          {inlineSearch ? (
            <button
              onClick={() => setInlineSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold px-2 py-1 rounded bg-[#162C58] text-slate-300 hover:text-white"
            >
              Clear
            </button>
          ) : (
            <button
              onClick={onOpenSearch}
              className="hidden sm:inline-flex items-center gap-1 absolute right-3 top-1/2 -translate-y-1/2 text-[11px] font-mono px-2.5 py-1 rounded-md bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] hover:border-[#0EA5E9]"
            >
              <span>Full Search</span>
              <kbd className="bg-[#070F1E] px-1 rounded text-[9px] text-slate-400">Ctrl+K</kbd>
            </button>
          )}
        </div>

        {/* Quick Search Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
          <span className="text-[11px] text-slate-400 whitespace-nowrap pl-1 pr-1 font-medium">Quick:</span>
          {quickChips.map((chip) => (
            <button
              key={chip.label}
              onClick={() => onSelectModule(chip.mod)}
              className="px-2.5 py-1 rounded-lg bg-[#0B172E] hover:bg-[#162C58] text-slate-300 hover:text-[#38BDF8] border border-[#1E3A70] transition whitespace-nowrap cursor-pointer flex items-center gap-1.5 text-xs"
            >
              <span>{chip.label}</span>
              <span className="text-[10px] text-[#E8A85C] font-urdu font-normal">{chip.urdu}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 4. Category Filter Tabs */}
      <div className="flex items-center justify-between gap-3 border-b border-[#1E3A70] pb-3 pt-1 flex-wrap">
        <div className="flex items-center gap-1.5 p-1 bg-[#0B172E] rounded-xl border border-[#1E3A70] overflow-x-auto max-w-full">
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer whitespace-nowrap ${
              activeCategory === 'all'
                ? 'bg-[#0284C7] text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            All Modules ({MODULES_CATALOG.length})
          </button>
          <button
            onClick={() => setActiveCategory('core')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer whitespace-nowrap ${
              activeCategory === 'core'
                ? 'bg-[#0284C7] text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Core & Calcs
          </button>
          <button
            onClick={() => setActiveCategory('automation')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer whitespace-nowrap ${
              activeCategory === 'automation'
                ? 'bg-[#0284C7] text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Industrial Automation
          </button>
          <button
            onClick={() => setActiveCategory('systems')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer whitespace-nowrap ${
              activeCategory === 'systems'
                ? 'bg-[#0284C7] text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Building & HVAC
          </button>
          <button
            onClick={() => setActiveCategory('field_work')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer whitespace-nowrap ${
              activeCategory === 'field_work'
                ? 'bg-[#0284C7] text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Safety & Field Diary
          </button>
        </div>

        <span className="text-xs font-mono text-slate-400">
          Showing {filteredModules.length} of {MODULES_CATALOG.length}
        </span>
      </div>

      {/* 5. Organized Category Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4.5">
        {filteredModules.map((mod) => (
          <div
            key={mod.id}
            onClick={() => onSelectModule(mod.id)}
            className="p-4 sm:p-5 rounded-xl bg-[#0B172E] hover:bg-[#0F2042] border border-[#1E3A70] hover:border-[#0EA5E9] shadow-md hover:shadow-xl hover:shadow-[#0EA5E9]/10 transition-all duration-200 cursor-pointer flex flex-col justify-between group hover:-translate-y-0.5 relative overflow-hidden"
          >
            {/* Top Row: Icon + Module Index & Topics Tag */}
            <div>
              <div className="flex items-center justify-between mb-3.5">
                <div className="w-11 h-11 rounded-xl bg-[#070F1E] border border-[#1E3A70] group-hover:border-[#0EA5E9] flex items-center justify-center text-[#38BDF8] shadow-sm transition-colors">
                  {ICON_MAP[mod.iconName] || <Box className="w-5 h-5" />}
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-mono font-bold bg-[#162C58] text-[#38BDF8] px-2 py-0.5 rounded border border-[#1E3A70]">
                    MOD {mod.moduleNumber < 10 ? `0${mod.moduleNumber}` : mod.moduleNumber}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 bg-[#070F1E] px-2 py-0.5 rounded border border-[#1E3A70]/60">
                    {mod.topicsCount} Topics
                  </span>
                </div>
              </div>

              {/* Title & Bilingual Subtitle */}
              <div className="space-y-1">
                <h3 className="text-base font-bold text-white group-hover:text-[#38BDF8] transition font-sans tracking-tight">
                  {mod.title}
                </h3>
                <p className="text-xs text-[#E8A85C] font-urdu font-medium leading-relaxed">
                  {mod.titleUrdu}
                </p>
                <p className="text-xs text-slate-400 leading-relaxed pt-1 line-clamp-2 font-sans">
                  {mod.tagline}
                </p>
              </div>
            </div>

            {/* Bottom Info Bar */}
            <div className="mt-4 pt-3 border-t border-[#1E3A70]/60 flex items-center justify-between text-xs text-slate-400 group-hover:text-[#38BDF8] transition">
              <span className="font-urdu text-[11px] text-slate-400 group-hover:text-amber-200 truncate pr-2">
                {mod.taglineUrdu}
              </span>
              <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-[#38BDF8] group-hover:translate-x-1 transition flex-shrink-0" />
            </div>
          </div>
        ))}
      </div>

      {/* 6. Quick Field Operational Guidelines / Trust Banner */}
      <section className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#1E3A70] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#070F1E] border border-[#1E3A70] flex items-center justify-center text-[#E8A85C] flex-shrink-0 mt-0.5">
            <Lock className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white font-sans">
              Owner Confidentiality & Local Storage (شاہد الیکٹریشن ذاتی ڈیٹا)
            </h4>
            <p className="text-xs text-slate-300 font-urdu mt-0.5">
              آپ کی ذاتی ریٹ لسٹ، کسٹمر بلنگ، فون نمبرز اور ذاتی نوٹس 100% آف لائن آپ کے موبائل میں محفوظ رہتے ہیں۔
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end md:self-auto flex-shrink-0">
          <button
            onClick={onOpenRates}
            className="px-3.5 py-2 rounded-xl bg-[#162C58] hover:bg-[#1E3A70] text-[#E8A85C] text-xs font-semibold border border-[#E8A85C]/30 flex items-center gap-1.5 transition cursor-pointer"
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>Open My Rates</span>
          </button>
          <button
            onClick={() => onSelectModule('work_diary')}
            className="px-3.5 py-2 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Manage Customer Billing</span>
          </button>
        </div>
      </section>
    </div>
  );
};
