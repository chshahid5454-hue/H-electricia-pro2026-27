import React, { useState } from 'react';
import { Cpu, Maximize2, Edit3, CheckCircle, Code, Layers, FileCode } from 'lucide-react';
import { PLC_TOPICS_DATA } from '../data/plcData';
import { PLCTopic } from '../types';
import { DiagramRenderer } from '../components/DiagramRenderer';
import { DiagramZoomModal } from '../components/DiagramZoomModal';
import { OwnerNotesModal } from '../components/OwnerNotesModal';
import { StorageService } from '../services/storage';

export const PLCView: React.FC = () => {
  const [selectedTopic, setSelectedTopic] = useState<PLCTopic>(PLC_TOPICS_DATA[0]);
  const [zoomedDiagram, setZoomedDiagram] = useState<{ title: string; titleUrdu: string; type: string } | null>(null);
  const [activeNoteTopic, setActiveNoteTopic] = useState<PLCTopic | null>(null);

  const hasOwnerNote = Boolean(StorageService.getOwnerNote(selectedTopic.id));

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white font-sans flex items-center gap-2">
              <Cpu className="w-5 h-5 text-[#38BDF8]" />
              Siemens S7-1200 PLC Programming | سیمنز پی ایل سی پروگرامنگ
            </h2>
            <p className="text-xs text-slate-300 font-urdu mt-0.5">
              سی پی یو 1214C ہارڈ ویئر وائرنگ، لیڈر لاجک، سٹار ڈیلٹا، ٹینک لیول اور ٹیا پورٹل
            </p>
          </div>
          <span className="text-xs font-mono bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] px-3 py-1 rounded-md font-bold">
            TIA Portal Ready
          </span>
        </div>

        {/* Topic Navigation Buttons */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {PLC_TOPICS_DATA.map((t) => {
            const isSelected = selectedTopic.id === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setSelectedTopic(t)}
                className={`px-3 py-2 rounded-xl text-left flex-shrink-0 transition border cursor-pointer ${
                  isSelected
                    ? 'bg-[#0284C7] text-white font-bold border-[#38BDF8] shadow'
                    : 'bg-[#0F2042] hover:bg-[#162C58] text-slate-200 border-[#1E3A70]'
                }`}
              >
                <span className="text-xs font-bold block truncate max-w-[200px]">{t.title.split('(')[0]}</span>
                <span className={`text-[11px] font-urdu block truncate max-w-[200px] ${isSelected ? 'text-blue-100' : 'text-[#E8A85C]'}`}>
                  {t.titleUrdu.split('(')[0]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Topic Content Card */}
      <div className="p-4 sm:p-6 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl space-y-4">
        {/* Title Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1E3A70]">
          <div>
            <span className="text-[10px] uppercase font-bold text-[#38BDF8] tracking-wider bg-[#162C58] px-2 py-0.5 rounded border border-[#1E3A70]">
              {selectedTopic.category.toUpperCase()}
            </span>
            <h3 className="text-base sm:text-xl font-bold text-white font-sans mt-1">
              {selectedTopic.title}
            </h3>
            <p className="text-xs sm:text-sm text-[#E8A85C] font-urdu font-medium mt-0.5">
              {selectedTopic.titleUrdu}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveNoteTopic(selectedTopic)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer ${
                hasOwnerNote
                  ? 'bg-amber-500/20 text-[#E8A85C] border-[#E8A85C]'
                  : 'bg-[#162C58] text-slate-300 border-[#1E3A70] hover:text-white'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5 text-[#E8A85C]" />
              <span className="font-urdu">My Notes {hasOwnerNote && '✓'}</span>
            </button>

            {selectedTopic.diagramType && (
              <button
                onClick={() =>
                  setZoomedDiagram({
                    title: selectedTopic.title,
                    titleUrdu: selectedTopic.titleUrdu,
                    type: selectedTopic.diagramType || 'ladder_latch',
                  })
                }
                className="px-3.5 py-1.5 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-white text-xs font-bold flex items-center gap-1.5 shadow transition cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>HD Ladder Zoom</span>
              </button>
            )}
          </div>
        </div>

        {/* Vector Diagram Preview if present */}
        {selectedTopic.diagramType && (
          <div
            onClick={() =>
              setZoomedDiagram({
                title: selectedTopic.title,
                titleUrdu: selectedTopic.titleUrdu,
                type: selectedTopic.diagramType || 'ladder_latch',
              })
            }
            className="rounded-xl overflow-hidden cursor-pointer group border border-[#1E3A70] bg-[#070F1E] relative"
          >
            <DiagramRenderer type={selectedTopic.diagramType} className="group-hover:scale-[1.01] transition duration-300" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
              <span className="px-4 py-2 rounded-xl bg-[#0284C7] text-white font-bold text-xs flex items-center gap-1.5 shadow-xl">
                <Maximize2 className="w-4 h-4" /> Tap to Zoom Ladder Logic & Wiring
              </span>
            </div>
          </div>
        )}

        {/* Bilingual Content Text */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 pt-2">
          {/* English Technical Guide */}
          <div className="p-4 rounded-xl bg-[#0F2042] border border-[#1E3A70] text-xs text-slate-200 leading-relaxed font-sans space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#38BDF8] block mb-1">
              Technical Specification & Execution Guide:
            </span>
            <div className="whitespace-pre-line font-mono-code text-[11px] sm:text-xs">
              {selectedTopic.content}
            </div>
          </div>

          {/* Urdu Explanation */}
          <div className="p-4 rounded-xl bg-[#0F2042] border border-[#1E3A70] text-xs sm:text-sm text-slate-200 leading-relaxed font-urdu space-y-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#E8A85C] block mb-1">
              اردو گائیڈ اور آسان وضاحت:
            </span>
            <div className="whitespace-pre-line" dir="rtl">
              {selectedTopic.contentUrdu}
            </div>
          </div>
        </div>

        {/* Key Points */}
        {selectedTopic.keyPoints && (
          <div className="p-3.5 rounded-xl bg-[#070F1E] border border-[#1E3A70]">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 block mb-1.5">
              Crucial Electrician Engineering Notes (اہم نکات):
            </span>
            <ul className="space-y-1.5 text-xs text-slate-200">
              {selectedTopic.keyPoints.map((kp, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <span>{kp}</span>
                    {selectedTopic.keyPointsUrdu?.[idx] && (
                      <span className="block font-urdu text-[11px] text-[#E8A85C]">
                        {selectedTopic.keyPointsUrdu[idx]}
                      </span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Zoom Modal */}
      {zoomedDiagram && (
        <DiagramZoomModal
          isOpen={true}
          onClose={() => setZoomedDiagram(null)}
          title={zoomedDiagram.title}
          titleUrdu={zoomedDiagram.titleUrdu}
          diagramType={zoomedDiagram.type}
        />
      )}

      {/* Owner Notes Modal */}
      {activeNoteTopic && (
        <OwnerNotesModal
          isOpen={true}
          onClose={() => setActiveNoteTopic(null)}
          topicId={activeNoteTopic.id}
          topicTitle={activeNoteTopic.title}
          topicTitleUrdu={activeNoteTopic.titleUrdu}
        />
      )}
    </div>
  );
};
