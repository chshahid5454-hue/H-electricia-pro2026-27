import React, { useState } from 'react';
import { Radar, Maximize2, Edit3, CheckCircle, Wrench, AlertCircle } from 'lucide-react';
import { SENSORS_DATA } from '../data/sensorsData';
import { SensorItem } from '../types';
import { DiagramRenderer } from '../components/DiagramRenderer';
import { DiagramZoomModal } from '../components/DiagramZoomModal';
import { OwnerNotesModal } from '../components/OwnerNotesModal';
import { StorageService } from '../services/storage';

export const SensorsView: React.FC = () => {
  const [selectedSensor, setSelectedSensor] = useState<SensorItem>(SENSORS_DATA[0]);
  const [zoomedDiagram, setZoomedDiagram] = useState<{ title: string; titleUrdu: string; type: string } | null>(null);
  const [activeNoteTopic, setActiveNoteTopic] = useState<SensorItem | null>(null);

  const hasOwnerNote = Boolean(StorageService.getOwnerNote(selectedSensor.id));

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white font-sans flex items-center gap-2">
              <Radar className="w-5 h-5 text-[#38BDF8]" />
              Sensors & Limit Switches | سینسرز اور لمٹ سوئچز
            </h2>
            <p className="text-xs text-slate-300 font-urdu mt-0.5">
              پی این پی بمقابلہ این پی این، انڈکٹو، کپیسیٹو، لمٹ سوئچ اور ملٹی میٹر سے ٹیسٹ کرنے کا طریقہ
            </p>
          </div>
          <span className="text-xs font-mono bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] px-3 py-1 rounded-md font-bold">
            Brown / Blue / Black
          </span>
        </div>

        {/* Sensor Navigation Pills */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {SENSORS_DATA.map((s) => {
            const isSelected = selectedSensor.id === s.id;
            return (
              <button
                key={s.id}
                onClick={() => setSelectedSensor(s)}
                className={`px-3 py-2 rounded-xl text-left flex-shrink-0 transition border cursor-pointer ${
                  isSelected
                    ? 'bg-[#0284C7] text-white font-bold border-[#38BDF8] shadow'
                    : 'bg-[#0F2042] hover:bg-[#162C58] text-slate-200 border-[#1E3A70]'
                }`}
              >
                <span className="text-xs font-bold block truncate max-w-[210px]">{s.title.split('(')[0]}</span>
                <span className={`text-[11px] font-urdu block truncate max-w-[210px] ${isSelected ? 'text-blue-100' : 'text-[#E8A85C]'}`}>
                  {s.titleUrdu.split('(')[0]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Sensor Detail Card */}
      <div className="p-4 sm:p-6 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl space-y-4">
        {/* Card Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1E3A70]">
          <div>
            <h3 className="text-base sm:text-xl font-bold text-white font-sans">{selectedSensor.title}</h3>
            <p className="text-xs sm:text-sm text-[#E8A85C] font-urdu font-medium mt-0.5">{selectedSensor.titleUrdu}</p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveNoteTopic(selectedSensor)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer ${
                hasOwnerNote
                  ? 'bg-amber-500/20 text-[#E8A85C] border-[#E8A85C]'
                  : 'bg-[#162C58] text-slate-300 border-[#1E3A70] hover:text-white'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5 text-[#E8A85C]" />
              <span className="font-urdu">My Notes {hasOwnerNote && '✓'}</span>
            </button>

            <button
              onClick={() =>
                setZoomedDiagram({
                  title: selectedSensor.title,
                  titleUrdu: selectedSensor.titleUrdu,
                  type: selectedSensor.diagramType,
                })
              }
              className="px-3.5 py-1.5 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-white text-xs font-bold flex items-center gap-1.5 shadow transition cursor-pointer"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>HD Circuit Zoom</span>
            </button>
          </div>
        </div>

        {/* Vector Schematic Preview */}
        <div
          onClick={() =>
            setZoomedDiagram({
              title: selectedSensor.title,
              titleUrdu: selectedSensor.titleUrdu,
              type: selectedSensor.diagramType,
            })
          }
          className="rounded-xl overflow-hidden cursor-pointer group border border-[#1E3A70] bg-[#070F1E] relative"
        >
          <DiagramRenderer type={selectedSensor.diagramType} className="group-hover:scale-[1.01] transition duration-300" />
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
            <span className="px-4 py-2 rounded-xl bg-[#0284C7] text-white font-bold text-xs flex items-center gap-1.5 shadow-xl">
              <Maximize2 className="w-4 h-4" /> Tap to Zoom Circuit & Pinout
            </span>
          </div>
        </div>

        {/* Color Codes Table */}
        <div className="p-3.5 rounded-xl bg-[#0F2042] border border-[#1E3A70]">
          <span className="text-xs font-bold uppercase tracking-wider text-[#38BDF8] block mb-2">
            Industrial Sensor Wire Color Codes (تاروں کے رنگ اور سگنل):
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {selectedSensor.colorCode.map((c, i) => (
              <div key={i} className="p-2.5 rounded-lg bg-[#070F1E] border border-[#1E3A70] flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-3.5 h-3.5 rounded-full border border-white" style={{ backgroundColor: c.color }} />
                  <div>
                    <span className="font-bold text-white block">{c.wire}</span>
                    <span className="text-[11px] text-slate-300">{c.signal}</span>
                  </div>
                </div>
                <div className="text-right font-urdu text-[#E8A85C] text-[11px]">
                  <span>{c.colorUrdu}</span>
                  <span className="block text-slate-400 text-[10px]">{c.signalUrdu}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Explanation & Working Principle */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-[#0F2042] border border-[#1E3A70] text-xs text-slate-200 leading-relaxed font-sans space-y-1.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#38BDF8] block">
              Working Principle & Electrical Operation:
            </span>
            <p className="whitespace-pre-line">{selectedSensor.workingPrinciple}</p>
          </div>

          <div className="p-4 rounded-xl bg-[#0F2042] border border-[#1E3A70] text-xs sm:text-sm text-slate-200 leading-relaxed font-urdu space-y-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#E8A85C] block">
              کام کرنے کا اصول اور وائرنگ:
            </span>
            <p className="whitespace-pre-line" dir="rtl">{selectedSensor.workingPrincipleUrdu}</p>
          </div>
        </div>

        {/* Multimeter Testing Method */}
        <div className="p-4 rounded-xl bg-[#070F1E] border border-amber-900/40 space-y-2">
          <div className="flex items-center gap-2">
            <Wrench className="w-4 h-4 text-amber-400" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-300 font-sans">
              How to Test with Multimeter (ملٹی میٹر سے چیک کرنے کا طریقہ):
            </h4>
          </div>
          <p className="text-xs text-slate-300 font-mono pl-6 leading-relaxed">
            {selectedSensor.testingMethod}
          </p>
          <p className="text-xs text-[#E8A85C] font-urdu pl-6 leading-relaxed" dir="rtl">
            {selectedSensor.testingMethodUrdu}
          </p>
        </div>
      </div>

      {/* Zoom Modal */}
      {zoomedDiagram && (
        <DiagramZoomModal
          isOpen={true}
          onClose={() => setZoomedDiagram(null)}
          title={zoomedDiagram.title}
          titleUrdu={zoomedDiagram.titleUrdu}
          diagramType={zoomedDiagram.type}
        />
      )}

      {/* Owner Notes Modal */}
      {activeNoteTopic && (
        <OwnerNotesModal
          isOpen={true}
          onClose={() => setActiveNoteTopic(null)}
          topicId={activeNoteTopic.id}
          topicTitle={activeNoteTopic.title}
          topicTitleUrdu={activeNoteTopic.titleUrdu}
        />
      )}
    </div>
  );
};
