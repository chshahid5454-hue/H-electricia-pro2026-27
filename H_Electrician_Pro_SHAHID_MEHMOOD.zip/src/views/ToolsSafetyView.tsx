import React, { useState } from 'react';
import { ShieldAlert, Maximize2, Edit3, HeartPulse, CheckCircle, AlertTriangle, ShieldCheck } from 'lucide-react';
import { TOOLS_SAFETY_DATA } from '../data/toolsSafetyData';
import { ToolSafetyTopic } from '../types';
import { DiagramRenderer } from '../components/DiagramRenderer';
import { DiagramZoomModal } from '../components/DiagramZoomModal';
import { OwnerNotesModal } from '../components/OwnerNotesModal';
import { StorageService } from '../services/storage';

export const ToolsSafetyView: React.FC = () => {
  const [selectedTopic, setSelectedTopic] = useState<ToolSafetyTopic>(TOOLS_SAFETY_DATA[0]);
  const [zoomedDiagram, setZoomedDiagram] = useState<{ title: string; titleUrdu: string; type: string } | null>(null);
  const [activeNoteTopic, setActiveNoteTopic] = useState<ToolSafetyTopic | null>(null);

  const hasOwnerNote = Boolean(StorageService.getOwnerNote(selectedTopic.id));

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="p-4 rounded-2xl bg-[#0A1E3C] border-2 border-[#1E4680] shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white font-sans flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-[#4ADE80]" />
              Tools & Electrician Safety | ٹولز اور الیکٹریشن سیفٹی
            </h2>
            <p className="text-xs text-slate-300 font-urdu mt-0.5">
              کلیمپ میٹر، میگر، 10 سنہری سیفٹی اصول، کرنٹ لگنے پر فرسٹ ایڈ (1122) اور کیمیکل ارتھنگ پٹ
            </p>
          </div>
          <span className="text-xs font-mono bg-[#163768] text-[#E8A85C] border border-[#1E4680] px-3 py-1 rounded-full font-bold">
            Rescue 1122 Guide
          </span>
        </div>

        {/* Topic Pills */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {TOOLS_SAFETY_DATA.map((t) => {
            const isSelected = selectedTopic.id === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setSelectedTopic(t)}
                className={`px-3 py-2 rounded-xl text-left flex-shrink-0 transition border cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-r from-[#B87333] to-[#E8A85C] text-[#050F1E] font-bold border-[#E8A85C] shadow'
                    : 'bg-[#0F294E] hover:bg-[#163768] text-slate-200 border-[#1E4680]'
                }`}
              >
                <span className="text-xs font-bold block truncate max-w-[200px]">{t.title.split('(')[0]}</span>
                <span className={`text-[11px] font-urdu block truncate max-w-[200px] ${isSelected ? 'text-[#050F1E]' : 'text-[#E8A85C]'}`}>
                  {t.titleUrdu.split('(')[0]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Topic Content */}
      <div className="p-4 sm:p-6 rounded-2xl bg-[#0A1E3C] border-2 border-[#1E4680] shadow-xl space-y-4">
        {/* Title Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1E4680]">
          <div>
            <h3 className="text-base sm:text-xl font-bold text-white font-sans">{selectedTopic.title}</h3>
            <p className="text-xs sm:text-sm text-[#E8A85C] font-urdu font-medium mt-0.5">{selectedTopic.titleUrdu}</p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveNoteTopic(selectedTopic)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer ${
                hasOwnerNote
                  ? 'bg-amber-500/20 text-[#E8A85C] border-[#E8A85C]'
                  : 'bg-[#163768] text-slate-300 border-[#1E4680] hover:text-white'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5 text-[#E8A85C]" />
              <span className="font-urdu">My Notes {hasOwnerNote && '✓'}</span>
            </button>

            {selectedTopic.diagramType && (
              <button
                onClick={() =>
                  setZoomedDiagram({
                    title: selectedTopic.title,
                    titleUrdu: selectedTopic.titleUrdu,
                    type: selectedTopic.diagramType || 'electrician_tools',
                  })
                }
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#B87333] to-[#E8A85C] hover:opacity-95 text-[#050F1E] text-xs font-bold flex items-center gap-1.5 shadow transition cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>HD Zoom</span>
              </button>
            )}
          </div>
        </div>

        {/* Vector Preview */}
        {selectedTopic.diagramType && (
          <div
            onClick={() =>
              setZoomedDiagram({
                title: selectedTopic.title,
                titleUrdu: selectedTopic.titleUrdu,
                type: selectedTopic.diagramType || 'electrician_tools',
              })
            }
            className="rounded-xl overflow-hidden cursor-pointer group border border-[#1E4680] bg-[#071326] relative"
          >
            <DiagramRenderer type={selectedTopic.diagramType} className="group-hover:scale-[1.01] transition duration-300" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
              <span className="px-4 py-2 rounded-xl bg-[#E8A85C] text-[#050F1E] font-bold text-xs flex items-center gap-1.5 shadow-xl">
                <Maximize2 className="w-4 h-4" /> Tap to Zoom Safety Guidelines
              </span>
            </div>
          </div>
        )}

        {/* Description Text */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-[#0F294E] border border-[#1E4680] text-xs text-slate-200 leading-relaxed font-sans space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#4ADE80] block">
              Safety & Operating Protocol:
            </span>
            <div className="whitespace-pre-line font-mono-code text-[11px] sm:text-xs">
              {selectedTopic.description}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#0F294E] border border-[#1E4680] text-xs sm:text-sm text-slate-200 leading-relaxed font-urdu space-y-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#E8A85C] block">
              اردو رہنمائی:
            </span>
            <div className="whitespace-pre-line" dir="rtl">
              {selectedTopic.description}
            </div>
          </div>
        </div>
      </div>

      {/* Zoom Modal */}
      {zoomedDiagram && (
        <DiagramZoomModal
          isOpen={true}
          onClose={() => setZoomedDiagram(null)}
          title={zoomedDiagram.title}
          titleUrdu={zoomedDiagram.titleUrdu}
          diagramType={zoomedDiagram.type}
        />
      )}

      {/* Owner Notes Modal */}
      {activeNoteTopic && (
        <OwnerNotesModal
          isOpen={true}
          onClose={() => setActiveNoteTopic(null)}
          topicId={activeNoteTopic.id}
          topicTitle={activeNoteTopic.title}
          topicTitleUrdu={activeNoteTopic.titleUrdu}
        />
      )}
    </div>
  );
};
