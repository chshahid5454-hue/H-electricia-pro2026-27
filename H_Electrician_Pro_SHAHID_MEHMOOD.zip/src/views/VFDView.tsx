import React, { useState } from 'react';
import { Gauge, Maximize2, Edit3, Table, Layers, ArrowRight } from 'lucide-react';
import { VFD_TOPICS_DATA } from '../data/vfdData';
import { VFDTopic } from '../types';
import { DiagramRenderer } from '../components/DiagramRenderer';
import { DiagramZoomModal } from '../components/DiagramZoomModal';
import { OwnerNotesModal } from '../components/OwnerNotesModal';
import { StorageService } from '../services/storage';

export const VFDView: React.FC = () => {
  const [selectedTopic, setSelectedTopic] = useState<VFDTopic>(VFD_TOPICS_DATA[0]);
  const [zoomedDiagram, setZoomedDiagram] = useState<{ title: string; titleUrdu: string; type: string } | null>(null);
  const [activeNoteTopic, setActiveNoteTopic] = useState<VFDTopic | null>(null);

  const hasOwnerNote = Boolean(StorageService.getOwnerNote(selectedTopic.id));

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white font-sans flex items-center gap-2">
              <Gauge className="w-5 h-5 text-[#38BDF8]" />
              VFD, HMI & SCADA | وی ایف ڈی، ایچ ایم آئی اور اسکاڈا
            </h2>
            <p className="text-xs text-slate-300 font-urdu mt-0.5">
              ڈنفس و سیمنز پیرامیٹرز لسٹ، فارورڈ ریورس کنٹرول، پی ایل سی موڈبس اور اسکاڈا نیٹ ورک
            </p>
          </div>
          <span className="text-xs font-mono bg-[#162C58] text-[#38BDF8] border border-[#1E3A70] px-3 py-1 rounded-md font-bold">
            Danfoss & Siemens
          </span>
        </div>

        {/* Topic Pills */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {VFD_TOPICS_DATA.map((t) => {
            const isSelected = selectedTopic.id === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setSelectedTopic(t)}
                className={`px-3 py-2 rounded-xl text-left flex-shrink-0 transition border cursor-pointer ${
                  isSelected
                    ? 'bg-[#0284C7] text-white font-bold border-[#38BDF8] shadow'
                    : 'bg-[#0F2042] hover:bg-[#162C58] text-slate-200 border-[#1E3A70]'
                }`}
              >
                <span className="text-xs font-bold block truncate max-w-[200px]">{t.title.split('(')[0]}</span>
                <span className={`text-[11px] font-urdu block truncate max-w-[200px] ${isSelected ? 'text-blue-100' : 'text-[#E8A85C]'}`}>
                  {t.titleUrdu.split('(')[0]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Topic Content */}
      <div className="p-4 sm:p-6 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl space-y-4">
        {/* Title Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1E3A70]">
          <div>
            <span className="text-[10px] uppercase font-bold text-[#38BDF8] tracking-wider bg-[#162C58] px-2 py-0.5 rounded border border-[#1E3A70]">
              {selectedTopic.category.toUpperCase().replace(/_/g, ' ')}
            </span>
            <h3 className="text-base sm:text-xl font-bold text-white font-sans mt-1">{selectedTopic.title}</h3>
            <p className="text-xs sm:text-sm text-[#E8A85C] font-urdu font-medium mt-0.5">{selectedTopic.titleUrdu}</p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveNoteTopic(selectedTopic)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition cursor-pointer ${
                hasOwnerNote
                  ? 'bg-amber-500/20 text-[#E8A85C] border-[#E8A85C]'
                  : 'bg-[#162C58] text-slate-300 border-[#1E3A70] hover:text-white'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5 text-[#E8A85C]" />
              <span className="font-urdu">My Notes {hasOwnerNote && '✓'}</span>
            </button>

            {selectedTopic.diagramType && (
              <button
                onClick={() =>
                  setZoomedDiagram({
                    title: selectedTopic.title,
                    titleUrdu: selectedTopic.titleUrdu,
                    type: selectedTopic.diagramType || 'vfd_power_control',
                  })
                }
                className="px-3.5 py-1.5 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-white text-xs font-bold flex items-center gap-1.5 shadow transition cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>HD Zoom</span>
              </button>
            )}
          </div>
        </div>

        {/* Vector Diagram Preview if available */}
        {selectedTopic.diagramType && (
          <div
            onClick={() =>
              setZoomedDiagram({
                title: selectedTopic.title,
                titleUrdu: selectedTopic.titleUrdu,
                type: selectedTopic.diagramType || 'vfd_power_control',
              })
            }
            className="rounded-xl overflow-hidden cursor-pointer group border border-[#1E3A70] bg-[#070F1E] relative"
          >
            <DiagramRenderer type={selectedTopic.diagramType} className="group-hover:scale-[1.01] transition duration-300" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
              <span className="px-4 py-2 rounded-xl bg-[#0284C7] text-white font-bold text-xs flex items-center gap-1.5 shadow-xl">
                <Maximize2 className="w-4 h-4" /> Tap to Zoom VFD & Network Schematics
              </span>
            </div>
          </div>
        )}

        {/* Text Description */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-[#0F294E] border border-[#1E4680] text-xs text-slate-200 leading-relaxed font-sans space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#38BDF8] block">
              Technical Details:
            </span>
            <div className="whitespace-pre-line font-mono-code text-[11px] sm:text-xs">
              {selectedTopic.description}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#0F294E] border border-[#1E4680] text-xs sm:text-sm text-slate-200 leading-relaxed font-urdu space-y-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#E8A85C] block">
              اردو گائیڈ:
            </span>
            <div className="whitespace-pre-line" dir="rtl">
              {selectedTopic.descriptionUrdu}
            </div>
          </div>
        </div>

        {/* Parameters Table if present (e.g. Danfoss / Siemens) */}
        {selectedTopic.parametersTable && (
          <div className="p-4 rounded-xl bg-[#071326] border border-[#1E4680]">
            <span className="text-xs font-bold uppercase tracking-wider text-[#E8A85C] block mb-3">
              Standard Drive Parameters (پیرامیٹرز لسٹ):
            </span>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-[#0F294E] text-[#E8A85C] uppercase text-[10px] font-bold border-b border-[#1E4680]">
                  <tr>
                    <th className="p-2.5 font-mono">Code</th>
                    <th className="p-2.5">Parameter Name</th>
                    <th className="p-2.5">Recommended Setting</th>
                    <th className="p-2.5 font-urdu text-right">وضاحت / مقصد</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {selectedTopic.parametersTable.map((p, idx) => (
                    <tr key={idx} className="hover:bg-[#0F294E]/60 transition">
                      <td className="p-2.5 font-mono font-bold text-[#38BDF8]">{p.param}</td>
                      <td className="p-2.5 font-medium text-white">{p.name}</td>
                      <td className="p-2.5 font-mono text-emerald-400 font-bold">{p.recommended}</td>
                      <td className="p-2.5 font-urdu text-[#E8A85C] text-right">{p.descUrdu}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Zoom Modal */}
      {zoomedDiagram && (
        <DiagramZoomModal
          isOpen={true}
          onClose={() => setZoomedDiagram(null)}
          title={zoomedDiagram.title}
          titleUrdu={zoomedDiagram.titleUrdu}
          diagramType={zoomedDiagram.type}
        />
      )}

      {/* Owner Notes Modal */}
      {activeNoteTopic && (
        <OwnerNotesModal
          isOpen={true}
          onClose={() => setActiveNoteTopic(null)}
          topicId={activeNoteTopic.id}
          topicTitle={activeNoteTopic.title}
          topicTitleUrdu={activeNoteTopic.titleUrdu}
        />
      )}
    </div>
  );
};
