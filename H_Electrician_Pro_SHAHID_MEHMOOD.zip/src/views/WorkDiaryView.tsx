import React, { useState, useEffect } from 'react';
import {
  FileText,
  Plus,
  Phone,
  Calendar,
  DollarSign,
  Trash2,
  CheckCircle,
  Clock,
  Camera,
  Search,
  Filter,
  Share2,
  Check,
  Building,
  User,
} from 'lucide-react';
import { StorageService } from '../services/storage';
import { WorkDiaryEntry } from '../types';

export const WorkDiaryView: React.FC = () => {
  const [entries, setEntries] = useState<WorkDiaryEntry[]>([]);
  const [isAdding, setIsAdding] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'paid' | 'pending'>('all');
  const [shareToast, setShareToast] = useState<string>('');

  // Form states
  const [customerName, setCustomerName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [workType, setWorkType] = useState<string>('Star Delta Panel Wiring');
  const [workTypeUrdu, setWorkTypeUrdu] = useState<string>('سٹار ڈیلٹا پینل وائرنگ');
  const [billAmount, setBillAmount] = useState<number>(5000);
  const [isPaid, setIsPaid] = useState<boolean>(false);
  const [jobDate, setJobDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [notes, setNotes] = useState<string>('');
  const [photoBase64, setPhotoBase64] = useState<string>('');

  useEffect(() => {
    loadDiary();
  }, []);

  const loadDiary = () => {
    const list = StorageService.getWorkDiaryEntries();
    setEntries(list);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoBase64(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim()) return;

    const newEntry: WorkDiaryEntry = {
      id: `diary-${Date.now()}`,
      customerName: customerName.trim(),
      phone: phone.trim(),
      workType: workType.trim(),
      workTypeUrdu: workTypeUrdu.trim() || workType.trim(),
      billAmount: Number(billAmount) || 0,
      isPaid,
      date: jobDate,
      notes: notes.trim(),
      photoBase64,
      createdAt: Date.now(),
    };

    StorageService.saveWorkDiaryEntry(newEntry);
    loadDiary();
    setIsAdding(false);

    // Reset Form
    setCustomerName('');
    setPhone('');
    setBillAmount(5000);
    setIsPaid(false);
    setNotes('');
    setPhotoBase64('');
  };

  const handleDelete = (id: string) => {
    if (window.confirm('کیا آپ واقعی یہ کسٹمر ریکارڈ ڈیلیٹ کرنا چاہتے ہیں؟ (Delete job record?)')) {
      StorageService.deleteWorkDiaryEntry(id);
      loadDiary();
    }
  };

  const handleTogglePaid = (entry: WorkDiaryEntry) => {
    const updated = { ...entry, isPaid: !entry.isPaid };
    StorageService.saveWorkDiaryEntry(updated);
    loadDiary();
  };

  const handleShareReceipt = (entry: WorkDiaryEntry) => {
    const statusText = entry.isPaid ? 'مکمل وصول شدہ (PAID)' : 'بقایا واجب الادا (PENDING)';
    const text = `*شاہد الیکٹریشن - کام کی انوائس / رسید*\n\n👤 *کسٹمر:* ${entry.customerName}\n📱 *فون:* ${entry.phone || 'N/A'}\n🔧 *کام:* ${entry.workTypeUrdu} (${entry.workType})\n📅 *تاریخ:* ${entry.date}\n💰 *بل کی رقم:* PKR ${entry.billAmount.toLocaleString()}\n📌 *حالت:* ${statusText}\n${entry.notes ? `📝 *نوٹس:* ${entry.notes}\n` : ''}\n_رابطہ: شاہد الیکٹریشن - انڈسٹریل و پاور سروسز_`;

    if (navigator.share) {
      navigator.share({ title: `Invoice - ${entry.customerName}`, text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      setShareToast('انوائس کاپی ہو گئی! واٹس ایپ پر شیئر کریں (Invoice Copied)');
      setTimeout(() => setShareToast(''), 3000);
    }
  };

  // Metrics calculation
  const totalBilled = entries.reduce((acc, curr) => acc + (curr.billAmount || 0), 0);
  const totalPaid = entries
    .filter((e) => e.isPaid)
    .reduce((acc, curr) => acc + (curr.billAmount || 0), 0);
  const totalPending = totalBilled - totalPaid;

  const filteredEntries = entries.filter((e) => {
    const matchesStatus =
      statusFilter === 'all' ||
      (statusFilter === 'paid' && e.isPaid) ||
      (statusFilter === 'pending' && !e.isPaid);
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      !q ||
      e.customerName.toLowerCase().includes(q) ||
      e.phone.includes(q) ||
      e.workType.toLowerCase().includes(q) ||
      e.workTypeUrdu.includes(q) ||
      e.notes.toLowerCase().includes(q);
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-4 pb-14">
      {/* Header Bar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#1E3A70] shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white font-sans flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#38BDF8]" />
              My Work Diary & Billing | کسٹمر کھاتہ و بلنگ
            </h2>
            <p className="text-xs text-slate-300 font-urdu mt-0.5">
              کسٹمر کا نام، موبائل نمبر، کام کی قسم، بل کی رقم، وصولی اور کام کی تصاویر (100% آف لائن ڈیٹا بیس)
            </p>
          </div>

          <button
            onClick={() => setIsAdding(!isAdding)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#0284C7] to-[#0EA5E9] hover:opacity-95 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-[#0EA5E9]/20 transition cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>{isAdding ? 'Close Form' : 'Add New Job (نیا کسٹمر شامل کریں)'}</span>
          </button>
        </div>

        {/* Metrics Bar with Tabular Figures */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-3 border-t border-[#1E3A70]">
          <div className="p-3 rounded-xl bg-[#0F2042] border border-[#1E3A70]">
            <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">Total Work Jobs</span>
            <span className="text-xl font-extrabold text-white font-mono tabular-nums">{entries.length}</span>
            <span className="text-[10px] text-[#38BDF8] font-urdu block">کل جابز</span>
          </div>

          <div className="p-3 rounded-xl bg-[#0F2042] border border-[#1E3A70]">
            <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">Total Billed</span>
            <span className="text-xl font-extrabold text-[#E8A85C] font-mono tabular-nums">
              PKR {totalBilled.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400 font-urdu block">کل بل کی رقم</span>
          </div>

          <div className="p-3 rounded-xl bg-[#0F2042] border border-emerald-900/40">
            <span className="text-[10px] text-emerald-400 block uppercase font-bold tracking-wider">Received (Paid)</span>
            <span className="text-xl font-extrabold text-emerald-400 font-mono tabular-nums">
              PKR {totalPaid.toLocaleString()}
            </span>
            <span className="text-[10px] text-emerald-400 font-urdu block">وصول شدہ رقم</span>
          </div>

          <div className="p-3 rounded-xl bg-[#0F2042] border border-amber-900/40">
            <span className="text-[10px] text-amber-400 block uppercase font-bold tracking-wider">Pending Balance</span>
            <span className="text-xl font-extrabold text-amber-400 font-mono tabular-nums">
              PKR {totalPending.toLocaleString()}
            </span>
            <span className="text-[10px] text-amber-400 font-urdu block">بقایا واجب الادا</span>
          </div>
        </div>
      </div>

      {/* Share Toast Notification */}
      {shareToast && (
        <div className="py-2 px-3 rounded-xl bg-emerald-950 border border-emerald-500 text-emerald-200 text-xs font-semibold flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{shareToast}</span>
        </div>
      )}

      {/* Add New Job Form Modal / Accordion */}
      {isAdding && (
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 rounded-2xl bg-[#0B172E] border border-[#0EA5E9] shadow-2xl space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between pb-2 border-b border-[#1E3A70]">
            <h3 className="font-bold text-sm text-[#38BDF8]">
              New Customer Work Record (نیا کسٹمر کام درج کریں)
            </h3>
            <button type="button" onClick={() => setIsAdding(false)} className="text-slate-400 hover:text-white">
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-slate-300 font-bold block mb-1">Customer / Factory Name:</label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="مثلاً: چوہدری ندیم (رائس مل)"
                className="w-full rounded-lg bg-[#070F1E] border border-[#1E3A70] p-2.5 text-white font-urdu text-sm focus:border-[#0EA5E9] focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1">Phone Number (موبائل نمبر):</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="03001234567"
                className="w-full rounded-lg bg-[#070F1E] border border-[#1E3A70] p-2.5 text-white font-mono focus:border-[#0EA5E9] focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1">Work Type (کام کی تفصیل):</label>
              <input
                type="text"
                value={workType}
                onChange={(e) => setWorkType(e.target.value)}
                placeholder="Star Delta Panel, Motor Rewind, Solar..."
                className="w-full rounded-lg bg-[#070F1E] border border-[#1E3A70] p-2.5 text-white focus:border-[#0EA5E9] focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1 font-urdu">کام کی قسم (اردو):</label>
              <input
                type="text"
                value={workTypeUrdu}
                onChange={(e) => setWorkTypeUrdu(e.target.value)}
                placeholder="سٹار ڈیلٹا پینل یا سولر فٹنگ"
                className="w-full rounded-lg bg-[#070F1E] border border-[#1E3A70] p-2.5 text-white font-urdu focus:border-[#0EA5E9] focus:outline-none"
                dir="rtl"
              />
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1">Bill Amount in PKR (بل کی رقم):</label>
              <input
                type="number"
                required
                value={billAmount}
                onChange={(e) => setBillAmount(Number(e.target.value))}
                className="w-full rounded-lg bg-[#070F1E] border border-[#1E3A70] p-2.5 text-white font-mono font-bold text-base focus:border-[#0EA5E9] focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1">Payment Status (وصولی کی صورتحال):</label>
              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsPaid(true)}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold border transition cursor-pointer ${
                    isPaid ? 'bg-emerald-600 text-white border-emerald-400' : 'bg-[#0F2042] text-slate-400 border-[#1E3A70]'
                  }`}
                >
                  PAID (مکمل وصول)
                </button>
                <button
                  type="button"
                  onClick={() => setIsPaid(false)}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold border transition cursor-pointer ${
                    !isPaid ? 'bg-amber-600 text-white border-amber-400' : 'bg-[#0F2042] text-slate-400 border-[#1E3A70]'
                  }`}
                >
                  PENDING (بقایا ہے)
                </button>
              </div>
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1">Date (تاریخ):</label>
              <input
                type="date"
                value={jobDate}
                onChange={(e) => setJobDate(e.target.value)}
                className="w-full rounded-lg bg-[#070F1E] border border-[#1E3A70] p-2 text-white font-mono focus:border-[#0EA5E9] focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1">Work Photo (کام یا پینل کی تصویر):</label>
              <label className="flex items-center gap-2 p-2 rounded-lg bg-[#070F1E] border border-[#1E3A70] hover:border-[#0EA5E9] text-slate-300 cursor-pointer">
                <Camera className="w-4 h-4 text-[#38BDF8]" />
                <span className="truncate">{photoBase64 ? 'Photo Selected ✓' : 'Upload photo from phone'}</span>
                <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
              </label>
            </div>

            <div className="sm:col-span-2">
              <label className="text-slate-300 font-bold block mb-1 font-urdu">تفصیل یا ضروری نوٹس (Notes):</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="سامان کیا لگا، اوور لوڈ کتنے پر سیٹ کی، گاہک سے کیا بات ہوئی..."
                rows={2}
                className="w-full rounded-lg bg-[#070F1E] border border-[#1E3A70] p-2.5 text-white font-urdu resize-none focus:border-[#0EA5E9] focus:outline-none"
                dir="rtl"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-[#1E3A70]">
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#0284C7] to-[#0EA5E9] text-white font-bold text-xs shadow-lg cursor-pointer"
            >
              Save Record (محفوظ کریں)
            </button>
          </div>
        </form>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap sm:flex-nowrap gap-2 items-center justify-between">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="کسٹمر یا فون نمبر سے تلاش کریں... (Search customer or phone)"
            className="w-full rounded-xl bg-[#0B172E] border border-[#1E3A70] focus:border-[#0EA5E9] focus:outline-none pl-9 pr-3 py-2 text-xs text-white placeholder-slate-400 font-urdu"
          />
        </div>

        <div className="flex items-center gap-1 bg-[#0B172E] border border-[#1E3A70] p-1 rounded-xl">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
              statusFilter === 'all' ? 'bg-[#0284C7] text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            All ({entries.length})
          </button>
          <button
            onClick={() => setStatusFilter('paid')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
              statusFilter === 'paid' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Paid ({entries.filter((e) => e.isPaid).length})
          </button>
          <button
            onClick={() => setStatusFilter('pending')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
              statusFilter === 'pending' ? 'bg-amber-600 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Pending ({entries.filter((e) => !e.isPaid).length})
          </button>
        </div>
      </div>

      {/* Work Entries Cards List */}
      <div className="space-y-3">
        {filteredEntries.length === 0 ? (
          <div className="p-10 text-center rounded-2xl bg-[#0B172E] border border-[#1E3A70] text-slate-400">
            <FileText className="w-8 h-8 mx-auto text-[#38BDF8] opacity-60 mb-2" />
            <p>کوئی کسٹمر ریکارڈ نہیں ملا (No job records found)</p>
          </div>
        ) : (
          filteredEntries.map((entry) => (
            <div
              key={entry.id}
              className="p-4 rounded-xl bg-[#0B172E] border border-[#1E3A70] hover:border-[#0EA5E9] shadow-md transition flex flex-col sm:flex-row gap-4 justify-between"
            >
              {/* Left Details */}
              <div className="space-y-1.5 flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base font-bold text-white font-sans">{entry.customerName}</h3>
                  <button
                    onClick={() => handleTogglePaid(entry)}
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border transition cursor-pointer ${
                      entry.isPaid
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500'
                        : 'bg-amber-500/20 text-amber-300 border-amber-500'
                    }`}
                  >
                    {entry.isPaid ? 'PAID ✓ (وصول)' : 'PENDING ⚠️ (بقایا)'}
                  </button>
                </div>

                <p className="text-xs text-[#E8A85C] font-urdu font-medium">{entry.workTypeUrdu}</p>
                <p className="text-[11px] text-slate-400 font-mono">{entry.workType}</p>

                {entry.notes && (
                  <p className="text-xs text-slate-300 font-urdu pt-1 border-t border-[#1E3A70]">
                    {entry.notes}
                  </p>
                )}

                <div className="flex items-center gap-3 text-[11px] text-slate-400 pt-1">
                  <span className="flex items-center gap-1 font-mono">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    {entry.date}
                  </span>
                  {entry.phone && (
                    <a
                      href={`tel:${entry.phone}`}
                      className="flex items-center gap-1 text-[#38BDF8] hover:underline font-mono"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      {entry.phone}
                    </a>
                  )}
                </div>
              </div>

              {/* Right Side: Photo & Bill & Actions */}
              <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#1E3A70]/60">
                {entry.photoBase64 && (
                  <img
                    src={entry.photoBase64}
                    alt="Work snapshot"
                    className="w-16 h-16 rounded-xl object-cover border border-[#1E3A70] shadow"
                  />
                )}

                <div className="text-left sm:text-right">
                  <span className="text-xs text-slate-400 block font-mono">Total Bill:</span>
                  <span className="text-lg font-black text-[#E8A85C] font-mono tabular-nums">
                    PKR {entry.billAmount.toLocaleString()}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleShareReceipt(entry)}
                    className="p-2 rounded-lg bg-[#0F2042] text-slate-300 hover:text-white border border-[#1E3A70] hover:border-[#0EA5E9] transition cursor-pointer"
                    title="Share Invoice on WhatsApp"
                  >
                    <Share2 className="w-4 h-4 text-[#38BDF8]" />
                  </button>

                  {entry.phone && (
                    <a
                      href={`tel:${entry.phone}`}
                      className="p-2 rounded-lg bg-emerald-950/60 text-emerald-300 border border-emerald-700/60 hover:bg-emerald-900 transition"
                      title="Direct Call Customer"
                    >
                      <Phone className="w-4 h-4" />
                    </a>
                  )}

                  <button
                    onClick={() => handleDelete(entry.id)}
                    className="p-2 rounded-lg bg-red-950/60 text-red-400 border border-red-700/60 hover:bg-red-900 transition cursor-pointer"
                    title="Delete record"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
